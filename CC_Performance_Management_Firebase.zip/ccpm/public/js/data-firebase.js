/* =========================================================================
 * DATA SERVICE - FIREBASE (Auth + Firestore + Storage)
 * Antarmuka identik dengan data-demo.js.
 *
 * Koleksi Firestore:
 *   users, usernames, customers, projects, kpi_targets, daily_performance,
 *   quality_performance, upload_history, upload_errors, issue_tracking,
 *   reports, audit_logs, login_history, login_attempts, system_settings
 * (roles & permissions disimpan di system_settings/permissions)
 * ========================================================================= */
(function () {
  'use strict';
  const C = window.Core;
  let F = {}; let app, auth, db, storage; let profile = null; let sid = C.uid('sess');
  const listeners = [];
  const now = () => new Date().toISOString();
  const strip = o => JSON.parse(JSON.stringify(o)); // buang undefined

  const MSG = {
    'auth/invalid-credential': 'Email/username atau password salah.',
    'auth/wrong-password': 'Email/username atau password salah.',
    'auth/user-not-found': 'Email/username atau password salah.',
    'auth/invalid-email': 'Format email tidak valid.',
    'auth/too-many-requests': 'Terlalu banyak percobaan gagal. Akun dikunci sementara, coba lagi nanti atau reset password.',
    'auth/user-disabled': 'Akun dinonaktifkan. Hubungi administrator.',
    'auth/email-already-in-use': 'Email sudah terdaftar.',
    'auth/weak-password': 'Password minimal 8 karakter.',
    'auth/network-request-failed': 'Koneksi ke server gagal. Periksa jaringan Anda.',
    'permission-denied': 'Anda tidak memiliki akses untuk aksi ini.'
  };
  const friendly = e => new Error(MSG[e && e.code] || (e && e.message) || 'Terjadi kesalahan.');

  async function loadProfile(user) {
    if (!user) return null;
    const snap = await F.getDoc(F.doc(db, 'users', user.uid));
    if (!snap.exists()) return null;
    return Object.assign({ id: user.uid }, snap.data());
  }
  function emit(p, err) { profile = p; listeners.forEach(f => f(p, err)); }

  async function queryScoped(colName, ids) {
    const col = F.collection(db, colName);
    if (!ids) { const s = await F.getDocs(col); return s.docs.map(d => Object.assign({ id: d.id }, d.data())); }
    const out = [];
    for (const pid of ids) { const s = await F.getDocs(F.query(col, F.where('projectId', '==', pid))); s.docs.forEach(d => out.push(Object.assign({ id: d.id }, d.data()))); }
    return out;
  }

  const DS = {
    mode: 'firebase',
    async init() {
      const v = window.APP_CONFIG.firebaseSdkVersion; const base = `https://www.gstatic.com/firebasejs/${v}/`;
      const [A, AU, FS] = await Promise.all([import(base + 'firebase-app.js'), import(base + 'firebase-auth.js'), import(base + 'firebase-firestore.js')]);
      let ST = null; try { ST = await import(base + 'firebase-storage.js'); } catch (e) { ST = null; }
      F = Object.assign({}, A, AU, FS, ST ? { ref: ST.ref, uploadBytes: ST.uploadBytes, getDownloadURL: ST.getDownloadURL, getStorage: ST.getStorage } : {});
      app = F.initializeApp(window.APP_CONFIG.firebase);
      auth = F.getAuth(app); db = F.getFirestore(app);
      try { storage = F.getStorage ? F.getStorage(app) : null; } catch (e) { storage = null; }
      // uji koneksi ringan: baca dokumen bootstrap (publik)
      await Promise.race([F.getDoc(F.doc(db, 'system_settings', 'bootstrap')), new Promise((_, r) => setTimeout(() => r(new Error('timeout')), 12000))]);
      F.onAuthStateChanged(auth, async user => {
        if (!user) return emit(null);
        try {
          const p = await loadProfile(user);
          if (!p) { await F.signOut(auth); return emit(null, 'Profil user belum terdaftar. Hubungi Super Admin.'); }
          if (p.status !== 'active') { await F.signOut(auth); return emit(null, 'Akun dinonaktifkan. Hubungi administrator.'); }
          emit(p);
        } catch (e) { emit(null, friendly(e).message); }
      });
      return 'firebase';
    },
    onAuthChange(cb) { listeners.push(cb); },
    sessionId() { return sid; },
    async bootstrapStatus() { const s = await F.getDoc(F.doc(db, 'system_settings', 'bootstrap')); return { needsSetup: !s.exists() }; },
    async createFirstAdmin({ name, email, password, username }) {
      try {
        const cred = await F.createUserWithEmailAndPassword(auth, email, password);
        const uid = cred.user.uid; const b = F.writeBatch(db);
        username = (username || email.split('@')[0]).toLowerCase();
        b.set(F.doc(db, 'users', uid), { name, username, email, phone: '', role: 'super_admin', projects: [], customers: [], status: 'active', createdAt: now(), lastLogin: now() });
        b.set(F.doc(db, 'usernames', username), { email, uid });
        b.set(F.doc(db, 'system_settings', 'bootstrap'), { uid, at: now() });
        await b.commit();
        const p = await loadProfile(cred.user); emit(p); return p;
      } catch (e) { throw friendly(e); }
    },
    async login(id, password, remember) {
      id = String(id || '').trim().toLowerCase(); let email = id;
      try {
        if (!id.includes('@')) { const s = await F.getDoc(F.doc(db, 'usernames', id)); if (!s.exists()) throw { code: 'auth/invalid-credential' }; email = s.data().email; }
        await F.setPersistence(auth, remember ? F.browserLocalPersistence : F.browserSessionPersistence);
        const cred = await F.signInWithEmailAndPassword(auth, email, password);
        const p = await loadProfile(cred.user);
        if (!p) { await F.signOut(auth); throw new Error('Profil user belum terdaftar. Hubungi Super Admin.'); }
        if (p.status !== 'active') { await F.signOut(auth); throw new Error('Akun dinonaktifkan. Hubungi administrator.'); }
        sid = C.uid('sess');
        await F.updateDoc(F.doc(db, 'users', p.id), { lastLogin: now() });
        await F.addDoc(F.collection(db, 'login_history'), { userId: p.id, userName: p.name, email: p.email, at: now(), sessionId: sid, agent: navigator.userAgent.slice(0, 80) });
        return p;
      } catch (e) {
        try { await F.addDoc(F.collection(db, 'login_attempts'), { email, at: now(), reason: (e && e.code) || 'error' }); } catch (x) { }
        throw e instanceof Error && !e.code ? e : friendly(e);
      }
    },
    async logout() { await F.signOut(auth); },
    async forgotPassword(email) { try { await F.sendPasswordResetEmail(auth, String(email).trim()); return { sent: true }; } catch (e) { throw friendly(e); } },
    // USERS
    async listUsers() { const s = await F.getDocs(F.collection(db, 'users')); return s.docs.map(d => Object.assign({ id: d.id }, d.data())); },
    async createUser(data, password) {
      const sec = F.initializeApp(window.APP_CONFIG.firebase, 'sec-' + Date.now());
      try {
        const sAuth = F.getAuth(sec);
        const cred = await F.createUserWithEmailAndPassword(sAuth, data.email, password);
        const uid = cred.user.uid; await F.signOut(sAuth);
        const doc = strip(Object.assign({ createdAt: now(), lastLogin: null }, data));
        const b = F.writeBatch(db);
        b.set(F.doc(db, 'users', uid), doc);
        if (data.username) b.set(F.doc(db, 'usernames', data.username.toLowerCase()), { email: data.email, uid });
        await b.commit();
        return Object.assign({ id: uid }, doc);
      } catch (e) { throw friendly(e); } finally { try { await F.deleteApp(sec); } catch (e) { } }
    },
    async updateUser(id, patch) {
      try {
        const b = F.writeBatch(db); b.update(F.doc(db, 'users', id), strip(patch));
        if (patch.username && patch.email) b.set(F.doc(db, 'usernames', patch.username.toLowerCase()), { email: patch.email, uid: id });
        await b.commit();
        if (profile && profile.id === id) emit(Object.assign({}, profile, patch));
      } catch (e) { throw friendly(e); }
    },
    async deleteUser(id) {
      const s = await F.getDoc(F.doc(db, 'users', id)); const b = F.writeBatch(db);
      if (s.exists() && s.data().username) b.delete(F.doc(db, 'usernames', s.data().username.toLowerCase()));
      b.delete(F.doc(db, 'users', id)); await b.commit();
    },
    async adminResetPassword(user) { await F.sendPasswordResetEmail(auth, user.email); return { sent: true }; },
    // MASTER DATA
    async listCustomers() { const s = await F.getDocs(F.collection(db, 'customers')); return s.docs.map(d => Object.assign({ id: d.id }, d.data())); },
    async saveCustomer(c) { await F.setDoc(F.doc(db, 'customers', c.id), strip(c)); },
    async deleteCustomer(id) { await F.deleteDoc(F.doc(db, 'customers', id)); },
    async listProjects() { const s = await F.getDocs(F.collection(db, 'projects')); return s.docs.map(d => Object.assign({ id: d.id }, d.data())); },
    async saveProject(p) { await F.setDoc(F.doc(db, 'projects', p.id), strip(p)); },
    async deleteProject(id) { await F.deleteDoc(F.doc(db, 'projects', id)); },
    async getKpiTargets() { const s = await F.getDocs(F.collection(db, 'kpi_targets')); const o = {}; s.docs.forEach(d => { const x = d.data(); delete x.projectId; o[d.id] = x; }); return o; },
    async saveKpiTarget(pid, obj) { await F.setDoc(F.doc(db, 'kpi_targets', pid), strip(Object.assign({ projectId: pid }, obj))); },
    async getSettings() {
      const out = { formulas: Object.assign({}, C.DEFAULT_FORMULAS), permissions: JSON.parse(JSON.stringify(C.DEFAULT_ROLE_PERMS)) };
      for (const k of ['formulas', 'permissions']) { try { const s = await F.getDoc(F.doc(db, 'system_settings', k)); if (s.exists()) out[k] = Object.assign(out[k], s.data().value || {}); } catch (e) { } }
      return out;
    },
    async saveSetting(key, val) { await F.setDoc(F.doc(db, 'system_settings', key), { value: strip(val), updatedAt: now() }); },
    // PERFORMANCE
    async loadPerformance(ids) { const list = await queryScoped('daily_performance', ids); const o = {}; list.forEach(d => o[d.id] = d); return o; },
    async getPerformanceMonth(key) { try { const s = await F.getDoc(F.doc(db, 'daily_performance', key)); return s.exists() ? Object.assign({ id: s.id }, s.data()) : null; } catch (e) { if (e && e.code === 'permission-denied') return null; throw e; } },
    async savePerformanceMonth(doc) { const d = strip(doc); delete d.id; await F.setDoc(F.doc(db, 'daily_performance', doc.id), d); },
    async deletePerformanceMonth(key) { await F.deleteDoc(F.doc(db, 'daily_performance', key)); },
    async loadAgents(ids) { const list = await queryScoped('quality_performance', ids); return list.flatMap(d => (d.agents || []).map(a => Object.assign({ projectId: d.projectId }, a))); },
    // UPLOADS
    async listUploads(ids) { const l = await queryScoped('upload_history', ids); return l.sort((a, b) => (b.uploadedAt || '').localeCompare(a.uploadedAt || '')); },
    async saveUpload(rec) { const d = strip(rec); delete d.id; await F.setDoc(F.doc(db, 'upload_history', rec.id), d); },
    async deleteUpload(id) { await F.deleteDoc(F.doc(db, 'upload_history', id)); try { await F.deleteDoc(F.doc(db, 'upload_errors', id)); } catch (e) { } },
    async saveUploadErrors(id, errors) { await F.setDoc(F.doc(db, 'upload_errors', id), { projectId: errors.projectId || null, errors: strip(errors.list || errors).slice(0, 3000) }); },
    async getUploadErrors(id) { const s = await F.getDoc(F.doc(db, 'upload_errors', id)); return s.exists() ? (s.data().errors || []) : []; },
    async uploadFile(file, path) {
      if (!storage || !F.ref) return { path, url: null, stored: false, note: 'Firebase Storage tidak aktif.' };
      try { const r = F.ref(storage, path); await F.uploadBytes(r, file); const url = await F.getDownloadURL(r); return { path, url, stored: true }; }
      catch (e) { return { path, url: null, stored: false, note: 'File tidak tersimpan ke Storage (' + (e.code || e.message) + ').' }; }
    },
    // ISSUES & REPORTS
    async listIssues(ids) { return queryScoped('issue_tracking', ids); },
    async saveIssue(issue) { const d = strip(issue); delete d.id; await F.setDoc(F.doc(db, 'issue_tracking', issue.id), d); },
    async listReports() { const s = await F.getDocs(F.query(F.collection(db, 'reports'), F.where('ownerId', '==', profile ? profile.id : '-'))); return s.docs.map(d => Object.assign({ id: d.id }, d.data())); },
    async saveReport(r) { const d = strip(Object.assign({ ownerId: profile ? profile.id : null }, r)); delete d.id; await F.setDoc(F.doc(db, 'reports', r.id), d); },
    async deleteReport(id) { await F.deleteDoc(F.doc(db, 'reports', id)); },
    // AUDIT
    async audit(e) { try { await F.addDoc(F.collection(db, 'audit_logs'), strip(Object.assign({ at: now(), serverAt: F.serverTimestamp(), sessionId: sid, userId: profile ? profile.id : null }, e))); } catch (x) { console.warn('audit gagal', x); } },
    async listAudit(limit = 500) { const s = await F.getDocs(F.query(F.collection(db, 'audit_logs'), F.orderBy('at', 'desc'), F.limit(limit))); return s.docs.map(d => Object.assign({ id: d.id }, d.data())); },
    async listLoginHistory(limit = 300) { const s = await F.getDocs(F.query(F.collection(db, 'login_history'), F.orderBy('at', 'desc'), F.limit(limit))); return s.docs.map(d => Object.assign({ id: d.id }, d.data())); },
    async listFailedLogins(limit = 300) { const s = await F.getDocs(F.query(F.collection(db, 'login_attempts'), F.orderBy('at', 'desc'), F.limit(limit))); return s.docs.map(d => Object.assign({ id: d.id }, d.data())); },
    // IMPORT DATA AWAL (dari file Excel yang diberikan)
    async importSeed(seed, progress) {
      const ops = [];
      seed.customers.forEach(c => ops.push(['customers', c.id, c]));
      seed.projects.forEach(p => ops.push(['projects', p.id, p]));
      Object.entries(seed.kpi).forEach(([pid, k]) => ops.push(['kpi_targets', pid, Object.assign({ projectId: pid }, k)]));
      Object.entries(seed.months).forEach(([key, rows]) => { const [pid, period] = key.split('_'); const p = seed.projects.find(x => x.id === pid); ops.push(['daily_performance', key, { projectId: pid, customerId: p ? p.customerId : '', period, rows, source: 'seed', uploadId: 'up-seed', updatedAt: now(), updatedBy: 'Import data awal' }]); });
      const byP = {}; seed.agents.forEach(a => { (byP[a.projectId] = byP[a.projectId] || []).push(a); });
      Object.entries(byP).forEach(([pid, agents]) => ops.push(['quality_performance', pid, { projectId: pid, agents }]));
      const total = Object.values(seed.months).reduce((a, r) => a + r.length, 0);
      ops.push(['upload_history', 'up-seed', { fileName: 'dashboard_performance_govseg3_ytd_2026_fixed.xlsx', projectId: '*', projectName: 'Semua project (data awal)', period: '2026-01 s/d 2026-09', totalRows: total, validRows: total, errorRows: 0, duplicateRows: 0, missingData: 0, uploadedAt: now(), uploadedBy: profile ? profile.name : 'Sistem', status: 'Approved', note: 'Import data awal' }]);
      for (let i = 0; i < ops.length; i += 10) {
        const b = F.writeBatch(db);
        ops.slice(i, i + 10).forEach(([c, id, data]) => b.set(F.doc(db, c, id), strip(data)));
        await b.commit(); progress && progress(Math.min(1, (i + 10) / ops.length));
      }
      return { docs: ops.length };
    }
  };
  window.FirebaseDataService = DS;
})();
