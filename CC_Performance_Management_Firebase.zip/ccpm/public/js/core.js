/* =========================================================================
 * CORE: konstanta, template Excel, RBAC, mesin kalkulasi & validasi.
 * Semua dashboard, report, dan alert memakai fungsi di file ini sehingga
 * angka di Executive / Project / Report selalu sama.
 * ========================================================================= */
(function () {
  'use strict';

  /* ---------- STANDARD EXCEL TEMPLATE (urutan & nama kolom WAJIB persis) ---------- */
  // key: nama field internal; t: tipe (text|month|date|day|int|num|pct|sec)
  const TEMPLATE_COLUMNS = [
    { h: 'PROJECT', k: 'project', t: 'text', req: true, d: 'Kode project (lihat sheet MASTER)' },
    { h: 'MONTH', k: 'month', t: 'month', req: true, d: 'JAN, FEB, ... DEC' },
    { h: 'DATE', k: 'date', t: 'date', req: true, d: 'Tanggal (format tanggal Excel / YYYY-MM-DD)' },
    { h: 'DAY', k: 'day', t: 'day', d: 'Nama hari (Senin/Monday)' },
    { h: 'Call Offered (Inbound)', k: 'off', t: 'int', d: 'Jumlah panggilan masuk' },
    { h: 'ACD Call (Inbound)', k: 'acd', t: 'int', d: 'Panggilan terjawab agent' },
    { h: 'Accepted Call (Inbound)', k: 'acc', t: 'int', d: 'Otomatis = ACD Call bila kosong' },
    { h: 'Abandon Call (Inbound)', k: 'abd', t: 'int', d: 'Panggilan abandon' },
    { h: 'AHT (Inbound)', k: 'aht', t: 'sec', d: 'Detik (atau hh:mm:ss)' },
    { h: 'Call Minute', k: 'cmin', t: 'num', d: 'Total menit panggilan' },
    { h: 'SCR', k: 'scr', t: 'pct', d: '0-100% (0.95 atau 95)' },
    { h: 'SL', k: 'sl', t: 'pct', d: 'Service Level 0-100%' },
    { h: 'Target SCR', k: 'tscr', t: 'pct', d: 'Target SCR harian' },
    { h: 'Realisasi SCR', k: 'rscr', t: 'pct', d: 'Realisasi SCR harian' },
    { h: 'Call Outbond (Jumlah)', k: 'ob', t: 'int', d: 'Jumlah call outbound' },
    { h: 'Walkin', k: 'walkin', t: 'int', ch: true },
    { h: 'SMS', k: 'sms', t: 'int', ch: true },
    { h: 'Email', k: 'email', t: 'int', ch: true },
    { h: 'Aplikasi', k: 'aplikasi', t: 'int', ch: true },
    { h: 'Chatbot', k: 'chatbot', t: 'int', ch: true },
    { h: 'Facebook', k: 'facebook', t: 'int', ch: true },
    { h: 'Threads', k: 'threads', t: 'int', ch: true },
    { h: 'Instagram', k: 'instagram', t: 'int', ch: true },
    { h: 'Live Chat', k: 'livechat', t: 'int', ch: true },
    { h: 'Video Call', k: 'videocall', t: 'int', ch: true },
    { h: 'Apps', k: 'apps', t: 'int', ch: true },
    { h: 'Twiter (X)', k: 'twitter', t: 'int', ch: true },
    { h: 'WhatsApp interaction', k: 'wa', t: 'int', ch: true },
    { h: 'Whatsapp blasting', k: 'wablast', t: 'int', ch: true },
    { h: 'OTP', k: 'otp', t: 'int', ch: true },
    { h: 'Respon Time masing masing chanel', k: 'rt', t: 'sec', d: 'Rata-rata response time digital (detik)' },
    { h: 'Handling Time masing masing channel Digital', k: 'ht', t: 'sec', d: 'Rata-rata handling time digital (detik)' },
    { h: 'Respon Rate', k: 'rr', t: 'pct', d: '0-100%' },
    { h: 'Informasi', k: 'info', t: 'int' },
    { h: 'Permintaan', k: 'perm', t: 'int' },
    { h: 'Komplain', k: 'komp', t: 'int' },
    { h: 'Non Pengaduan', k: 'nonp', t: 'int' },
    { h: 'Top Kategori 1', k: 'top1', t: 'text' },
    { h: 'Top Kategori 2', k: 'top2', t: 'text' },
    { h: 'Top Kategori 3', k: 'top3', t: 'text' },
    { h: 'Issue Ketidak tercapaian SCR', k: 'issue', t: 'text', d: 'Wajib diisi bila SCR < Target' },
    { h: 'Total Digital', k: 'totdig', t: 'int', d: 'Otomatis dihitung dari 15 channel digital' },
    { h: 'Jumlah Seat', k: 'seat', t: 'int' },
    { h: 'Jumlah SDM', k: 'sdm', t: 'int' },
    { h: 'Total Trafik All', k: 'tottraffic', t: 'int', d: 'Otomatis = Accepted + Outbound + Total Digital' },
    { h: 'Quality Score', k: 'qs', t: 'pct', d: 'Skor 0-100' },
    { h: 'Product Knowledge Score', k: 'pk', t: 'pct', d: 'Skor 0-100' },
    { h: 'Productifity Agent', k: 'prod', t: 'pct', d: '0-100%' },
    { h: 'Kehadiran', k: 'att', t: 'pct', d: 'Agent hadir / terjadwal x 100%' },
    { h: 'Ketepatan Login', k: 'login', t: 'pct', d: 'Login tepat waktu / total schedule x 100%' }
  ];

  const CHANNELS = TEMPLATE_COLUMNS.filter(c => c.ch).map(c => ({ k: c.k, label: c.h === 'Twiter (X)' ? 'Twitter/X' : c.h === 'WhatsApp interaction' ? 'WhatsApp' : c.h === 'Whatsapp blasting' ? 'WA Blasting' : c.h }));
  const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const MONTHS_ID = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  const MONTH_ALIASES = { JAN: 1, JANUARI: 1, JANUARY: 1, FEB: 2, FEBRUARI: 2, FEBUARI: 2, FEBRUARY: 2, MAR: 3, MARET: 3, MARCH: 3, APR: 4, APRIL: 4, MAY: 5, MEI: 5, JUN: 6, JUNI: 6, JUNE: 6, JUL: 7, JULI: 7, JULY: 7, AUG: 8, AGU: 8, AGT: 8, AGUSTUS: 8, AUGUST: 8, SEP: 9, SEPT: 9, SEPTEMBER: 9, OCT: 10, OKT: 10, OKTOBER: 10, OCTOBER: 10, NOV: 11, NOVEMBER: 11, DEC: 12, DES: 12, DESEMBER: 12, DECEMBER: 12 };
  const DAYS_ID = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  const DAYS_EN = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

  /* ---------- ROLES & PERMISSIONS ---------- */
  const ROLES = {
    super_admin: { label: 'Super Admin', all: true },
    corporate_admin: { label: 'Corporate Admin', all: true },
    project_manager: { label: 'Project Manager' },
    project_admin: { label: 'Project Admin' },
    data_entry: { label: 'Data Entry / Performance Admin' },
    viewer: { label: 'Viewer / Customer' }
  };
  const PERMISSIONS = [
    ['dashboard.view', 'Lihat dashboard'],
    ['template.download', 'Download template'],
    ['upload.data', 'Upload & submit data'],
    ['upload.approve', 'Approve / reject / reprocess upload'],
    ['data.delete', 'Hapus data & riwayat upload'],
    ['report.export', 'Generate & export report'],
    ['report.schedule', 'Jadwalkan report'],
    ['issue.edit', 'Kelola issue SCR'],
    ['customer.manage', 'Kelola customer'],
    ['project.manage', 'Kelola project'],
    ['kpi.configure', 'Konfigurasi KPI & target'],
    ['user.view', 'Monitoring user'],
    ['user.manage', 'Kelola user'],
    ['audit.view', 'Lihat audit log'],
    ['permission.manage', 'Kelola permission'],
    ['settings.manage', 'Pengaturan sistem & formula']
  ];
  const ALL = PERMISSIONS.map(p => p[0]);
  const DEFAULT_ROLE_PERMS = {
    super_admin: ALL.slice(),
    corporate_admin: ['dashboard.view', 'template.download', 'upload.data', 'upload.approve', 'report.export', 'report.schedule', 'issue.edit', 'customer.manage', 'project.manage', 'kpi.configure', 'user.view', 'user.manage', 'audit.view'],
    project_manager: ['dashboard.view', 'template.download', 'upload.data', 'report.export', 'issue.edit'],
    project_admin: ['dashboard.view', 'template.download', 'upload.data', 'report.export', 'issue.edit'],
    data_entry: ['template.download', 'upload.data'],
    viewer: ['dashboard.view', 'report.export']
  };

  /* ---------- FORMULA & ALERT DEFAULTS (dapat diubah Super Admin) ---------- */
  const DEFAULT_FORMULAS = {
    acceptedFromAcd: true,          // Accepted Call = ACD Call
    scrSource: 'uploaded',          // 'uploaded' | 'computed' (ACD/Offered)
    scrAggregate: 'weighted',       // 'weighted' (ΣACD/ΣOffered) | 'average'
    totalDigital: 'computed',       // 'computed' (Σ15 channel) | 'uploaded'
    totalTraffic: 'computed',       // 'computed' | 'uploaded'
    atRiskBand: 2,                  // poin % di bawah target masih 'At Risk'
    ahtRiskPct: 10,                 // % di atas target AHT masih 'At Risk'
    qualityExcellent: 95, qualityGood: 85
  };
  const DEFAULT_KPI = { scr: 90, sl: 90, aht: 300, quality: 90, pk: 80, productivity: 90, attendance: 98, login: 95, rt: 900, ht: 600, rr: 95 };

  /* ---------- UTIL ---------- */
  const isNum = v => typeof v === 'number' && isFinite(v);
  const sum = (arr, f) => arr.reduce((a, r) => { const v = f ? f(r) : r; return isNum(v) ? a + v : a; }, 0);
  const avg = arr => { const v = arr.filter(isNum); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null; };
  const pad = n => String(n).padStart(2, '0');
  const ymOf = d => d.slice(0, 7);
  const toISO = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const ymLabel = ym => { if (!ym) return ''; const [y, m] = ym.split('-'); return MONTHS_ID[+m - 1] + ' ' + y; };
  const ymShort = ym => { const [y, m] = ym.split('-'); return MONTHS_ID[+m - 1].slice(0, 3) + ' ' + y.slice(2); };
  const fmtInt = v => isNum(v) ? Math.round(v).toLocaleString('id-ID') : '–';
  const fmtNum = (v, d = 1) => isNum(v) ? v.toLocaleString('id-ID', { minimumFractionDigits: d, maximumFractionDigits: d }) : '–';
  const fmtPct = (v, d = 1) => isNum(v) ? fmtNum(v, d) + '%' : '–';
  const fmtCompact = v => { if (!isNum(v)) return '–'; const a = Math.abs(v); if (a >= 1e6) return fmtNum(v / 1e6, 2) + ' jt'; if (a >= 1e4) return fmtNum(v / 1e3, 1) + ' rb'; return fmtInt(v); };
  const fmtSec = v => { if (!isNum(v)) return '–'; v = Math.round(v); if (v < 60) return v + ' dtk'; const h = Math.floor(v / 3600), m = Math.floor((v % 3600) / 60), s = v % 60; return h ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`; };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const uid = (p = 'id') => p + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const isoWeek = dateStr => { const d = new Date(dateStr + 'T00:00:00'); const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); const dn = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - dn); const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1)); return t.getUTCFullYear() + '-W' + pad(Math.ceil(((t - y0) / 86400000 + 1) / 7)); };
  async function sha256(text) {
    try { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join(''); }
    catch (e) { let h = 0; for (const c of text) h = (h * 31 + c.charCodeAt(0)) | 0; return 'fallback-' + h; }
  }

  /* ---------- STATUS ---------- */
  // higher=true: makin tinggi makin baik. Return 'ok' | 'risk' | 'bad' | 'na'
  function status(value, target, higher = true, F = DEFAULT_FORMULAS) {
    if (!isNum(value) || !isNum(target)) return 'na';
    if (higher) { if (value >= target) return 'ok'; if (value >= target - (F.atRiskBand ?? 2)) return 'risk'; return 'bad'; }
    if (value <= target) return 'ok'; if (value <= target * (1 + (F.ahtRiskPct ?? 10) / 100)) return 'risk'; return 'bad';
  }
  const STATUS_LABEL = { ok: 'Achieved', risk: 'At Risk', bad: 'Below Target', na: 'No Data' };

  /* ---------- KALKULASI ---------- */
  // Menerapkan auto-calculation pada satu baris (dipakai saat upload & saat membaca).
  function computeRow(r, F = DEFAULT_FORMULAS) {
    const o = Object.assign({}, r);
    if (F.acceptedFromAcd && isNum(o.acd)) o.acc = o.acd;
    else if (!isNum(o.acc) && isNum(o.acd)) o.acc = o.acd;
    const chSum = CHANNELS.reduce((a, c) => a + (isNum(o[c.k]) ? o[c.k] : 0), 0);
    const hasCh = CHANNELS.some(c => isNum(o[c.k]));
    o.totdigCalc = hasCh ? chSum : (isNum(o.totdig) ? o.totdig : 0);
    o.totdigUsed = F.totalDigital === 'uploaded' && isNum(o.totdig) ? o.totdig : o.totdigCalc;
    o.trafficCalc = (isNum(o.acc) ? o.acc : 0) + (isNum(o.ob) ? o.ob : 0) + o.totdigUsed;
    o.trafficUsed = F.totalTraffic === 'uploaded' && isNum(o.tottraffic) ? o.tottraffic : o.trafficCalc;
    o.abdRate = isNum(o.abd) && isNum(o.off) && o.off > 0 ? o.abd / o.off * 100 : null;
    o.scrCalc = isNum(o.acd) && isNum(o.off) && o.off > 0 ? o.acd / o.off * 100 : null;
    o.scrUsed = F.scrSource === 'computed' ? (o.scrCalc ?? o.scr ?? null) : (isNum(o.scr) ? o.scr : o.scrCalc);
    return o;
  }

  // Agregasi satu kumpulan baris (multi project / multi hari)
  function aggregate(rows, F = DEFAULT_FORMULAS) {
    const a = { days: rows.length };
    ['off', 'acd', 'acc', 'abd', 'ob', 'cmin', 'info', 'perm', 'komp', 'nonp'].forEach(k => a[k] = sum(rows, r => r[k]));
    CHANNELS.forEach(c => a[c.k] = sum(rows, r => r[c.k]));
    a.totdig = sum(rows, r => r.totdigUsed);
    a.traffic = sum(rows, r => r.trafficUsed);
    a.abdRate = a.off > 0 ? a.abd / a.off * 100 : null;
    const scrRows = rows.filter(r => isNum(r.scrUsed));
    if (F.scrAggregate === 'weighted') {
      const w = scrRows.filter(r => isNum(r.off) && r.off > 0);
      const wo = sum(w, r => r.off);
      a.scr = wo > 0 ? sum(w, r => r.scrUsed * r.off) / wo : avg(scrRows.map(r => r.scrUsed));
    } else a.scr = avg(scrRows.map(r => r.scrUsed));
    const slRows = rows.filter(r => isNum(r.sl));
    const slw = slRows.filter(r => isNum(r.off) && r.off > 0); const so = sum(slw, r => r.off);
    a.sl = so > 0 ? sum(slw, r => r.sl * r.off) / so : avg(slRows.map(r => r.sl));
    a.tscr = avg(rows.map(r => r.tscr));
    a.rscr = avg(rows.map(r => r.rscr));
    const ahtR = rows.filter(r => isNum(r.aht) && isNum(r.acd) && r.acd > 0); const aw = sum(ahtR, r => r.acd);
    a.aht = aw > 0 ? sum(ahtR, r => r.aht * r.acd) / aw : avg(rows.map(r => r.aht));
    const dw = k => { const rr = rows.filter(r => isNum(r[k]) && r.totdigUsed > 0); const w = sum(rr, r => r.totdigUsed); return w > 0 ? sum(rr, r => r[k] * r.totdigUsed) / w : avg(rows.map(r => r[k])); };
    a.rt = dw('rt'); a.ht = dw('ht'); a.rr = avg(rows.map(r => r.rr));
    ['qs', 'pk', 'prod', 'att', 'login'].forEach(k => a[k] = avg(rows.map(r => r[k])));
    // headcount: nilai terakhir per project, lalu dijumlahkan
    const last = {};
    rows.forEach(r => { ['seat', 'sdm'].forEach(k => { if (isNum(r[k])) { const key = r.projectId + k; if (!last[key] || last[key].d <= r.date) last[key] = { d: r.date, v: r[k], k }; } }); });
    a.seat = null; a.sdm = null;
    Object.values(last).forEach(x => { a[x.k] = (a[x.k] || 0) + x.v; });
    a.projects = new Set(rows.map(r => r.projectId)).size;
    return a;
  }

  function groupBy(rows, keyFn) { const m = new Map(); rows.forEach(r => { const k = keyFn(r); if (!m.has(k)) m.set(k, []); m.get(k).push(r); }); return m; }
  function series(rows, keyFn, F) { const g = groupBy(rows, keyFn); return [...g.keys()].sort().map(k => ({ key: k, ...aggregate(g.get(k), F) })); }

  function qualityBand(v, F = DEFAULT_FORMULAS) { if (!isNum(v)) return null; return v >= F.qualityExcellent ? 'Excellent' : v >= F.qualityGood ? 'Good' : 'Need Improvement'; }

  // Alert otomatis per project
  function buildAlerts(perProject, targets, F) {
    const out = [];
    const chk = (p, label, val, tgt, higher, unit) => {
      const st = status(val, tgt, higher, F); if (st === 'ok' || st === 'na') return;
      const gap = Math.abs(val - tgt);
      const txt = higher ? `${label} ${p.name} berada di bawah target sebesar ${unit === 's' ? fmtSec(gap) : fmtNum(gap, 1) + '%'} (${unit === 's' ? fmtSec(val) : fmtPct(val)} vs target ${unit === 's' ? fmtSec(tgt) : fmtPct(tgt)}).`
        : `${label} ${p.name} melebihi target sebesar ${fmtSec(gap)} (${fmtSec(val)} vs ${fmtSec(tgt)}).`;
      out.push({ projectId: p.id, project: p.name, kpi: label, severity: st, text: txt });
    };
    perProject.forEach(({ project: p, agg: a }) => {
      const t = targets[p.id] || DEFAULT_KPI;
      if (a.off > 0) chk(p, 'SCR', a.scr, t.scr, true);
      if (a.off > 0) chk(p, 'SL', a.sl, t.sl, true);
      chk(p, 'Quality Score', a.qs, t.quality, true);
      chk(p, 'Kehadiran', a.att, t.attendance, true);
      chk(p, 'Ketepatan Login', a.login, t.login, true);
      chk(p, 'Respon Rate', a.rr, t.rr, true);
      if (a.acd > 0) chk(p, 'AHT', a.aht, t.aht, false, 's');
    });
    return out.sort((x, y) => (x.severity === 'bad' ? 0 : 1) - (y.severity === 'bad' ? 0 : 1));
  }

  /* ---------- PARSING NILAI EXCEL ---------- */
  function excelDate(v) {
    if (v instanceof Date && !isNaN(v)) return toISO(v);
    if (typeof v === 'number' && v > 20000 && v < 80000) { const d = new Date((Math.floor(v + 0.0001) - 25569) * 86400000); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
    if (typeof v === 'string') {
      const s = v.trim(); let m;
      if ((m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/))) return valid(+m[1], +m[2], +m[3]);
      if ((m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/))) return valid(+m[3], +m[2], +m[1]);
    }
    return null;
    function valid(y, mo, d) { const dt = new Date(y, mo - 1, d); return dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d ? toISO(dt) : null; }
  }
  function parseSeconds(v) {
    if (typeof v === 'number') { if (v < 0) return NaN; if (v > 0 && v < 1) return Math.round(v * 86400); return v; }
    if (typeof v === 'string') { const s = v.trim(); if (/^\d+(\.\d+)?$/.test(s.replace(',', '.'))) return parseFloat(s.replace(',', '.')); const m = s.match(/^(\d+):(\d{1,2})(?::(\d{1,2}))?$/); if (m) return m[3] !== undefined ? +m[1] * 3600 + +m[2] * 60 + +m[3] : +m[1] * 60 + +m[2]; }
    return NaN;
  }
  function parseNumber(v) {
    if (typeof v === 'number') return v;
    if (typeof v === 'string') { let s = v.trim().replace(/\s/g, ''); if (s.endsWith('%')) { const n = parseNumber(s.slice(0, -1)); return isNum(n) ? n / 100 : NaN; } if (/^-?\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) s = s.replace(/\./g, '').replace(',', '.'); else s = s.replace(',', '.'); return s !== '' && !isNaN(+s) ? +s : NaN; }
    return NaN;
  }
  // persen: 0-1 => x100 ; 1-100 => apa adanya
  function parsePct(v) { const n = parseNumber(v); if (!isNum(n) || n < 0) return NaN; if (n <= 1) return +(n * 100).toFixed(4); if (n <= 100) return n; return NaN; }

  /* ---------- VALIDATION ENGINE ---------- */
  // ctx: { project:{id,code,name}, period:'YYYY-MM', existingDates:Set, formulas }
  function validateSheet(aoa, ctx) {
    const F = ctx.formulas || DEFAULT_FORMULAS;
    const res = { structureOk: true, structureErrors: [], errors: [], warnings: [], rows: [], totalRows: 0, validRows: 0, errorRows: 0, duplicateRows: 0, missingData: 0, overwriteDates: [] };
    const header = (aoa[0] || []).map(h => h == null ? '' : String(h).trim());
    const expected = TEMPLATE_COLUMNS.map(c => c.h);
    // 2 & 3. nama + jumlah kolom + urutan
    const trimmedHeader = header.slice(); while (trimmedHeader.length && trimmedHeader[trimmedHeader.length - 1] === '') trimmedHeader.pop();
    if (trimmedHeader.length !== expected.length) res.structureErrors.push({ row: 1, col: '-', error: `Jumlah kolom ${trimmedHeader.length}, seharusnya ${expected.length}`, rec: 'Gunakan template standar terbaru tanpa menambah/menghapus kolom.' });
    expected.forEach((h, i) => {
      const got = trimmedHeader[i];
      if (got !== h) {
        const idx = trimmedHeader.indexOf(h);
        res.structureErrors.push({ row: 1, col: colLetter(i), error: idx >= 0 ? `Urutan kolom salah: "${h}" ada di kolom ${colLetter(idx)}` : `Kolom "${h}" tidak ditemukan${got ? ` (ditemukan "${got}")` : ''}`, rec: `Kolom ${colLetter(i)} harus bernama persis "${h}".` });
      }
    });
    if (res.structureErrors.length) { res.structureOk = false; return res; }

    const [py, pm] = ctx.period.split('-').map(Number);
    const seen = new Map();
    for (let i = 1; i < aoa.length; i++) {
      const raw = aoa[i] || [];
      if (raw.every(v => v === null || v === undefined || String(v).trim() === '')) continue;
      res.totalRows++;
      const rowNo = i + 1; const row = { projectId: ctx.project.id }; let rowErr = 0; let missing = false;
      const err = (c, msg, rec) => { res.errors.push({ row: rowNo, col: c.h, error: msg, rec }); rowErr++; };
      const warn = (c, msg, rec) => res.warnings.push({ row: rowNo, col: c.h, error: msg, rec });
      TEMPLATE_COLUMNS.forEach((c, ci) => {
        const v = raw[ci]; const empty = v === null || v === undefined || String(v).trim() === '';
        if (empty) { if (c.req) err(c, 'Field wajib kosong', `Isi kolom ${c.h}.`); else if (['off', 'acd', 'abd', 'scr'].includes(c.k)) missing = true; return; }
        switch (c.t) {
          case 'text': {
            const s = String(v).trim();
            if (c.k === 'project') {
              const okP = [ctx.project.code, ctx.project.id, ctx.project.name].map(x => String(x || '').toUpperCase()).includes(s.toUpperCase());
              if (!okP) err(c, `PROJECT "${s}" tidak sesuai project yang dipilih`, `Isi dengan kode project "${ctx.project.code}".`);
            } else if (s.length > 1000) err(c, 'Teks terlalu panjang (>1000 karakter)', 'Ringkas isi teks.');
            else row[c.k] = s;
            break;
          }
          case 'month': {
            const m = MONTH_ALIASES[String(v).trim().toUpperCase()] || (/^\d{1,2}$/.test(String(v).trim()) ? +v : null);
            if (!m || m < 1 || m > 12) err(c, `MONTH "${v}" tidak valid`, 'Gunakan JAN, FEB, MAR, ... DEC.');
            else if (m !== pm) err(c, `MONTH ${MONTHS[m - 1]} tidak sesuai periode ${MONTHS[pm - 1]} ${py}`, 'Pilih periode yang sesuai atau perbaiki kolom MONTH.');
            row._m = m; break;
          }
          case 'date': {
            const d = excelDate(v);
            if (!d) err(c, `Format tanggal "${v}" tidak valid`, 'Gunakan format tanggal Excel atau YYYY-MM-DD.');
            else if (d.slice(0, 7) !== ctx.period) err(c, `Tanggal ${d} di luar periode ${ymLabel(ctx.period)}`, 'Pastikan semua tanggal berada di bulan periode upload.');
            else row.date = d;
            break;
          }
          case 'day': row._day = String(v).trim(); break;
          case 'int': case 'num': {
            const n = parseNumber(v);
            if (!isNum(n)) err(c, `Nilai "${v}" bukan angka`, 'Isi dengan angka tanpa teks.');
            else if (n < 0) err(c, 'Nilai negatif', 'Nilai tidak boleh negatif.');
            else if (c.t === 'int' && Math.abs(n - Math.round(n)) > 1e-9) { warn(c, `Nilai ${n} dibulatkan`, 'Gunakan bilangan bulat.'); row[c.k] = Math.round(n); }
            else row[c.k] = c.t === 'int' ? Math.round(n) : +n.toFixed(2);
            break;
          }
          case 'pct': {
            const n = parsePct(v);
            if (!isNum(n)) err(c, `Persentase "${v}" tidak valid`, 'Isi 0-1 (format %) atau 0-100.');
            else row[c.k] = +n.toFixed(2);
            break;
          }
          case 'sec': {
            const n = parseSeconds(v);
            if (!isNum(n) || n < 0) err(c, `Durasi "${v}" tidak valid`, 'Isi dalam detik atau format hh:mm:ss.');
            else row[c.k] = +n.toFixed(1);
            break;
          }
        }
      });
      // validasi silang
      if (row.date) {
        const dt = new Date(row.date + 'T00:00:00');
        row.day = DAYS_ID[dt.getDay()];
        if (row._day) { const dd = row._day.toLowerCase(); if (dd !== DAYS_ID[dt.getDay()].toLowerCase() && dd !== DAYS_EN[dt.getDay()]) res.warnings.push({ row: rowNo, col: 'DAY', error: `DAY "${row._day}" tidak sesuai tanggal (${DAYS_ID[dt.getDay()]})`, rec: 'Sistem memakai hari dari tanggal.' }); }
        if (row._m && row._m !== +row.date.slice(5, 7)) res.errors.push({ row: rowNo, col: 'MONTH', error: 'MONTH tidak konsisten dengan DATE', rec: 'Samakan bulan pada kolom MONTH dan DATE.' }), rowErr++;
        if (seen.has(row.date)) { res.errors.push({ row: rowNo, col: 'DATE', error: `Duplikat tanggal ${row.date} (sama dengan baris ${seen.get(row.date)})`, rec: 'Satu project hanya boleh satu baris per tanggal.' }); rowErr++; res.duplicateRows++; }
        else seen.set(row.date, rowNo);
        if (ctx.existingDates && ctx.existingDates.has(row.date)) res.overwriteDates.push(row.date);
      }
      const C = h => TEMPLATE_COLUMNS.find(c => c.h === h);
      if (isNum(row.acd) && isNum(row.off) && row.acd > row.off) { res.errors.push({ row: rowNo, col: C('ACD Call (Inbound)').h, error: `ACD (${row.acd}) > Call Offered (${row.off})`, rec: 'ACD tidak boleh melebihi Call Offered.' }); rowErr++; }
      if (isNum(row.abd) && isNum(row.off) && row.abd > row.off) { res.errors.push({ row: rowNo, col: C('Abandon Call (Inbound)').h, error: `Abandon (${row.abd}) > Call Offered (${row.off})`, rec: 'Abandon tidak boleh melebihi Call Offered.' }); rowErr++; }
      if (isNum(row.acd) && isNum(row.abd) && isNum(row.off) && row.off > 0 && Math.abs(row.acd + row.abd - row.off) / row.off > 0.05) warn(C('Call Offered (Inbound)'), `ACD + Abandon (${row.acd + row.abd}) ≠ Offered (${row.off})`, 'Periksa kembali data inbound (selisih > 5%).');
      if (isNum(row.acc) && isNum(row.acd) && row.acc !== row.acd && F.acceptedFromAcd) warn(C('Accepted Call (Inbound)'), `Accepted (${row.acc}) ≠ ACD (${row.acd})`, 'Sistem akan memakai Accepted = ACD sesuai formula.');
      if (isNum(row.scr) && isNum(row.acd) && isNum(row.off) && row.off > 0 && Math.abs(row.scr - row.acd / row.off * 100) > 1) warn(C('SCR'), `SCR ${fmtPct(row.scr)} ≠ ACD/Offered ${fmtPct(row.acd / row.off * 100)}`, 'Periksa formula SCR di Excel.');
      const chSum = CHANNELS.reduce((a, c) => a + (isNum(row[c.k]) ? row[c.k] : 0), 0);
      if (isNum(row.totdig) && row.totdig !== chSum) warn(C('Total Digital'), `Total Digital ${row.totdig} ≠ jumlah channel ${chSum}`, F.totalDigital === 'computed' ? 'Sistem memakai hasil hitung otomatis.' : 'Sistem memakai nilai upload.');
      const scrV = isNum(row.scr) ? row.scr : null; const tV = isNum(row.tscr) ? row.tscr : null;
      if (scrV !== null && tV !== null && scrV < tV && !row.issue) warn(C('Issue Ketidak tercapaian SCR'), `SCR ${fmtPct(scrV)} di bawah target ${fmtPct(tV)} tanpa keterangan issue`, 'Isi kolom Issue Ketidak tercapaian SCR.');
      if (isNum(row.sdm) && isNum(row.seat) && row.sdm > 0 && (row.seat / row.sdm > 1.5)) warn(C('Jumlah Seat'), 'Seat jauh lebih banyak dari SDM', 'Periksa jumlah seat / SDM.');
      delete row._m; delete row._day;
      if (missing) res.missingData++;
      if (rowErr) res.errorRows++; else { res.validRows++; res.rows.push(computeStored(row, F)); }
    }
    if (res.totalRows === 0) res.errors.push({ row: 2, col: '-', error: 'Tidak ada baris data', rec: 'Isi minimal satu baris data harian.' });
    res.rows.sort((a, b) => a.date < b.date ? -1 : 1);
    return res;
  }
  // nilai yang disimpan ke database: input + hasil auto-calc
  function computeStored(row, F) {
    const c = computeRow(row, F);
    const out = {};
    TEMPLATE_COLUMNS.forEach(col => { if (!['project', 'month'].includes(col.k) && c[col.k] !== undefined && c[col.k] !== null && c[col.k] !== '') out[col.k] = c[col.k]; });
    out.date = c.date; out.day = c.day;
    if (isNum(c.acc)) out.acc = c.acc;
    out.totdig = c.totdigUsed; out.tottraffic = c.trafficUsed;
    if (F.scrSource === 'computed' && isNum(c.scrCalc)) out.scr = +c.scrCalc.toFixed(2);
    return out;
  }
  function colLetter(i) { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; }

  /* ---------- TEMPLATE GENERATOR (SheetJS) ---------- */
  function buildTemplateWorkbook(project, period) {
    const XLSX = window.XLSX;
    const header = TEMPLATE_COLUMNS.map(c => c.h);
    const aoa = [header];
    if (project && period) {
      const [y, m] = period.split('-').map(Number); const days = new Date(y, m, 0).getDate();
      for (let d = 1; d <= days; d++) { const dt = new Date(y, m - 1, d); const r = new Array(header.length).fill(null); r[0] = project.code; r[1] = MONTHS[m - 1]; r[2] = (Date.UTC(y, m - 1, d) - Date.UTC(1899, 11, 30)) / 86400000; r[3] = DAYS_ID[dt.getDay()]; aoa.push(r); }
    }
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = header.map(h => ({ wch: Math.max(12, Math.min(28, h.length + 2)) }));
    ws['!freeze'] = { xSplit: 4, ySplit: 1 };
    for (let r = 1; r < aoa.length; r++) { const ref = XLSX.utils.encode_cell({ r, c: 2 }); if (ws[ref]) ws[ref].z = 'yyyy-mm-dd'; }
    const guide = [['Kolom', 'Nama Kolom (wajib persis)', 'Tipe', 'Wajib', 'Keterangan']].concat(
      TEMPLATE_COLUMNS.map((c, i) => [colLetter(i), c.h, { text: 'Teks', month: 'Bulan', date: 'Tanggal', day: 'Hari', int: 'Angka bulat', num: 'Angka', pct: 'Persentase', sec: 'Durasi (detik)' }[c.t], c.req ? 'Ya' : 'Tidak', c.d || (c.ch ? 'Volume interaksi channel digital' : '')]));
    guide.push([], ['ATURAN'], ['1. Jangan mengubah nama, urutan, atau jumlah kolom pada sheet DATA.'], ['2. Satu baris = satu tanggal untuk satu project. Tidak boleh ada tanggal ganda.'], ['3. Persentase boleh 0-1 (format %) atau 0-100.'], ['4. Total Digital & Total Trafik All dihitung otomatis oleh sistem.'], ['5. Isi Issue Ketidak tercapaian SCR bila SCR di bawah target.']);
    const ws2 = XLSX.utils.aoa_to_sheet(guide); ws2['!cols'] = [{ wch: 7 }, { wch: 44 }, { wch: 16 }, { wch: 7 }, { wch: 60 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'DATA');
    XLSX.utils.book_append_sheet(wb, ws2, 'PETUNJUK');
    if (project) { const ws3 = XLSX.utils.aoa_to_sheet([['PROJECT (kode)', 'Nama Project', 'Periode'], [project.code, project.name, period || '']]); ws3['!cols'] = [{ wch: 20 }, { wch: 40 }, { wch: 12 }]; XLSX.utils.book_append_sheet(wb, ws3, 'MASTER'); }
    return wb;
  }

  window.Core = {
    TEMPLATE_COLUMNS, CHANNELS, MONTHS, MONTHS_ID, DAYS_ID, ROLES, PERMISSIONS, DEFAULT_ROLE_PERMS, DEFAULT_FORMULAS, DEFAULT_KPI,
    isNum, sum, avg, pad, ymOf, toISO, ymLabel, ymShort, fmtInt, fmtNum, fmtPct, fmtCompact, fmtSec, esc, uid, isoWeek, sha256,
    status, STATUS_LABEL, computeRow, aggregate, groupBy, series, qualityBand, buildAlerts,
    excelDate, parsePct, parseNumber, parseSeconds, validateSheet, computeStored, colLetter, buildTemplateWorkbook
  };
})();
