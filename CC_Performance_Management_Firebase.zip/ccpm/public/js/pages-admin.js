/* =========================================================================
 * HALAMAN DATA & ADMINISTRASI:
 * Customer/Project, Data Upload Center, Report Center, User Management,
 * Access Management, Audit Log, System Settings (KPI & formula)
 * ========================================================================= */
(function () {
  'use strict';
  const C = window.Core, U = window.UI, esc = C.esc;
  const Pages = window.Pages = window.Pages || {};
  const A = () => window.App; const PH = () => window.PH;
  const now = () => new Date().toISOString();
  const dt = s => (s || '').slice(0, 16).replace('T', ' ');
  const val = (root, id) => { const e = root.querySelector('#' + id); return e ? e.value.trim() : ''; };

  /* =================== 10. CUSTOMER / PROJECT =================== */
  const STATUSES = ['Active', 'Inactive', 'Onboarding', 'Closed'];
  const stPill = s => U.pill(s === 'Active' ? 'ok' : s === 'Onboarding' ? 'info' : s === 'Closed' ? 'bad' : 'na', s);
  Pages.master = {
    title: 'Customer / Project', icon: 'master', perm: ['dashboard.view', 'customer.manage', 'project.manage'], filters: false,
    render() {
      const App = A(); const tab = App.tabs('master', [['cust', 'Customer'], ['proj', 'Project']]);
      const add = tab.cur === 'cust' ? (App.can('customer.manage') ? `<button class="btn primary" id="m-add">${U.icon('plus')} Tambah Customer</button>` : '') : (App.can('project.manage') ? `<button class="btn primary" id="m-add">${U.icon('plus')} Tambah Project</button>` : '');
      return U.pageHead('Master Data', 'Customer / Project', 'Data customer, project, PIC, kontrak, dan target layanan.', add) + tab.html + U.card('', '<div id="m-table"></div>');
    },
    mount() {
      const App = A(); const cur = App.subTab.master || 'cust'; const addBtn = document.getElementById('m-add');
      if (cur === 'cust') {
        const rows = App.customersInScope().map(c => { const ps = App.data.projects.filter(p => p.customerId === c.id); const rr = App.data.allRows.filter(r => r.customerId === c.id); const a = App.agg(rr); return Object.assign({}, c, { nProj: ps.length, projects: ps, agents: a.sdm, channels: C.CHANNELS.filter(ch => a[ch.k] > 0).length + (a.off > 0 ? 1 : 0) + (a.ob > 0 ? 1 : 0) }); });
        U.dataTable('m-table', [{ k: 'id', label: 'Customer ID' }, { k: 'name', label: 'Customer Name', fmt: (v, r) => `<b>${esc(v)}</b><div class="muted small">${esc(r.contactCenter || '')}</div>` }, { k: 'industry', label: 'Industry' }, { k: 'nProj', label: 'Project', fmt: (v, r) => r.projects.map(p => `<span class="tag">${esc(p.code)}</span>`).join('') || '–' }, { k: 'pic', label: 'PIC', fmt: v => esc(v || '–') }, { k: 'startDate', label: 'Start' }, { k: 'endDate', label: 'Contract End' }, { k: 'status', label: 'Status', fmt: stPill }, { k: 'agents', label: 'Total Agent', r: 1, fmt: C.fmtInt }, { k: 'channels', label: 'Total Channel', r: 1 },
          { k: 'act', label: '', noSort: 1, fmt: (v, r) => `<span class="row" style="flex-wrap:nowrap"><button class="btn sm" data-cdash="${esc(r.id)}">${U.icon('exec')} Dashboard</button>${App.can('customer.manage') ? `<button class="btn sm ghost" data-cedit="${esc(r.id)}" aria-label="Edit">${U.icon('edit')}</button>` : ''}${App.isSuper() ? `<button class="btn sm ghost" data-cdel="${esc(r.id)}" aria-label="Hapus">${U.icon('trash')}</button>` : ''}</span>` }],
          rows, { sortK: 'name', dir: 1, onRender: el => {
            el.querySelectorAll('[data-cdash]').forEach(b => b.addEventListener('click', () => customerDash(b.dataset.cdash)));
            el.querySelectorAll('[data-cedit]').forEach(b => b.addEventListener('click', () => customerForm(App.cust(b.dataset.cedit))));
            el.querySelectorAll('[data-cdel]').forEach(b => b.addEventListener('click', () => delCustomer(b.dataset.cdel)));
          } });
        if (addBtn) addBtn.addEventListener('click', () => customerForm(null));
      } else {
        const rows = App.projectsInScope().map(p => Object.assign({}, p, { cust: App.cust(p.customerId).name, t: App.targets(p.id) }));
        U.dataTable('m-table', [{ k: 'id', label: 'Project ID' }, { k: 'name', label: 'Project Name', fmt: (v, r) => `<b>${esc(v)}</b><div class="muted small">Kode Excel: ${esc(r.code)}</div>` }, { k: 'cust', label: 'Customer' }, { k: 'manager', label: 'Project Manager', fmt: v => esc(v || '–') }, { k: 'sl', label: 'SLA Target', r: 1, sort: r => r.t.sl, fmt: (v, r) => C.fmtPct(r.t.sl) }, { k: 'scr', label: 'SCR Target', r: 1, sort: r => r.t.scr, fmt: (v, r) => C.fmtPct(r.t.scr) }, { k: 'q', label: 'Quality Target', r: 1, sort: r => r.t.quality, fmt: (v, r) => C.fmtNum(r.t.quality) }, { k: 'startDate', label: 'Start' }, { k: 'endDate', label: 'End' }, { k: 'status', label: 'Status', fmt: stPill },
          { k: 'act', label: '', noSort: 1, fmt: (v, r) => `<span class="row" style="flex-wrap:nowrap"><button class="btn sm" data-pdash="${esc(r.id)}">${U.icon('project')} Dashboard</button>${App.can('project.manage') ? `<button class="btn sm ghost" data-pedit="${esc(r.id)}" aria-label="Edit">${U.icon('edit')}</button>` : ''}${App.isSuper() ? `<button class="btn sm ghost" data-pdel="${esc(r.id)}" aria-label="Hapus">${U.icon('trash')}</button>` : ''}</span>` }],
          rows, { sortK: 'name', dir: 1, onRender: el => {
            el.querySelectorAll('[data-pdash]').forEach(b => b.addEventListener('click', () => { App.subTab.projectPick = b.dataset.pdash; App.filter.project = ''; App.go('project'); }));
            el.querySelectorAll('[data-pedit]').forEach(b => b.addEventListener('click', () => projectForm(App.proj(b.dataset.pedit))));
            el.querySelectorAll('[data-pdel]').forEach(b => b.addEventListener('click', () => delProject(b.dataset.pdel)));
          } });
        if (addBtn) addBtn.addEventListener('click', () => projectForm(null));
      }
    }
  };
  function customerDash(cid) {
    const App = A(); const c = App.cust(cid); const rows = App.rows({ ignoreCustomer: true, ignoreProject: true }).filter(r => r.customerId === cid); const a = App.agg(rows);
    const items = [['Total Project', C.fmtInt(App.data.projects.filter(p => p.customerId === cid).length)], ['Total Traffic', C.fmtInt(a.traffic)], ['Total Agent', C.fmtInt(a.sdm)], ['Total Digital Interaction', C.fmtInt(a.totdig)], ['SCR', a.off ? C.fmtPct(a.scr) : '–'], ['SL', C.fmtPct(a.sl)], ['AHT', C.fmtSec(a.aht)], ['Quality Score', C.fmtNum(a.qs)], ['Productivity', C.fmtPct(a.prod)], ['Attendance', C.fmtPct(a.att)], ['Login Accuracy', C.fmtPct(a.login)]];
    U.modal({ title: c.name, wide: true, body: `<p class="muted" style="margin-top:0">${esc(c.industry || '')} · ${esc(c.contactCenter || '')} · Periode ${esc(A().periodLabel())}</p><div class="stat-strip">${items.map(([l, v]) => `<div><span>${l}</span><b>${v}</b></div>`).join('')}</div>${rows.length ? '' : U.empty('Belum ada data performa', '')}` });
  }
  function customerForm(c) {
    const App = A(); const isNew = !c; c = c || { id: '', name: '', industry: 'Kementerian', contactCenter: '', pic: '', startDate: '', endDate: '', status: 'Active' };
    const m = U.modal({ title: isNew ? 'Tambah Customer' : 'Edit Customer', body: `<form class="form-grid" id="cf">
      <div class="field"><label for="c-id">Customer ID</label><input class="input" id="c-id" value="${esc(c.id)}" ${isNew ? '' : 'disabled'} placeholder="CUS-XXX"></div>
      <div class="field"><label for="c-name">Customer Name</label><input class="input" id="c-name" value="${esc(c.name)}"></div>
      <div class="field"><label for="c-ind">Industry</label><input class="input" id="c-ind" value="${esc(c.industry)}" list="c-ind-l"><datalist id="c-ind-l"><option>Kementerian</option><option>Lembaga Pemerintah</option><option>Lembaga Negara</option><option>Penegak Hukum</option><option>BUMN</option></datalist></div>
      <div class="field"><label for="c-cc">Contact Center Name</label><input class="input" id="c-cc" value="${esc(c.contactCenter)}"></div>
      <div class="field"><label for="c-pic">PIC</label><input class="input" id="c-pic" value="${esc(c.pic)}"></div>
      <div class="field"><label for="c-st">Status</label><select class="input" id="c-st">${STATUSES.map(s => `<option ${s === c.status ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
      <div class="field"><label for="c-sd">Start Date</label><input class="input" type="date" id="c-sd" value="${esc(c.startDate)}"></div>
      <div class="field"><label for="c-ed">Contract End Date</label><input class="input" type="date" id="c-ed" value="${esc(c.endDate)}"></div>
      <div class="err-msg full" id="c-err"></div></form>`, foot: `<button class="btn" data-close>Batal</button><button class="btn primary" id="c-save">Simpan</button>` });
    m.el.querySelector('#c-save').addEventListener('click', async () => {
      const r = m.el; const rec = { id: isNew ? val(r, 'c-id').toUpperCase() : c.id, name: val(r, 'c-name'), industry: val(r, 'c-ind'), contactCenter: val(r, 'c-cc'), pic: val(r, 'c-pic'), status: val(r, 'c-st'), startDate: val(r, 'c-sd'), endDate: val(r, 'c-ed') };
      const err = r.querySelector('#c-err');
      if (!/^[A-Z0-9-_]{3,30}$/.test(rec.id)) return err.textContent = 'Customer ID 3-30 karakter (huruf, angka, - atau _).';
      if (isNew && App.data.customers.some(x => x.id === rec.id)) return err.textContent = 'Customer ID sudah dipakai.';
      if (!rec.name) return err.textContent = 'Customer Name wajib diisi.';
      if (rec.startDate && rec.endDate && rec.endDate < rec.startDate) return err.textContent = 'Contract End Date harus setelah Start Date.';
      try { await App.ds.saveCustomer(rec); const i = App.data.customers.findIndex(x => x.id === rec.id); if (i >= 0) App.data.customers[i] = rec; else App.data.customers.push(rec); await App.audit(isNew ? 'Create Customer' : 'Edit Customer', rec.name); m.close(); U.toast('Customer tersimpan.', 'ok'); App.render(); } catch (e) { err.textContent = e.message; }
    });
  }
  async function delCustomer(id) {
    const App = A(); if (App.data.projects.some(p => p.customerId === id)) return U.toast('Customer masih memiliki project. Pindahkan atau hapus project terlebih dahulu.', 'bad');
    if (!await U.confirmBox('Hapus customer', `Hapus customer <b>${esc(App.cust(id).name)}</b>? Tindakan ini tidak dapat dibatalkan.`, 'Hapus')) return;
    try { await App.ds.deleteCustomer(id); App.data.customers = App.data.customers.filter(c => c.id !== id); await App.audit('Delete Customer', id); App.render(); } catch (e) { U.toast(e.message, 'bad'); }
  }
  function projectForm(p) {
    const App = A(); const isNew = !p; p = p || { id: '', code: '', name: '', customerId: App.data.customers[0] ? App.data.customers[0].id : '', description: '', startDate: '', endDate: '', manager: '', status: 'Onboarding' };
    const t = App.targets(p.id);
    const m = U.modal({ title: isNew ? 'Tambah Project' : 'Edit Project', wide: true, body: `<form class="form-grid" id="pf">
      <div class="field"><label for="p-id">Project ID</label><input class="input" id="p-id" value="${esc(p.id)}" ${isNew ? '' : 'disabled'} placeholder="PRJ-XXX"></div>
      <div class="field"><label for="p-code">Kode PROJECT di Excel</label><input class="input" id="p-code" value="${esc(p.code)}" placeholder="mis. BMKG"></div>
      <div class="field"><label for="p-name">Project Name</label><input class="input" id="p-name" value="${esc(p.name)}"></div>
      <div class="field"><label for="p-cust">Customer</label><select class="input" id="p-cust">${App.data.customers.map(c => `<option value="${c.id}" ${c.id === p.customerId ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
      <div class="field full"><label for="p-desc">Description</label><input class="input" id="p-desc" value="${esc(p.description || '')}"></div>
      <div class="field"><label for="p-sd">Start Date</label><input class="input" type="date" id="p-sd" value="${esc(p.startDate)}"></div>
      <div class="field"><label for="p-ed">End Date</label><input class="input" type="date" id="p-ed" value="${esc(p.endDate)}"></div>
      <div class="field"><label for="p-pm">Project Manager</label><input class="input" id="p-pm" value="${esc(p.manager || '')}"></div>
      <div class="field"><label for="p-st">Status</label><select class="input" id="p-st">${STATUSES.map(s => `<option ${s === p.status ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
      <div class="field"><label for="p-sla">SLA Target (%)</label><input class="input" type="number" step="0.1" id="p-sla" value="${t.sl}"></div>
      <div class="field"><label for="p-scr">SCR Target (%)</label><input class="input" type="number" step="0.1" id="p-scr" value="${t.scr}"></div>
      <div class="field"><label for="p-slt">SL Target (%)</label><input class="input" type="number" step="0.1" id="p-slt" value="${t.sl}" disabled title="Sama dengan SLA Target"></div>
      <div class="field"><label for="p-q">Quality Target</label><input class="input" type="number" step="0.1" id="p-q" value="${t.quality}"></div>
      <div class="err-msg full" id="p-err"></div></form>`, foot: `<button class="btn" data-close>Batal</button><button class="btn primary" id="p-save">Simpan</button>` });
    m.el.querySelector('#p-sla').addEventListener('input', e => m.el.querySelector('#p-slt').value = e.target.value);
    m.el.querySelector('#p-save').addEventListener('click', async () => {
      const r = m.el; const err = r.querySelector('#p-err');
      const rec = { id: isNew ? val(r, 'p-id').toUpperCase() : p.id, code: val(r, 'p-code'), name: val(r, 'p-name'), customerId: val(r, 'p-cust'), description: val(r, 'p-desc'), startDate: val(r, 'p-sd'), endDate: val(r, 'p-ed'), manager: val(r, 'p-pm'), status: val(r, 'p-st'), region: p.region || '' };
      if (!/^[A-Z0-9-_]{3,30}$/.test(rec.id)) return err.textContent = 'Project ID 3-30 karakter (huruf, angka, - atau _).';
      if (isNew && App.data.projects.some(x => x.id === rec.id)) return err.textContent = 'Project ID sudah dipakai.';
      if (!rec.code || !rec.name) return err.textContent = 'Kode PROJECT dan Project Name wajib diisi.';
      if (App.data.projects.some(x => x.id !== rec.id && String(x.code).toUpperCase() === rec.code.toUpperCase())) return err.textContent = 'Kode PROJECT sudah dipakai project lain.';
      if (rec.startDate && rec.endDate && rec.endDate < rec.startDate) return err.textContent = 'End Date harus setelah Start Date.';
      const nums = ['p-sla', 'p-scr', 'p-q'].map(id => parseFloat(val(r, id)));
      if (nums.some(n => !C.isNum(n) || n < 0 || n > 100)) return err.textContent = 'Target harus angka 0-100.';
      const kpi = Object.assign({}, App.targets(rec.id), { sl: nums[0], scr: nums[1], quality: nums[2] });
      try {
        await App.ds.saveProject(rec); await App.ds.saveKpiTarget(rec.id, kpi);
        const i = App.data.projects.findIndex(x => x.id === rec.id); if (i >= 0) App.data.projects[i] = rec; else App.data.projects.push(rec); App.data.kpi[rec.id] = kpi;
        await App.audit(isNew ? 'Create Project' : 'Edit Project', rec.name, rec.id); if (!isNew) await App.audit('Change Target', `SCR ${nums[1]} · SL ${nums[0]} · Quality ${nums[2]}`, rec.id);
        App.computeScope(); App.rebuildRows(); m.close(); U.toast('Project tersimpan.', 'ok'); App.render();
      } catch (e) { err.textContent = e.message; }
    });
  }
  async function delProject(id) {
    const App = A(); const keys = Object.keys(App.data.perf).filter(k => App.data.perf[k].projectId === id);
    if (!await U.confirmBox('Hapus project', `Hapus project <b>${esc(App.proj(id).name)}</b> beserta <b>${keys.length}</b> dokumen data performa bulanan? Tindakan ini tidak dapat dibatalkan.`, 'Hapus permanen')) return;
    try { for (const k of keys) { await App.ds.deletePerformanceMonth(k); delete App.data.perf[k]; } await App.ds.deleteProject(id); App.data.projects = App.data.projects.filter(p => p.id !== id); await App.audit('Delete Data', `Project ${id} dan ${keys.length} periode data dihapus`, id); App.computeScope(); App.rebuildRows(); App.render(); U.toast('Project dihapus.', 'ok'); } catch (e) { U.toast(e.message, 'bad'); }
  }

  /* =================== 11. DATA UPLOAD CENTER =================== */
  const UP = { customer: '', project: '', period: '', file: null, result: null, step: 0, overwrite: false, busy: false, done: null, progress: 0 };
  const STEPS = ['Pilih', 'Template', 'Upload', 'Validasi', 'Preview', 'Submit', 'Processing', 'Selesai'];
  Pages.upload = {
    title: 'Data Upload', icon: 'upload', perm: ['upload.data', 'template.download', 'upload.approve'], filters: false,
    render() {
      const App = A(); const tab = App.tabs('upload', [['center', 'Data Upload Center'], ['history', 'Data History']]);
      if (tab.cur === 'history') return U.pageHead('Data Management', 'Data History', 'Riwayat upload, status validasi, dan approval.') + tab.html + U.card('', '<div id="uh-table"></div>');
      const projs = App.projectsInScope().filter(p => !UP.customer || p.customerId === UP.customer);
      if (UP.project && !projs.some(p => p.id === UP.project)) UP.project = '';
      if (!UP.period) { const d = new Date(); UP.period = d.getFullYear() + '-' + C.pad(d.getMonth() + 1); }
      const r = UP.result; const ready = UP.project && UP.period;
      const step = UP.done ? 7 : UP.busy ? 6 : r ? (r.structureOk && !r.errors.length ? 4 : 3) : UP.file ? 2 : ready ? 1 : 0;
      const failed = r && (!r.structureOk || r.errors.length);
      return U.pageHead('Data Management', 'Data Upload Center', 'Upload data harian menggunakan template standar. Data hanya dapat disubmit jika lolos validasi.') + tab.html +
        `<div class="card"><div class="card-b"><div class="steps">${STEPS.map((s, i) => `<div class="step ${i < step ? 'done' : i === step ? (failed && i === 3 ? 'fail' : 'cur') : ''}"><div class="bar"></div>${i + 1}. ${s}</div>`).join('')}</div></div></div>
        <div class="grid">
          ${U.card('1. Pilih customer, project & periode', `<div class="form-grid">
            <div class="field"><label for="u-cust">Customer</label><select class="input" id="u-cust"><option value="">Semua customer</option>${App.customersInScope().map(c => `<option value="${c.id}" ${UP.customer === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
            <div class="field"><label for="u-proj">Project</label><select class="input" id="u-proj"><option value="">Pilih project…</option>${projs.map(p => `<option value="${p.id}" ${UP.project === p.id ? 'selected' : ''}>${esc(p.name)} (${esc(p.code)})</option>`).join('')}</select></div>
            <div class="field"><label for="u-period">Period (Month / Year)</label><input class="input" type="month" id="u-period" value="${UP.period}"></div>
            <div class="field"><label for="u-type">Data Type</label><select class="input" id="u-type"><option>Daily Performance</option></select></div></div>
            <div class="row" style="margin-top:14px">${App.can('template.download') ? `<button class="btn primary" id="u-tpl" ${ready ? '' : 'disabled'}>${U.icon('download')} Download Standard Excel Template</button><button class="btn" id="u-tpl-blank">${U.icon('file')} Template kosong</button>` : ''}</div>
            <p class="muted small" style="margin:10px 0 0">Template berisi ${C.TEMPLATE_COLUMNS.length} kolom wajib dengan nama dan urutan tetap, sheet PETUNJUK, dan baris tanggal yang sudah terisi untuk periode terpilih.</p>`, { span: 's5' })}
          ${U.card('2. Upload file Excel', App.can('upload.data') ? `<label class="drop" id="u-drop" for="u-file">${U.icon('upload')}<div style="margin-top:8px;font-weight:700">${UP.file ? esc(UP.file.name) : 'Tarik file ke sini atau klik untuk memilih'}</div><div class="muted small">${UP.file ? C.fmtNum(UP.file.size / 1024, 1) + ' KB' : '.xlsx / .xls / .csv · maks. 10 MB'}</div></label><input type="file" id="u-file" accept=".xlsx,.xls,.csv" hidden>
            ${!ready ? '<p class="muted small" style="margin:10px 0 0">Pilih project dan periode terlebih dahulu.</p>' : ''}${UP.busy ? `<div style="margin-top:14px"><div class="progress"><i style="width:${UP.progress}%"></i></div><div class="small muted" style="margin-top:6px">Memproses… ${UP.progress}%</div></div>` : ''}` : U.empty('Akses upload tidak tersedia', 'Role Anda hanya dapat mengunduh template.'), { span: 's7' })}
        </div>
        ${UP.done ? successCard() : r ? resultView(r) : ''}`;
    },
    mount() {
      const App = A();
      if ((App.subTab.upload || 'center') === 'history') return historyTable();
      const g = id => document.getElementById(id);
      g('u-cust').addEventListener('change', e => { UP.customer = e.target.value; reset(); App.render(); });
      g('u-proj').addEventListener('change', e => { UP.project = e.target.value; reset(); App.render(); });
      g('u-period').addEventListener('change', e => { UP.period = e.target.value; reset(); App.render(); });
      if (g('u-tpl')) g('u-tpl').addEventListener('click', () => downloadTemplate(true));
      if (g('u-tpl-blank')) g('u-tpl-blank').addEventListener('click', () => downloadTemplate(false));
      const fi = g('u-file'), drop = g('u-drop');
      if (fi) {
        fi.addEventListener('change', () => fi.files[0] && handleFile(fi.files[0]));
        ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
        ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
        drop.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (f) handleFile(f); });
      }
      const sub = g('u-submit'); if (sub) sub.addEventListener('click', submitUpload);
      const ow = g('u-ow'); if (ow) ow.addEventListener('change', e => { UP.overwrite = e.target.checked; App.render(); });
      const er = g('u-errdl'); if (er) er.addEventListener('click', () => errorReport(UP.result.errors.concat(UP.result.structureErrors), UP.result.warnings, UP.file ? UP.file.name : 'upload'));
      const again = g('u-again'); if (again) again.addEventListener('click', () => { reset(); UP.done = null; App.render(); });
      const view = g('u-view'); if (view) view.addEventListener('click', () => { App.filter = Object.assign(App.filter, { project: UP.done.projectId, customer: '', month: UP.done.period, from: '', to: '' }); reset(); UP.done = null; App.subTab.projectPick = App.filter.project; App.go('project'); });
      if (UP.result && UP.result.structureOk) {
        if (UP.result.errors.length) U.dataTable('u-errors', errCols(), UP.result.errors, { pageSize: 10 });
        if (UP.result.warnings.length) U.dataTable('u-warn', errCols(), UP.result.warnings, { pageSize: 8 });
        if (UP.result.rows.length) U.dataTable('u-preview', [{ k: 'date', label: 'DATE' }, { k: 'day', label: 'DAY' }, { k: 'off', label: 'Offered', r: 1, fmt: C.fmtInt }, { k: 'acd', label: 'ACD', r: 1, fmt: C.fmtInt }, { k: 'acc', label: 'Accepted', r: 1, fmt: C.fmtInt }, { k: 'abd', label: 'Abandon', r: 1, fmt: C.fmtInt }, { k: 'scr', label: 'SCR', r: 1, fmt: v => C.fmtPct(v) }, { k: 'aht', label: 'AHT', r: 1, fmt: C.fmtSec }, { k: 'totdig', label: 'Total Digital*', r: 1, fmt: C.fmtInt }, { k: 'tottraffic', label: 'Total Trafik All*', r: 1, fmt: C.fmtInt }, { k: 'qs', label: 'Quality', r: 1, fmt: v => C.fmtNum(v) }, { k: 'att', label: 'Kehadiran', r: 1, fmt: v => C.fmtPct(v) }], UP.result.rows, { pageSize: 10, search: false });
      } else if (UP.result) U.dataTable('u-struct', errCols(), UP.result.structureErrors, { noPaging: true, search: false });
    }
  };
  const errCols = () => [{ k: 'row', label: 'Row', r: 1 }, { k: 'col', label: 'Column' }, { k: 'error', label: 'Error', wrap: 1 }, { k: 'rec', label: 'Recommendation', wrap: 1 }];
  function reset() { UP.file = null; UP.result = null; UP.overwrite = false; UP.busy = false; UP.progress = 0; }
  async function downloadTemplate(prefill) {
    const App = A(); const p = prefill ? App.proj(UP.project) : null;
    const wb = C.buildTemplateWorkbook(p, prefill ? UP.period : null);
    const name = prefill ? `Template_Daily_Performance_${p.code}_${UP.period}.xlsx` : 'Template_Daily_Performance.xlsx';
    if (await U.saveFile(name.replace(/\s+/g, '_'), U.workbookBlob(wb))) { App.audit('Download Template', name, p ? p.id : ''); U.toast('Template diunduh.', 'ok'); }
  }
  async function handleFile(file) {
    const App = A(); reset(); UP.file = file;
    if (!/\.(xlsx|xls|csv)$/i.test(file.name)) { UP.result = { structureOk: false, structureErrors: [{ row: '-', col: '-', error: 'Format file tidak didukung', rec: 'Gunakan file .xlsx dari template standar.' }], errors: [], warnings: [], rows: [] }; return App.render(); }
    if (file.size > 10 * 1024 * 1024) { UP.result = { structureOk: false, structureErrors: [{ row: '-', col: '-', error: 'Ukuran file melebihi 10 MB', rec: 'Pisahkan data per bulan / per project.' }], errors: [], warnings: [], rows: [] }; return App.render(); }
    if (!UP.project || !UP.period) { U.toast('Pilih project dan periode terlebih dahulu.', 'bad'); UP.file = null; return App.render(); }
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: 'array', cellDates: false });
      const sheetName = wb.SheetNames.includes('DATA') ? 'DATA' : wb.SheetNames[0];
      const aoa = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { header: 1, raw: true, defval: null, blankrows: false });
      const key = UP.project + '_' + UP.period; const ex = App.data.perf[key];
      const res = C.validateSheet(aoa, { project: App.proj(UP.project), period: UP.period, existingDates: new Set(ex ? ex.rows.map(r => r.date) : []), formulas: App.F() });
      res.sheetName = sheetName; res.validatedAt = now(); UP.result = res;
    } catch (e) { UP.result = { structureOk: false, structureErrors: [{ row: '-', col: '-', error: 'File tidak dapat dibaca: ' + e.message, rec: 'Pastikan file tidak terkunci password atau rusak.' }], errors: [], warnings: [], rows: [] }; }
    App.render();
  }
  function resultView(r) {
    const App = A(); const p = App.proj(UP.project);
    if (!r.structureOk) return U.card('Hasil validasi', `<div class="alert-row bad"><span class="ic">${U.icon('alert')}</span><div><b>Template tidak sesuai. Silakan download template terbaru.</b><div class="muted small">${r.structureErrors.length} masalah struktur ditemukan. Data tidak diproses.</div></div></div><div id="u-struct" style="margin-top:10px"></div><div class="row" style="margin-top:12px"><button class="btn" id="u-errdl">${U.icon('download')} Download Error Report</button></div>`);
    const ok = !r.errors.length && r.rows.length; const needOw = r.overwriteDates.length > 0;
    const canSubmit = ok && (!needOw || UP.overwrite) && App.can('upload.data');
    return `<div class="grid">${U.card('Upload Summary', `<div class="stat-strip">
        <div><span>File Name</span><b style="font-size:13px">${esc(UP.file.name)}</b></div><div><span>Project</span><b style="font-size:13px">${esc(p.name)}</b></div><div><span>Period</span><b>${esc(C.ymLabel(UP.period))}</b></div>
        <div><span>Total Rows</span><b>${r.totalRows}</b></div><div><span>Valid Rows</span><b style="color:var(--ok)">${r.validRows}</b></div><div><span>Error Rows</span><b style="color:var(--${r.errorRows ? 'bad' : 'text'})">${r.errorRows}</b></div>
        <div><span>Duplicate Rows</span><b>${r.duplicateRows}</b></div><div><span>Missing Data</span><b>${r.missingData}</b></div><div><span>Warnings</span><b style="color:var(--${r.warnings.length ? 'risk' : 'text'})">${r.warnings.length}</b></div>
        <div><span>Upload Time</span><b style="font-size:13px">${dt(r.validatedAt)}</b></div><div><span>Uploaded By</span><b style="font-size:13px">${esc(App.profile.name)}</b></div></div>
        <div style="margin-top:14px">${ok ? `<div class="alert-row info"><span class="ic">${U.icon('check')}</span><div><b>Validasi lolos.</b> ${r.validRows} baris siap disubmit${r.warnings.length ? `, dengan ${r.warnings.length} catatan (tidak memblokir submit)` : ''}.</div></div>` : `<div class="alert-row bad"><span class="ic">${U.icon('alert')}</span><div><b>${r.errors.length} error ditemukan.</b> Perbaiki file lalu upload ulang. Data hanya dapat disubmit jika seluruh baris valid.</div></div>`}
        ${needOw ? `<label class="check" style="margin-top:8px"><input type="checkbox" id="u-ow" ${UP.overwrite ? 'checked' : ''}> ${r.overwriteDates.length} tanggal sudah ada di database untuk project & periode ini. Timpa data lama (data lama disimpan sebagai snapshot untuk rollback).</label>` : ''}</div>
        <div class="row" style="margin-top:14px">${r.errors.length || r.warnings.length ? `<button class="btn" id="u-errdl">${U.icon('download')} Download Error Report</button>` : ''}<button class="btn primary" id="u-submit" ${canSubmit && !UP.busy ? '' : 'disabled'}>${U.icon('check')} Submit data</button></div>`)}
      ${r.errors.length ? U.card(`Error (${r.errors.length})`, '<div id="u-errors"></div>') : ''}
      ${r.warnings.length ? U.card(`Catatan validasi (${r.warnings.length})`, '<div id="u-warn"></div>', { hint: 'Tidak memblokir submit' }) : ''}
      ${r.rows.length ? U.card('Preview data valid', '<div id="u-preview"></div>', { hint: '* dihitung otomatis oleh sistem' }) : ''}</div>`;
  }
  function successCard() {
    const d = UP.done;
    return U.card('Upload berhasil', `<div class="alert-row info"><span class="ic">${U.icon('check')}</span><div><b>${d.validRows} baris data ${esc(d.projectName)} periode ${esc(C.ymLabel(d.period))} tersimpan.</b><div class="muted small">Status: ${esc(d.status)} · ${d.stored ? 'File asli tersimpan di storage.' : esc(d.storageNote || '')} Dashboard sudah diperbarui.</div></div></div><div class="row" style="margin-top:12px"><button class="btn primary" id="u-view">${U.icon('project')} Lihat dashboard project</button><button class="btn" id="u-again">Upload file lain</button></div>`);
  }
  async function submitUpload() {
    const App = A(); const r = UP.result; if (!r || r.errors.length || !r.rows.length || UP.busy) return;
    if (r.overwriteDates.length && !UP.overwrite) return U.toast('Centang opsi timpa data terlebih dahulu.', 'bad');
    UP.busy = true; UP.progress = 10; App.render();
    const p = App.proj(UP.project); const key = UP.project + '_' + UP.period; const id = C.uid('up');
    try {
      const st = await App.ds.uploadFile(UP.file, `uploads/${p.id}/${UP.period}/${Date.now()}_${UP.file.name.replace(/[^\w.\-]/g, '_')}`);
      UP.progress = 40; App.render();
      const existing = App.data.perf[key] || (App.isCorporate() ? await App.ds.getPerformanceMonth(key) : null);
      const exRows = existing ? existing.rows : [];
      const newDates = new Set(r.rows.map(x => x.date));
      const prevRows = exRows.filter(x => newDates.has(x.date));
      const merged = exRows.filter(x => !newDates.has(x.date)).concat(r.rows).sort((a, b) => a.date.localeCompare(b.date));
      const doc = { id: key, projectId: p.id, customerId: p.customerId, period: UP.period, rows: merged, source: 'upload', uploadId: id, updatedAt: now(), updatedBy: App.profile.name };
      await App.ds.savePerformanceMonth(doc); UP.progress = 70; App.render();
      const rec = { id, fileName: UP.file.name, fileSize: UP.file.size, storagePath: st.path, fileUrl: st.url || null, projectId: p.id, projectName: p.name, customerId: p.customerId, period: UP.period, dataType: 'Daily Performance', totalRows: r.totalRows, validRows: r.validRows, errorRows: r.errorRows, duplicateRows: r.duplicateRows, missingData: r.missingData, warnings: r.warnings.length, uploadedAt: now(), uploadedBy: App.profile.name, uploadedById: App.profile.id, status: App.can('upload.approve') ? 'Approved' : 'Valid', rows: r.rows, prevRows, overwrote: prevRows.length };
      await App.ds.saveUpload(rec);
      if (r.warnings.length) await App.ds.saveUploadErrors(id, { projectId: p.id, list: r.warnings.map(w => Object.assign({ severity: 'warning' }, w)) });
      await App.audit('Upload Excel', `${UP.file.name} · ${r.validRows} baris · ${C.ymLabel(UP.period)}${prevRows.length ? ` · menimpa ${prevRows.length} tanggal` : ''}`, p.id);
      App.data.perf[key] = doc; App.data.uploads.unshift(rec); App.rebuildRows(); UP.progress = 100;
      UP.done = Object.assign({}, rec, { stored: st.stored, storageNote: st.note }); UP.busy = false; App.render(); U.toast('Data berhasil disubmit. Dashboard diperbarui.', 'ok');
    } catch (e) { UP.busy = false; App.render(); U.toast('Submit gagal: ' + e.message, 'bad'); await App.audit('Upload Excel', `${UP.file.name}: ${e.message}`, p.id, 'Failed'); }
  }
  async function errorReport(errors, warnings, fname) {
    const rows = [['Severity', 'Row', 'Column', 'Error', 'Recommendation']].concat(errors.map(e => ['Error', e.row, e.col, e.error, e.rec]), (warnings || []).map(e => ['Warning', e.row, e.col, e.error, e.rec]));
    const ws = XLSX.utils.aoa_to_sheet(rows); ws['!cols'] = [{ wch: 9 }, { wch: 6 }, { wch: 32 }, { wch: 60 }, { wch: 60 }];
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, 'Error Report');
    await U.saveFile('Error_Report_' + fname.replace(/\.[^.]+$/, '') + '.xlsx', U.workbookBlob(wb));
  }
  function historyTable() {
    const App = A(); const canAp = App.can('upload.approve'), canDel = App.can('data.delete');
    const list = App.data.uploads.slice().sort((a, b) => (b.uploadedAt || '').localeCompare(a.uploadedAt || ''));
    const stCls = { Processing: 'info', Valid: 'info', Error: 'bad', Approved: 'ok', Rejected: 'bad' };
    U.dataTable('uh-table', [{ k: 'uploadedAt', label: 'Upload Date', fmt: dt }, { k: 'projectName', label: 'Project' }, { k: 'period', label: 'Period' }, { k: 'fileName', label: 'File', wrap: 1 }, { k: 'validRows', label: 'Rows', r: 1 }, { k: 'uploadedBy', label: 'Uploaded By' }, { k: 'status', label: 'Status', fmt: v => U.pill(stCls[v] || 'na', v) },
      { k: 'id', label: 'Action', noSort: 1, fmt: (v, r) => `<span class="row" style="flex-wrap:nowrap"><button class="btn sm" data-hv="${v}">${U.icon('eye')} View</button>${r.id !== 'up-seed' && canAp ? `<button class="btn sm ghost" data-hr="${v}" title="Reprocess">${U.icon('refresh')}</button>${r.status !== 'Approved' ? `<button class="btn sm ghost" data-ha="${v}" title="Approve">${U.icon('check')}</button>` : ''}${r.status !== 'Rejected' ? `<button class="btn sm ghost" data-hj="${v}" title="Reject">${U.icon('x')}</button>` : ''}` : ''}${r.id !== 'up-seed' && canDel ? `<button class="btn sm ghost" data-hd="${v}" title="Delete">${U.icon('trash')}</button>` : ''}</span>` }],
      list, { sortK: 'uploadedAt', emptyMsg: 'Belum ada riwayat upload.', onRender: el => {
        const find = id => App.data.uploads.find(u => u.id === id);
        el.querySelectorAll('[data-hv]').forEach(b => b.addEventListener('click', () => viewUpload(find(b.dataset.hv))));
        el.querySelectorAll('[data-hr]').forEach(b => b.addEventListener('click', () => reprocess(find(b.dataset.hr))));
        el.querySelectorAll('[data-ha]').forEach(b => b.addEventListener('click', () => setStatus(find(b.dataset.ha), 'Approved')));
        el.querySelectorAll('[data-hj]').forEach(b => b.addEventListener('click', () => rejectUpload(find(b.dataset.hj), false)));
        el.querySelectorAll('[data-hd]').forEach(b => b.addEventListener('click', () => rejectUpload(find(b.dataset.hd), true)));
      } });
  }
  async function viewUpload(u) {
    const App = A(); let errs = []; try { errs = await App.ds.getUploadErrors(u.id); } catch (e) { }
    const m = U.modal({ title: 'Detail upload', wide: true, body: `<div class="stat-strip">${[['File', u.fileName], ['Project', u.projectName], ['Period', u.period], ['Total Rows', u.totalRows], ['Valid Rows', u.validRows], ['Error Rows', u.errorRows], ['Duplicate', u.duplicateRows], ['Missing Data', u.missingData], ['Uploaded By', u.uploadedBy], ['Upload Time', dt(u.uploadedAt)], ['Status', u.status], ['Overwrite', (u.overwrote || 0) + ' tanggal']].map(([l, v]) => `<div><span>${l}</span><b style="font-size:13px">${esc(v ?? '–')}</b></div>`).join('')}</div>
      ${u.fileUrl ? `<p><a href="${esc(u.fileUrl)}" target="_blank" rel="noopener">Buka file asli di storage</a></p>` : ''}${u.note ? `<p class="muted">${esc(u.note)}</p>` : ''}
      <h4 style="margin:14px 0 6px">Catatan validasi (${errs.length})</h4><div id="vu-err"></div>`, foot: errs.length ? `<button class="btn" id="vu-dl">${U.icon('download')} Download Error Report</button>` : '' });
    U.dataTable(m.el.querySelector('#vu-err'), [{ k: 'severity', label: 'Severity', fmt: v => U.pill(v === 'warning' ? 'risk' : 'bad', v || 'error') }].concat(errCols()), errs, { pageSize: 8, search: false, emptyMsg: 'Tidak ada error atau catatan.' });
    const b = m.el.querySelector('#vu-dl'); if (b) b.addEventListener('click', () => errorReport(errs.filter(e => e.severity !== 'warning'), errs.filter(e => e.severity === 'warning'), u.fileName));
  }
  async function setStatus(u, status, extra) {
    const App = A(); const rec = Object.assign({}, u, { status, reviewedBy: App.profile.name, reviewedAt: now() }, extra || {});
    await App.ds.saveUpload(rec); const i = App.data.uploads.findIndex(x => x.id === u.id); App.data.uploads[i] = rec;
    await App.audit(status === 'Approved' ? 'Approve Upload' : status === 'Rejected' ? 'Reject Upload' : 'Edit Data', `${u.fileName} (${u.period})`, u.projectId);
    U.toast(`Upload ${status.toLowerCase()}.`, 'ok'); App.render();
  }
  async function restoreMonth(u) {
    const App = A(); const key = u.projectId + '_' + u.period; const doc = App.data.perf[key] || await App.ds.getPerformanceMonth(key); if (!doc) return;
    const dates = new Set((u.rows || []).map(r => r.date));
    const rows = doc.rows.filter(r => !dates.has(r.date)).concat(u.prevRows || []).sort((a, b) => a.date.localeCompare(b.date));
    if (rows.length) { const nd = Object.assign({}, doc, { rows, updatedAt: now(), updatedBy: App.profile.name, source: 'rollback' }); await App.ds.savePerformanceMonth(nd); App.data.perf[key] = nd; }
    else { await App.ds.deletePerformanceMonth(key); delete App.data.perf[key]; }
    App.rebuildRows();
  }
  async function rejectUpload(u, del) {
    const App = A();
    if (!await U.confirmBox(del ? 'Hapus upload' : 'Reject upload', `${del ? 'Hapus' : 'Reject'} upload <b>${esc(u.fileName)}</b>? ${u.status !== 'Rejected' ? `${(u.rows || []).length} baris data akan dikeluarkan dari dashboard${(u.prevRows || []).length ? ` dan ${(u.prevRows || []).length} baris data sebelumnya dipulihkan` : ''}.` : ''}`, del ? 'Hapus' : 'Reject')) return;
    try {
      if (u.status !== 'Rejected') await restoreMonth(u);
      if (del) { await App.ds.deleteUpload(u.id); App.data.uploads = App.data.uploads.filter(x => x.id !== u.id); await App.audit('Delete Data', `Upload ${u.fileName} (${u.period}) dihapus`, u.projectId); U.toast('Upload dihapus.', 'ok'); App.render(); }
      else await setStatus(u, 'Rejected');
    } catch (e) { U.toast(e.message, 'bad'); }
  }
  async function reprocess(u) {
    const App = A(); if (u.status === 'Rejected') return U.toast('Upload yang sudah di-reject tidak dapat diproses ulang.', 'bad');
    try {
      const F = App.F(); const rows = (u.rows || []).map(r => C.computeStored(r, F));
      const key = u.projectId + '_' + u.period; const doc = App.data.perf[key] || await App.ds.getPerformanceMonth(key);
      const dates = new Set(rows.map(r => r.date)); const merged = (doc ? doc.rows.filter(r => !dates.has(r.date)) : []).concat(rows).sort((a, b) => a.date.localeCompare(b.date));
      const nd = Object.assign({ id: key, projectId: u.projectId, customerId: u.customerId, period: u.period }, doc || {}, { rows: merged, updatedAt: now(), updatedBy: App.profile.name, uploadId: u.id });
      await App.ds.savePerformanceMonth(nd); App.data.perf[key] = nd; App.rebuildRows();
      await setStatus(u, u.status, { rows, reprocessedAt: now() }); await App.audit('Reprocess Upload', `${u.fileName} diproses ulang dengan formula terbaru`, u.projectId);
    } catch (e) { U.toast(e.message, 'bad'); }
  }

  /* =================== 12. REPORT CENTER =================== */
  const RTYPES = [['daily', 'Daily Report'], ['weekly', 'Weekly Report'], ['monthly', 'Monthly Report'], ['project', 'Project Report'], ['customer', 'Customer Report'], ['corporate', 'Corporate Report'], ['quality', 'Quality Report'], ['workforce', 'Workforce Report'], ['digital', 'Digital Channel Report']];
  const FORMATS = [['xlsx', 'Excel'], ['csv', 'CSV'], ['pdf', 'PDF'], ['pptx', 'PowerPoint']];
  const RS = { type: 'corporate', format: 'xlsx', report: null };
  function buildReport(type) {
    const App = A(); const rows = App.rows(); const a = App.agg(rows); const F = App.F();
    const title = (RTYPES.find(t => t[0] === type) || [])[1]; const sub = `${App.periodLabel()} · ${App.filter.project ? App.proj(App.filter.project).name : App.filter.customer ? App.cust(App.filter.customer).name : 'Semua project dalam akses'}`;
    const kpis = [['Total Traffic', C.fmtInt(a.traffic)], ['Call Offered', C.fmtInt(a.off)], ['SCR', C.fmtPct(a.scr)], ['SL', C.fmtPct(a.sl)], ['AHT', C.fmtSec(a.aht)], ['Total Digital', C.fmtInt(a.totdig)], ['Quality', C.fmtNum(a.qs)], ['Attendance', C.fmtPct(a.att)]];
    const perfCols = ['Periode', 'Call Offered', 'Accepted', 'Abandon', 'SCR %', 'SL %', 'AHT (dtk)', 'Outbound', 'Total Digital', 'Total Traffic'];
    const perfRow = (k, x) => [k, x.off, x.acc, x.abd, r1(x.scr), r1(x.sl), r1(x.aht), x.ob, x.totdig, x.traffic];
    const projCols = ['Project', 'Customer', 'Traffic', 'SCR %', 'Target SCR', 'Status SCR', 'SL %', 'AHT (dtk)', 'Digital', 'Quality', 'Attendance %'];
    const projRow = x => { const t = App.targets(x.project.id); return [x.project.name, App.cust(x.project.customerId).name, x.agg.traffic, x.agg.off ? r1(x.agg.scr) : null, t.scr, x.agg.off ? C.STATUS_LABEL[C.status(x.agg.scr, t.scr, true, F)] : '–', r1(x.agg.sl), r1(x.agg.aht), x.agg.totdig, r1(x.agg.qs), r1(x.agg.att)]; };
    const pp = App.perProject(rows); const tables = [];
    if (type === 'daily') tables.push({ name: 'Harian', columns: perfCols, rows: App.series(rows, 'date').map(x => perfRow(x.key, x)) });
    if (type === 'weekly') tables.push({ name: 'Mingguan', columns: perfCols, rows: App.series(rows, 'week').map(x => perfRow(x.key, x)) });
    if (type === 'monthly' || type === 'corporate') tables.push({ name: 'Bulanan', columns: perfCols, rows: App.series(rows).map(x => perfRow(C.ymLabel(x.key), x)) });
    if (type === 'project' || type === 'corporate') tables.push({ name: 'Per Project', columns: projCols, rows: pp.map(projRow) });
    if (type === 'project') pp.forEach(x => tables.push({ name: x.project.code.slice(0, 28), columns: ['Tanggal'].concat(C.TEMPLATE_COLUMNS.slice(4).map(c => c.h)), rows: x.rows.map(r => [r.date].concat(C.TEMPLATE_COLUMNS.slice(4).map(c => c.k === 'totdig' ? r.totdigUsed : c.k === 'tottraffic' ? r.trafficUsed : c.k === 'scr' ? r.scrUsed : r[c.k] ?? null))) }));
    if (type === 'customer') { const g = C.groupBy(rows, r => r.customerId); tables.push({ name: 'Per Customer', columns: ['Customer', 'Project', 'Traffic', 'SCR %', 'SL %', 'AHT (dtk)', 'Digital', 'Quality', 'Agent'], rows: [...g.entries()].map(([cid, rr]) => { const x = App.agg(rr); return [App.cust(cid).name, x.projects, x.traffic, x.off ? r1(x.scr) : null, r1(x.sl), r1(x.aht), x.totdig, r1(x.qs), x.sdm]; }) }); }
    if (type === 'corporate') { const al = App.alerts(); tables.push({ name: 'Alert', columns: ['Project', 'KPI', 'Severity', 'Keterangan'], rows: al.map(x => [x.project, x.kpi, C.STATUS_LABEL[x.severity], x.text]) }); }
    if (type === 'quality') { tables.push({ name: 'Quality per Project', columns: ['Project', 'Quality', 'Target', 'Status', 'Product Knowledge', 'Productivity %'], rows: pp.filter(x => C.isNum(x.agg.qs) || C.isNum(x.agg.pk)).map(x => { const t = App.targets(x.project.id); return [x.project.name, r1(x.agg.qs), t.quality, C.STATUS_LABEL[C.status(x.agg.qs, t.quality, true, F)], r1(x.agg.pk), r1(x.agg.prod)]; }) }); tables.push({ name: 'Agent', columns: ['Agent', 'Project', 'Channel', 'Rata-rata QM', 'Kategori'], rows: App.data.agents.filter(ag => pp.some(x => x.project.id === ag.projectId)).map(ag => { const v = C.avg(Object.entries(ag.qs || {}).filter(([m]) => rows.some(r => r.ym === m)).map(e => e[1])); return [ag.name, App.proj(ag.projectId).code, ag.channel, r1(v), C.qualityBand(v, F) || '–']; }).filter(r => r[3] !== null) }); }
    if (type === 'workforce') tables.push({ name: 'Workforce', columns: ['Project', 'Seat', 'SDM', 'Utilisasi %', 'Attendance %', 'Login Accuracy %', 'Productivity %'], rows: pp.map(x => [x.project.name, x.agg.seat, x.agg.sdm, x.agg.seat ? r1(x.agg.sdm / x.agg.seat * 100) : null, r1(x.agg.att), r1(x.agg.login), r1(x.agg.prod)]) });
    if (type === 'digital') { const tot = a.totdig; tables.push({ name: 'Per Channel', columns: ['Channel', 'Volume', 'Kontribusi %'], rows: C.CHANNELS.map(c => [c.label, a[c.k], tot ? r1(a[c.k] / tot * 100) : null]).filter(r => r[1] > 0).sort((x, y) => y[1] - x[1]) }); tables.push({ name: 'Digital per Project', columns: ['Project', 'Total Digital', 'Response Time (dtk)', 'Handling Time (dtk)', 'Response Rate %'], rows: pp.filter(x => x.agg.totdig > 0).map(x => [x.project.name, x.agg.totdig, r1(x.agg.rt), r1(x.agg.ht), r1(x.agg.rr)]) }); }
    return { type, title, sub, kpis, tables, generatedAt: now(), generatedBy: A().profile.name };
  }
  const r1 = v => C.isNum(v) ? Math.round(v * 10) / 10 : null;
  async function exportReport(rep, format) {
    const App = A(); const base = `${rep.title.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}`;
    let blob, name;
    if (format === 'xlsx' || format === 'csv') {
      if (format === 'xlsx') {
        const wb = XLSX.utils.book_new();
        const sum = [[rep.title], [rep.sub], ['Dibuat', dt(rep.generatedAt) + ' oleh ' + rep.generatedBy], [], ['KPI', 'Nilai']].concat(rep.kpis);
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(sum), 'Ringkasan');
        rep.tables.forEach((t, i) => { const ws = XLSX.utils.aoa_to_sheet([t.columns].concat(t.rows)); ws['!cols'] = t.columns.map(c => ({ wch: Math.max(10, Math.min(40, String(c).length + 4)) })); XLSX.utils.book_append_sheet(wb, ws, (t.name || 'Data' + i).replace(/[\\/?*[\]:]/g, '').slice(0, 31)); });
        blob = U.workbookBlob(wb); name = base + '.xlsx';
      } else {
        const q = v => { const s = v == null ? '' : String(v); return /[",;\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
        const lines = [q(rep.title), q(rep.sub), ''].concat(...rep.tables.map(t => [q(t.name), t.columns.map(q).join(','), ...t.rows.map(r => r.map(q).join(',')), '']));
        blob = new Blob(['﻿' + lines.join('\n')], { type: 'text/csv;charset=utf-8' }); name = base + '.csv';
      }
    } else if (format === 'pdf') {
      await U.loadScript('https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js'); await U.loadScript('https://cdn.jsdelivr.net/npm/jspdf-autotable@3.8.2/dist/jspdf.plugin.autotable.min.js');
      const doc = new window.jspdf.jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4' });
      doc.setFillColor(10, 26, 51); doc.rect(0, 0, 842, 64, 'F'); doc.setTextColor(255, 255, 255); doc.setFontSize(16); doc.text(rep.title, 32, 30); doc.setFontSize(9); doc.text(rep.sub, 32, 48);
      doc.setTextColor(30, 40, 60); doc.autoTable({ startY: 80, head: [rep.kpis.map(k => k[0])], body: [rep.kpis.map(k => k[1])], theme: 'grid', styles: { fontSize: 9, halign: 'center' }, headStyles: { fillColor: [31, 91, 216] } });
      rep.tables.forEach(t => { const cut = t.columns.length > 14; const cols = cut ? t.columns.slice(0, 14) : t.columns; doc.autoTable({ startY: doc.lastAutoTable.finalY + 22, head: [cols], body: t.rows.map(r => (cut ? r.slice(0, 14) : r).map(v => v == null ? '–' : typeof v === 'number' ? v.toLocaleString('id-ID') : String(v).slice(0, 120))), theme: 'striped', styles: { fontSize: 7.5, cellPadding: 3 }, headStyles: { fillColor: [18, 40, 75] }, didDrawPage: () => { doc.setFontSize(8); doc.setTextColor(120); doc.text(`${window.APP_CONFIG.appName} · dibuat ${dt(rep.generatedAt)}`, 32, 580); } }); doc.setFontSize(10); });
      blob = doc.output('blob'); name = base + '.pdf';
    } else {
      await U.loadScript('https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js');
      const pptx = new window.PptxGenJS(); pptx.layout = 'LAYOUT_WIDE';
      let s = pptx.addSlide(); s.background = { color: '0A1A33' }; s.addText(rep.title, { x: .6, y: 2.4, w: 12, h: 1, fontSize: 36, bold: true, color: 'FFFFFF', fontFace: 'Arial' }); s.addText(rep.sub, { x: .6, y: 3.4, w: 12, h: .6, fontSize: 16, color: 'A9B8D0' }); s.addText(window.APP_CONFIG.corporateName + ' · ' + dt(rep.generatedAt), { x: .6, y: 6.6, w: 12, h: .4, fontSize: 11, color: '7C90B0' });
      s = pptx.addSlide(); s.addText('Ringkasan KPI', { x: .5, y: .3, w: 12, h: .6, fontSize: 24, bold: true, color: '0E1A2C' });
      rep.kpis.forEach((k, i) => { const x = .5 + (i % 4) * 3.1, y = 1.3 + Math.floor(i / 4) * 2.2; s.addShape(pptx.ShapeType.roundRect, { x, y, w: 2.9, h: 1.9, fill: { color: 'F3F5F9' }, line: { color: 'E2E7EF' }, rectRadius: .08 }); s.addText(k[0].toUpperCase(), { x: x + .2, y: y + .2, w: 2.5, h: .4, fontSize: 11, color: '5A6A80', bold: true }); s.addText(String(k[1]), { x: x + .2, y: y + .7, w: 2.5, h: .8, fontSize: 26, bold: true, color: '1F5BD8' }); });
      rep.tables.forEach(t => { const cols = t.columns.slice(0, 10); for (let i = 0; i < Math.max(1, t.rows.length); i += 12) { const sl = pptx.addSlide(); sl.addText(t.name + (t.rows.length > 12 ? ` (${i / 12 + 1}/${Math.ceil(t.rows.length / 12)})` : ''), { x: .5, y: .3, w: 12, h: .6, fontSize: 20, bold: true, color: '0E1A2C' }); const body = t.rows.slice(i, i + 12).map(r => r.slice(0, 10).map(v => ({ text: v == null ? '–' : typeof v === 'number' ? v.toLocaleString('id-ID') : String(v).slice(0, 60) }))); sl.addTable([cols.map(c => ({ text: String(c), options: { bold: true, color: 'FFFFFF', fill: { color: '12284B' } } }))].concat(body), { x: .5, y: 1.1, w: 12.3, fontSize: 9, border: { type: 'solid', color: 'E2E7EF', pt: .5 }, autoPage: false }); } });
      blob = await pptx.write({ outputType: 'blob' }); name = base + '.pptx';
    }
    if (await U.saveFile(name, blob)) { await App.audit('Export Report', `${rep.title} (${format.toUpperCase()})`, App.filter.project || ''); U.toast('Report diunduh.', 'ok'); }
  }
  window.Reports = { buildReport, exportReport, quickExport: async (name, rows) => { const wb = XLSX.utils.book_new(); const cols = C.TEMPLATE_COLUMNS; const aoa = [cols.map(c => c.h)].concat(rows.map(r => cols.map(c => c.k === 'project' ? A().proj(r.projectId).code : c.k === 'month' ? C.MONTHS[+r.date.slice(5, 7) - 1] : c.k === 'totdig' ? r.totdigUsed : c.k === 'tottraffic' ? r.trafficUsed : c.k === 'scr' ? r.scrUsed : r[c.k] ?? null))); XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(aoa), 'DATA'); if (await U.saveFile(name + '.xlsx', U.workbookBlob(wb))) A().audit('Export Report', name + '.xlsx'); } };
  Pages.reports = {
    title: 'Report Center', icon: 'report', perm: 'report.export', filters: true,
    render() {
      const App = A(); const rep = RS.report;
      return U.pageHead('Reporting', 'Report Center', 'Report memakai filter global di atas sehingga angka sama dengan dashboard.') +
        `<div class="grid">${U.card('Buat report', `<div class="form-grid"><div class="field"><label for="r-type">Jenis report</label><select class="input" id="r-type">${RTYPES.map(([k, l]) => `<option value="${k}" ${RS.type === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
          <div class="field"><label for="r-fmt">Format export</label><select class="input" id="r-fmt">${FORMATS.map(([k, l]) => `<option value="${k}" ${RS.format === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div></div>
          <p class="muted small">Cakupan: <b>${esc(App.periodLabel())}</b> · ${esc(App.filter.project ? App.proj(App.filter.project).name : App.filter.customer ? App.cust(App.filter.customer).name : 'semua project dalam akses Anda')}</p>
          <div class="row"><button class="btn primary" id="r-gen">${U.icon('report')} Generate Report</button><button class="btn" id="r-prev">${U.icon('eye')} Preview</button><button class="btn" id="r-dl" ${rep ? '' : 'disabled'}>${U.icon('download')} Download</button>${App.can('report.schedule') ? `<button class="btn" id="r-sch">${U.icon('calendar')} Schedule Report</button>` : ''}</div>`, { span: 's5' })}
          ${U.card('Report terjadwal & tersimpan', '<div id="r-list"></div>', { span: 's7' })}
          ${rep ? U.card(`Preview · ${rep.title}`, `<p class="muted small" style="margin-top:0">${esc(rep.sub)} · dibuat ${dt(rep.generatedAt)}</p><div class="stat-strip">${rep.kpis.map(([l, v]) => `<div><span>${esc(l)}</span><b>${esc(v)}</b></div>`).join('')}</div>${rep.tables.map((t, i) => `<h4 style="margin:16px 0 6px">${esc(t.name)} <span class="muted small">(${t.rows.length} baris)</span></h4><div id="r-t${i}"></div>`).join('')}`) : ''}</div>`;
    },
    async mount() {
      const App = A(); const g = id => document.getElementById(id);
      g('r-type').addEventListener('change', e => { RS.type = e.target.value; RS.report = null; App.render(); });
      g('r-fmt').addEventListener('change', e => RS.format = e.target.value);
      const gen = () => { RS.report = buildReport(RS.type); App.render(); };
      g('r-gen').addEventListener('click', gen); g('r-prev').addEventListener('click', gen);
      g('r-dl').addEventListener('click', async () => { const b = g('r-dl'); b.disabled = true; b.textContent = 'Menyiapkan…'; try { await exportReport(RS.report, g('r-fmt').value); } catch (e) { U.toast('Export gagal: ' + e.message, 'bad'); } App.render(); });
      if (g('r-sch')) g('r-sch').addEventListener('click', scheduleForm);
      if (RS.report) RS.report.tables.forEach((t, i) => U.dataTable('r-t' + i, t.columns.map((c, j) => ({ k: j, label: c, r: t.rows.some(r => typeof r[j] === 'number'), fmt: v => v == null ? '–' : typeof v === 'number' ? esc(v.toLocaleString('id-ID')) : esc(v) })), t.rows.map(r => Object.assign({}, r)), { pageSize: 10, search: false }));
      let list = []; try { list = await App.ds.listReports(); } catch (e) { }
      U.dataTable('r-list', [{ k: 'name', label: 'Nama' }, { k: 'typeLabel', label: 'Jenis' }, { k: 'format', label: 'Format', fmt: v => esc(String(v).toUpperCase()) }, { k: 'schedule', label: 'Jadwal' }, { k: 'recipients', label: 'Penerima', wrap: 1 }, { k: 'createdBy', label: 'Dibuat oleh' }, { k: 'id', label: '', noSort: 1, fmt: v => `<button class="btn sm ghost" data-rdel="${v}" aria-label="Hapus">${U.icon('trash')}</button>` }], list, { search: false, pageSize: 6, emptyMsg: 'Belum ada report terjadwal.', onRender: el => el.querySelectorAll('[data-rdel]').forEach(b => b.addEventListener('click', async () => { await App.ds.deleteReport(b.dataset.rdel); App.audit('Delete Data', 'Jadwal report dihapus'); App.render(); })) });
    }
  };
  function scheduleForm() {
    const App = A();
    const m = U.modal({ title: 'Schedule Report', body: `<div class="form-grid"><div class="field full"><label for="s-name">Nama jadwal</label><input class="input" id="s-name" value="${esc((RTYPES.find(t => t[0] === RS.type) || [])[1])} otomatis"></div>
      <div class="field"><label for="s-type">Jenis</label><select class="input" id="s-type">${RTYPES.map(([k, l]) => `<option value="${k}" ${RS.type === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      <div class="field"><label for="s-fmt">Format</label><select class="input" id="s-fmt">${FORMATS.map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></div>
      <div class="field"><label for="s-freq">Frekuensi</label><select class="input" id="s-freq"><option>Harian</option><option selected>Mingguan (Senin)</option><option>Bulanan (tanggal 1)</option></select></div>
      <div class="field"><label for="s-time">Jam kirim</label><input class="input" type="time" id="s-time" value="07:00"></div>
      <div class="field full"><label for="s-to">Penerima (pisahkan dengan koma)</label><input class="input" id="s-to" value="${esc(App.profile.email)}"></div>
      <p class="muted small full" style="margin:0">Jadwal disimpan di koleksi <span class="mono">reports</span>. Pengiriman email otomatis dijalankan oleh Cloud Function terjadwal (lihat README).</p><div class="err-msg full" id="s-err"></div></div>`,
      foot: `<button class="btn" data-close>Batal</button><button class="btn primary" id="s-save">Simpan jadwal</button>` });
    m.el.querySelector('#s-save').addEventListener('click', async () => {
      const r = m.el; const to = val(r, 's-to').split(',').map(s => s.trim()).filter(Boolean);
      if (!to.length || to.some(e => !/^\S+@\S+\.\S+$/.test(e))) return r.querySelector('#s-err').textContent = 'Isi email penerima yang valid.';
      const rec = { id: C.uid('rp'), name: val(r, 's-name'), type: val(r, 's-type'), typeLabel: (RTYPES.find(t => t[0] === val(r, 's-type')) || [])[1], format: val(r, 's-fmt'), schedule: `${val(r, 's-freq')} ${val(r, 's-time')}`, recipients: to.join(', '), filter: Object.assign({}, App.filter), createdBy: App.profile.name, createdAt: now(), active: true };
      try { await App.ds.saveReport(rec); await App.audit('Schedule Report', `${rec.name} · ${rec.schedule}`); m.close(); U.toast('Jadwal report tersimpan.', 'ok'); App.render(); } catch (e) { r.querySelector('#s-err').textContent = e.message; }
    });
  }

  /* =================== 13. USER MANAGEMENT =================== */
  const roleLabel = r => (C.ROLES[r] || {}).label || r;
  Pages.users = {
    title: 'User Management', icon: 'users', perm: ['user.view', 'user.manage'], filters: false,
    render() {
      const App = A(); const tab = App.tabs('users', [['list', 'Daftar User'], ['history', 'Login History'], ['failed', 'Failed Login Attempt']]);
      return U.pageHead('Administrasi', 'User Management', 'Kelola akun, role, dan akses project/customer.', App.can('user.manage') && tab.cur === 'list' ? `<button class="btn primary" id="u-add">${U.icon('plus')} Add User</button>` : '') + tab.html + U.card('', '<div id="usr-table"></div>');
    },
    async mount() {
      const App = A(); const cur = App.subTab.users || 'list';
      if (cur === 'history') { const l = await App.ds.listLoginHistory().catch(() => []); return U.dataTable('usr-table', [{ k: 'at', label: 'Waktu', fmt: dt }, { k: 'userName', label: 'User' }, { k: 'email', label: 'Email' }, { k: 'sessionId', label: 'Session' }, { k: 'agent', label: 'Perangkat', wrap: 1 }], l, { sortK: 'at' }); }
      if (cur === 'failed') { const l = await App.ds.listFailedLogins().catch(() => []); return U.dataTable('usr-table', [{ k: 'at', label: 'Waktu', fmt: dt }, { k: 'email', label: 'Email / Username' }, { k: 'reason', label: 'Alasan' }], l, { sortK: 'at' }); }
      const users = await App.ds.listUsers(); App._users = users; const can = App.can('user.manage');
      const editable = u => can && (App.isSuper() || u.role !== 'super_admin');
      U.dataTable('usr-table', [
        { k: 'name', label: 'User', fmt: (v, r) => `<b>${esc(v)}</b><div class="muted small">@${esc(r.username || '')}</div>` }, { k: 'email', label: 'Email' }, { k: 'role', label: 'Role', fmt: roleLabel },
        { k: 'projects', label: 'Project', sort: r => (r.projects || []).length, fmt: (v, r) => C.ROLES[r.role] && C.ROLES[r.role].all ? '<span class="tag">Semua</span>' : (v || []).map(id => `<span class="tag">${esc(App.proj(id).code)}</span>`).join('') || '–' },
        { k: 'customers', label: 'Customer', sort: r => (r.customers || []).length, fmt: (v, r) => C.ROLES[r.role] && C.ROLES[r.role].all ? '<span class="tag">Semua</span>' : (v || []).map(id => `<span class="tag">${esc(id)}</span>`).join('') || '–' },
        { k: 'status', label: 'Status', fmt: v => U.pill(v === 'active' ? 'ok' : 'na', v === 'active' ? 'Active' : 'Inactive') }, { k: 'lastLogin', label: 'Last Login', fmt: v => esc(dt(v) || '–') },
        { k: 'id', label: 'Action', noSort: 1, fmt: (v, r) => `<span class="row" style="flex-wrap:nowrap">${editable(r) ? `<button class="btn sm" data-ue="${v}">${U.icon('edit')} Edit</button><button class="btn sm ghost" data-ut="${v}">${r.status === 'active' ? 'Nonaktifkan' : 'Aktifkan'}</button><button class="btn sm ghost" data-ur="${v}">Reset Password</button>` : ''}<button class="btn sm ghost" data-ua="${v}">Activity</button>${editable(r) && r.id !== App.profile.id ? `<button class="btn sm ghost" data-ud="${v}" aria-label="Hapus">${U.icon('trash')}</button>` : ''}</span>` }
      ], users, { sortK: 'name', dir: 1, onRender: el => {
        const f = id => users.find(u => u.id === id);
        el.querySelectorAll('[data-ue]').forEach(b => b.addEventListener('click', () => userForm(f(b.dataset.ue))));
        el.querySelectorAll('[data-ut]').forEach(b => b.addEventListener('click', () => toggleUser(f(b.dataset.ut))));
        el.querySelectorAll('[data-ur]').forEach(b => b.addEventListener('click', () => resetPw(f(b.dataset.ur))));
        el.querySelectorAll('[data-ua]').forEach(b => b.addEventListener('click', () => userActivity(f(b.dataset.ua))));
        el.querySelectorAll('[data-ud]').forEach(b => b.addEventListener('click', () => deleteUser(f(b.dataset.ud))));
      } });
      const add = document.getElementById('u-add'); if (add) add.addEventListener('click', () => userForm(null));
    }
  };
  function userForm(u) {
    const App = A(); const isNew = !u; u = u || { name: '', username: '', email: '', phone: '', role: 'viewer', projects: [], customers: [], status: 'active' };
    const roles = Object.keys(C.ROLES).filter(r => App.isSuper() || r !== 'super_admin');
    const m = U.modal({ title: isNew ? 'Add User' : 'Edit User', wide: true, body: `<form class="form-grid" id="uf" novalidate>
      <div class="field"><label for="f-name">Full Name</label><input class="input" id="f-name" value="${esc(u.name)}"></div>
      <div class="field"><label for="f-user">Username</label><input class="input" id="f-user" value="${esc(u.username)}"></div>
      <div class="field"><label for="f-email">Email</label><input class="input" id="f-email" type="email" value="${esc(u.email)}" ${isNew ? '' : 'disabled'}></div>
      <div class="field"><label for="f-phone">Phone</label><input class="input" id="f-phone" value="${esc(u.phone || '')}"></div>
      <div class="field"><label for="f-role">Role</label><select class="input" id="f-role">${roles.map(r => `<option value="${r}" ${u.role === r ? 'selected' : ''}>${roleLabel(r)}</option>`).join('')}</select></div>
      <div class="field"><label for="f-status">Status</label><select class="input" id="f-status"><option value="active" ${u.status === 'active' ? 'selected' : ''}>Active</option><option value="inactive" ${u.status !== 'active' ? 'selected' : ''}>Inactive</option></select></div>
      <div class="field full"><label>Customer</label><div class="multi" id="f-cust">${App.data.customers.map(c => `<label class="check"><input type="checkbox" value="${c.id}" ${(u.customers || []).includes(c.id) ? 'checked' : ''}> ${esc(c.name)}</label>`).join('')}</div><span class="muted small">Viewer/customer otomatis melihat seluruh project milik customer yang dipilih.</span></div>
      <div class="field full"><label>Project</label><div class="multi" id="f-proj">${App.data.projects.map(p => `<label class="check"><input type="checkbox" value="${p.id}" ${(u.projects || []).includes(p.id) ? 'checked' : ''}> ${esc(p.code)} · <span class="muted small">${esc(p.name)}</span></label>`).join('')}</div></div>
      ${isNew ? `<div class="field"><label for="f-pw">Password</label><input class="input" id="f-pw" type="password" autocomplete="new-password"></div><div class="field"><label for="f-pw2">Confirm Password</label><input class="input" id="f-pw2" type="password" autocomplete="new-password"></div><p class="muted small full" style="margin:0">Minimal 8 karakter, kombinasi huruf dan angka. Password di-hash oleh ${App.ds.mode === 'firebase' ? 'Firebase Authentication' : 'SHA-256 (mode demo)'} dan tidak pernah disimpan dalam bentuk asli.</p>` : ''}
      <div class="err-msg full" id="f-err"></div></form>`, foot: `<button class="btn" data-close>Batal</button><button class="btn primary" id="f-save">Simpan</button>` });
    const roleSel = m.el.querySelector('#f-role'); const sync = () => { const all = C.ROLES[roleSel.value].all; m.el.querySelectorAll('#f-cust input,#f-proj input').forEach(i => i.disabled = all); };
    roleSel.addEventListener('change', sync); sync();
    m.el.querySelector('#f-save').addEventListener('click', async () => {
      const r = m.el; const err = r.querySelector('#f-err'); err.textContent = '';
      const data = { name: val(r, 'f-name'), username: val(r, 'f-user').toLowerCase(), email: isNew ? val(r, 'f-email').toLowerCase() : u.email, phone: val(r, 'f-phone'), role: val(r, 'f-role'), status: val(r, 'f-status'), customers: [...r.querySelectorAll('#f-cust input:checked')].map(i => i.value), projects: [...r.querySelectorAll('#f-proj input:checked')].map(i => i.value) };
      if (C.ROLES[data.role].all) { data.customers = []; data.projects = []; }
      data.projectAccess = [...new Set(data.projects.concat(App.data.projects.filter(p => data.customers.includes(p.customerId)).map(p => p.id)))];
      if (!data.name) return err.textContent = 'Full Name wajib diisi.';
      if (!/^[a-z0-9._-]{3,30}$/.test(data.username)) return err.textContent = 'Username 3-30 karakter (huruf kecil, angka, titik, _ atau -).';
      if (!/^\S+@\S+\.\S+$/.test(data.email)) return err.textContent = 'Format email tidak valid.';
      if (data.phone && !/^[+0-9\s-]{8,16}$/.test(data.phone)) return err.textContent = 'Format nomor telepon tidak valid.';
      if (!C.ROLES[data.role].all && !data.projects.length && !data.customers.length) return err.textContent = 'Pilih minimal satu project atau customer untuk role ini.';
      const others = App._users || []; if (others.some(x => x.id !== u.id && (x.username || '').toLowerCase() === data.username)) return err.textContent = 'Username sudah dipakai.';
      if (!isNew && u.id === App.profile.id && data.role !== u.role) return err.textContent = 'Anda tidak dapat mengubah role akun sendiri.';
      try {
        if (isNew) {
          const pw = val(r, 'f-pw'); if (pw.length < 8 || !/[a-zA-Z]/.test(pw) || !/\d/.test(pw)) return err.textContent = 'Password minimal 8 karakter dengan huruf dan angka.';
          if (pw !== val(r, 'f-pw2')) return err.textContent = 'Konfirmasi password tidak sama.';
          await App.ds.createUser(data, pw); await App.audit('Create User', `${data.name} (${roleLabel(data.role)})`);
        } else {
          await App.ds.updateUser(u.id, data); await App.audit('Edit User', `${data.name}`);
          if (u.role !== data.role || JSON.stringify(u.projects || []) !== JSON.stringify(data.projects) || JSON.stringify(u.customers || []) !== JSON.stringify(data.customers)) await App.audit('Change Permission', `${data.name}: ${roleLabel(data.role)} · ${data.projects.length} project · ${data.customers.length} customer`);
        }
        m.close(); U.toast('User tersimpan.', 'ok'); App.render();
      } catch (e) { err.textContent = e.message; }
    });
  }
  async function toggleUser(u) {
    const App = A(); if (u.id === App.profile.id) return U.toast('Anda tidak dapat menonaktifkan akun sendiri.', 'bad');
    const ns = u.status === 'active' ? 'inactive' : 'active';
    if (!await U.confirmBox(ns === 'active' ? 'Aktifkan akun' : 'Nonaktifkan akun', `${ns === 'active' ? 'Aktifkan' : 'Nonaktifkan'} akun <b>${esc(u.name)}</b>?${ns === 'inactive' ? ' User tidak dapat login sampai diaktifkan kembali.' : ''}`, ns === 'active' ? 'Aktifkan' : 'Nonaktifkan', ns !== 'active')) return;
    try { await App.ds.updateUser(u.id, { status: ns }); await App.audit(ns === 'active' ? 'Activate User' : 'Deactivate User', u.name); App.render(); } catch (e) { U.toast(e.message, 'bad'); }
  }
  async function resetPw(u) {
    const App = A(); if (!await U.confirmBox('Reset password', `Kirim reset password untuk <b>${esc(u.name)}</b> (${esc(u.email)})?`, 'Reset', false)) return;
    try { const r = await App.ds.adminResetPassword(u); await App.audit('Reset Password', u.name); U.toast(r.demo ? `Mode demo: password ${u.name} direset ke ${r.password}` : 'Email reset password terkirim ke ' + u.email, 'ok'); } catch (e) { U.toast(e.message, 'bad'); }
  }
  async function deleteUser(u) {
    const App = A(); if (!await U.confirmBox('Hapus user', `Hapus user <b>${esc(u.name)}</b>? Profil dan akses akan dihapus.${App.ds.mode === 'firebase' ? ' Akun login di Firebase Authentication juga perlu dihapus dari Firebase Console atau Cloud Function (lihat README).' : ''}`, 'Hapus')) return;
    try { await App.ds.deleteUser(u.id); await App.audit('Delete User', u.name); App.render(); U.toast('User dihapus.', 'ok'); } catch (e) { U.toast(e.message, 'bad'); }
  }
  async function userActivity(u) {
    const App = A(); const [audit, logins] = await Promise.all([App.can('audit.view') ? App.ds.listAudit(1000).catch(() => []) : [], App.ds.listLoginHistory(500).catch(() => [])]);
    const m = U.modal({ title: `Aktivitas · ${u.name}`, wide: true, body: `<h4 style="margin:0 0 6px">Aktivitas</h4><div id="ua-a"></div><h4 style="margin:16px 0 6px">Login History</h4><div id="ua-l"></div>` });
    U.dataTable(m.el.querySelector('#ua-a'), [{ k: 'at', label: 'Waktu', fmt: dt }, { k: 'activity', label: 'Aktivitas' }, { k: 'detail', label: 'Detail', wrap: 1 }, { k: 'status', label: 'Status' }], audit.filter(a => a.userId === u.id), { pageSize: 8, search: false, emptyMsg: App.can('audit.view') ? 'Belum ada aktivitas.' : 'Butuh akses audit log.' });
    U.dataTable(m.el.querySelector('#ua-l'), [{ k: 'at', label: 'Waktu', fmt: dt }, { k: 'sessionId', label: 'Session' }, { k: 'agent', label: 'Perangkat', wrap: 1 }], logins.filter(a => a.userId === u.id), { pageSize: 6, search: false });
  }

  /* =================== 14. ACCESS MANAGEMENT =================== */
  Pages.access = {
    title: 'Access Management', icon: 'access', perm: ['permission.manage', 'user.manage'], filters: false,
    render() {
      const App = A(); const pm = App.data.settings.permissions || C.DEFAULT_ROLE_PERMS; const can = App.can('permission.manage'); const roles = Object.keys(C.ROLES);
      return U.pageHead('Role Based Access Control', 'Access Management', 'Matriks permission per role dan ringkasan akses project per user.', can ? `<button class="btn" id="ac-reset">Kembalikan default</button><button class="btn primary" id="ac-save">Simpan permission</button>` : '') +
        `<div class="grid">${U.card('Matriks role & permission', `<div class="tbl-wrap"><table class="tbl matrix"><thead><tr><th>Permission</th>${roles.map(r => `<th>${esc(C.ROLES[r].label)}</th>`).join('')}</tr></thead><tbody>${C.PERMISSIONS.map(([k, l]) => `<tr><td><b>${esc(l)}</b><div class="muted small mono">${k}</div></td>${roles.map(r => `<td><input type="checkbox" data-perm="${k}" data-role="${r}" ${r === 'super_admin' || (pm[r] || []).includes(k) ? 'checked' : ''} ${!can || r === 'super_admin' ? 'disabled' : ''} aria-label="${esc(l)} untuk ${esc(C.ROLES[r].label)}" style="width:16px;height:16px;accent-color:var(--accent)"></td>`).join('')}</tr>`).join('')}</tbody></table></div>
          <p class="muted small" style="margin:10px 0 0">Super Admin selalu memiliki seluruh permission. Isolasi data per project ditegakkan juga oleh Firestore Security Rules sehingga tidak bisa dilewati dari browser.</p>`)}
          ${U.card('Akses project per user', '<div id="ac-users"></div>')}</div>`;
    },
    async mount() {
      const App = A(); const g = id => document.getElementById(id);
      if (g('ac-save')) g('ac-save').addEventListener('click', async () => {
        const pm = {}; Object.keys(C.ROLES).forEach(r => pm[r] = []); document.querySelectorAll('[data-perm]').forEach(i => { if (i.checked) pm[i.dataset.role].push(i.dataset.perm); }); pm.super_admin = C.PERMISSIONS.map(p => p[0]);
        try { await App.ds.saveSetting('permissions', pm); App.data.settings.permissions = pm; App.computeScope(); await App.audit('Change Permission', 'Matriks role-permission diperbarui'); U.toast('Permission tersimpan.', 'ok'); } catch (e) { U.toast(e.message, 'bad'); }
      });
      if (g('ac-reset')) g('ac-reset').addEventListener('click', async () => { if (!await U.confirmBox('Kembalikan default', 'Kembalikan matriks permission ke pengaturan default?', 'Kembalikan', false)) return; App.data.settings.permissions = JSON.parse(JSON.stringify(C.DEFAULT_ROLE_PERMS)); await App.ds.saveSetting('permissions', App.data.settings.permissions); await App.audit('Change Permission', 'Reset ke default'); App.render(); });
      const users = await App.ds.listUsers().catch(() => []);
      U.dataTable('ac-users', [{ k: 'name', label: 'User' }, { k: 'role', label: 'Role', fmt: roleLabel }, { k: 'scope', label: 'Cakupan data', sort: r => r.role, fmt: (v, r) => C.ROLES[r.role] && C.ROLES[r.role].all ? '<span class="pill info plain">Seluruh project</span>' : ((r.projects || []).map(id => `<span class="tag">${esc(App.proj(id).code)}</span>`).join('') + (r.customers || []).map(id => `<span class="tag">Customer: ${esc(App.cust(id).name)}</span>`).join('') || '<span class="pill bad plain">Tidak ada akses</span>') }, { k: 'status', label: 'Status', fmt: v => U.pill(v === 'active' ? 'ok' : 'na', v === 'active' ? 'Active' : 'Inactive') }], users, { sortK: 'role', pageSize: 10 });
    }
  };

  /* =================== 15. AUDIT LOG =================== */
  Pages.audit = {
    title: 'Audit Log', icon: 'audit', perm: 'audit.view', filters: false,
    render() { const App = A(); const tab = App.tabs('audit', [['log', 'Audit Trail'], ['login', 'Login History'], ['failed', 'Failed Login']]); return U.pageHead('Keamanan', 'Audit Log', 'Seluruh aktivitas user tercatat dan tidak dapat diubah.', `<button class="btn" id="al-export">${U.icon('download')} Export Excel</button>`) + tab.html + U.card('', '<div class="row" style="margin-bottom:10px" id="al-filter"></div><div id="al-table"></div>'); },
    async mount() {
      const App = A(); const cur = App.subTab.audit || 'log'; let data = [], cols = [];
      if (cur === 'log') { data = await App.ds.listAudit(1000).catch(e => { U.toast(e.message, 'bad'); return []; }); cols = [{ k: 'at', label: 'Timestamp', fmt: dt }, { k: 'userName', label: 'User' }, { k: 'activity', label: 'Activity', fmt: v => `<span class="tag">${esc(v)}</span>` }, { k: 'projectId', label: 'Project', fmt: v => esc(v ? App.proj(v).code : '–') }, { k: 'sessionId', label: 'IP / Session', fmt: (v, r) => `<span class="mono small">${esc(r.ip || v || '–')}</span>` }, { k: 'status', label: 'Status', fmt: v => U.pill(v === 'Success' ? 'ok' : 'bad', v) }, { k: 'detail', label: 'Detail', wrap: 1 }]; }
      else if (cur === 'login') { data = await App.ds.listLoginHistory().catch(() => []); cols = [{ k: 'at', label: 'Timestamp', fmt: dt }, { k: 'userName', label: 'User' }, { k: 'email', label: 'Email' }, { k: 'sessionId', label: 'Session' }, { k: 'agent', label: 'Perangkat', wrap: 1 }]; }
      else { data = await App.ds.listFailedLogins().catch(() => []); cols = [{ k: 'at', label: 'Timestamp', fmt: dt }, { k: 'email', label: 'Email / Username' }, { k: 'reason', label: 'Alasan' }]; }
      let view = data;
      if (cur === 'log') {
        const acts = [...new Set(data.map(d => d.activity))].sort();
        document.getElementById('al-filter').innerHTML = `<label class="small muted" for="al-act">Activity</label><select class="input" id="al-act" style="max-width:220px"><option value="">Semua aktivitas</option>${acts.map(a => `<option>${esc(a)}</option>`).join('')}</select><label class="small muted" for="al-from">Dari</label><input class="input" type="date" id="al-from" style="max-width:160px"><label class="small muted" for="al-to">Sampai</label><input class="input" type="date" id="al-to" style="max-width:160px">`;
        const tbl = U.dataTable('al-table', cols, data, { sortK: 'at', pageSize: 20 });
        const ap = () => { const a = val(document, 'al-act'), f = val(document, 'al-from'), t = val(document, 'al-to'); view = data.filter(d => (!a || d.activity === a) && (!f || d.at.slice(0, 10) >= f) && (!t || d.at.slice(0, 10) <= t)); tbl.refresh(view); };
        ['al-act', 'al-from', 'al-to'].forEach(id => document.getElementById(id).addEventListener('change', ap));
      } else U.dataTable('al-table', cols, data, { sortK: 'at', pageSize: 20 });
      document.getElementById('al-export').addEventListener('click', async () => { const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(view.map(d => { const o = Object.assign({}, d); delete o.serverAt; return o; })), 'Audit'); if (await U.saveFile(`Audit_${cur}_${new Date().toISOString().slice(0, 10)}.xlsx`, U.workbookBlob(wb))) App.audit('Export Report', 'Audit log ' + cur); });
    }
  };

  /* =================== 16. SYSTEM SETTINGS =================== */
  const KPI_FIELDS = [['scr', 'SCR %'], ['sl', 'SL %'], ['aht', 'AHT dtk'], ['quality', 'Quality'], ['pk', 'Prod. Knowl.'], ['productivity', 'Productivity %'], ['attendance', 'Attendance %'], ['login', 'Login Acc. %'], ['rt', 'Resp. Time dtk'], ['ht', 'Handl. Time dtk'], ['rr', 'Resp. Rate %']];
  Pages.settings = {
    title: 'System Settings', icon: 'settings', perm: ['kpi.configure', 'settings.manage'], filters: false,
    render() {
      const App = A(); const tab = App.tabs('settings', [['overview', 'System Overview'], ['kpi', 'KPI Configuration'], ['formula', 'Formula & Alert'], ['data', 'Data & Sistem']].filter(([k]) => k !== 'formula' || App.can('settings.manage')).filter(([k]) => k !== 'kpi' || App.can('kpi.configure')));
      let body = '';
      if (tab.cur === 'overview') {
        const ups = App.data.uploads; const last = ups.slice().sort((a, b) => (b.uploadedAt || '').localeCompare(a.uploadedAt || ''))[0];
        const records = Object.values(App.data.perf).reduce((s, d) => s + (d.rows || []).length, 0);
        body = `<div class="kpis">${[['Total Customers', App.data.customers.length, 'master'], ['Total Projects', App.data.projects.length, 'project'], ['Active Users', '<span id="ov-users">…</span>', 'users'], ['Total Data Records', records.toLocaleString('id-ID'), 'file'], ['Last Upload', last ? dt(last.uploadedAt).slice(0, 10) : '–', 'upload'], ['Failed / Rejected Upload', ups.filter(u => u.status === 'Error' || u.status === 'Rejected').length, 'alert']].map(([l, v, ic]) => `<div class="kpi st-info"><div class="lbl">${U.icon(ic)}${l}</div><div class="val">${v}</div><div class="meta"></div></div>`).join('')}</div>
          <div class="grid">${U.card('Quick Action', `<div class="row">${App.can('customer.manage') ? `<button class="btn" data-qa="customer">${U.icon('plus')} Create Customer</button>` : ''}${App.can('project.manage') ? `<button class="btn" data-qa="project">${U.icon('plus')} Create Project</button>` : ''}${App.can('user.manage') ? `<button class="btn" data-qa="user">${U.icon('plus')} Create User</button>` : ''}${App.can('template.download') ? `<button class="btn" data-qa="template">${U.icon('download')} Download Template</button>` : ''}${App.can('upload.data') ? `<button class="btn" data-qa="upload">${U.icon('upload')} Upload Data</button>` : ''}${App.can('kpi.configure') ? `<button class="btn" data-qa="kpi">${U.icon('settings')} Configure KPI</button>` : ''}</div>`, { span: 's12' })}
          ${U.card('System Activity', App.can('audit.view') ? U.chartBox('ov-act') : U.empty('Butuh akses audit log', ''), { span: 's8', hint: 'Aktivitas 14 hari terakhir' })}
          ${U.card('Status platform', `<dl class="kv"><dt>Mode</dt><dd>${App.ds.mode === 'firebase' ? 'Firebase (produksi)' : 'Demo (lokal)'}</dd><dt>Firebase project</dt><dd class="mono">${esc(window.APP_CONFIG.firebase.projectId)}</dd><dt>Data awal</dt><dd>${esc(window.SEED ? window.SEED.generatedAt.slice(0, 10) : '–')}</dd><dt>Template</dt><dd>${C.TEMPLATE_COLUMNS.length} kolom</dd><dt>Session timeout</dt><dd>${window.APP_CONFIG.sessionTimeoutMinutes} menit</dd></dl>`, { span: 's4' })}</div>`;
      } else if (tab.cur === 'kpi') {
        body = U.card('Target KPI per project', `<p class="muted small" style="margin-top:0">Target dapat berbeda antar project. Perubahan langsung dipakai oleh status, alert, dan report.</p><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Project</th>${KPI_FIELDS.map(f => `<th class="r">${f[1]}</th>`).join('')}<th></th></tr></thead><tbody>${App.projectsInScope().map(p => { const t = App.targets(p.id); return `<tr data-kp="${p.id}"><td><b>${esc(p.code)}</b></td>${KPI_FIELDS.map(([k]) => `<td><input class="input mono" style="width:80px;height:32px;text-align:right" type="number" step="0.1" min="0" data-k="${k}" value="${t[k]}" aria-label="${k} ${esc(p.code)}"></td>`).join('')}<td><button class="btn sm" data-ksave="${p.id}">Simpan</button></td></tr>`; }).join('')}</tbody></table></div><div class="row" style="margin-top:12px"><button class="btn primary" id="k-all">Simpan semua</button></div>`);
      } else if (tab.cur === 'formula') {
        const F = App.F();
        const sel = (id, opts, cur) => `<select class="input" id="${id}">${opts.map(([v, l]) => `<option value="${v}" ${String(cur) === String(v) ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
        body = U.card('Konfigurasi formula auto-calculation', `<div class="form-grid">
          <div class="field"><label for="fx-acc">Accepted Call</label>${sel('fx-acc', [['true', 'Accepted Call = ACD Call'], ['false', 'Pakai nilai upload (fallback ACD)']], F.acceptedFromAcd)}</div>
          <div class="field"><label for="fx-scr">Sumber SCR harian</label>${sel('fx-scr', [['uploaded', 'Nilai SCR yang di-upload'], ['computed', 'Hitung: ACD ÷ Call Offered × 100%']], F.scrSource)}</div>
          <div class="field"><label for="fx-agg">Agregasi SCR multi-hari / multi-project</label>${sel('fx-agg', [['weighted', 'Tertimbang volume (Σ ACD ÷ Σ Offered)'], ['average', 'Rata-rata harian']], F.scrAggregate)}</div>
          <div class="field"><label for="fx-dig">Total Digital</label>${sel('fx-dig', [['computed', 'Hitung: jumlah 15 channel digital'], ['uploaded', 'Pakai nilai upload']], F.totalDigital)}</div>
          <div class="field"><label for="fx-tt">Total Traffic All</label>${sel('fx-tt', [['computed', 'Hitung: Accepted + Outbound + Total Digital'], ['uploaded', 'Pakai nilai upload']], F.totalTraffic)}</div>
          <div class="field"><label for="fx-band">Batas "At Risk" (poin % di bawah target)</label><input class="input" type="number" step="0.5" min="0" id="fx-band" value="${F.atRiskBand}"></div>
          <div class="field"><label for="fx-aht">Batas "At Risk" AHT/RT (% di atas target)</label><input class="input" type="number" step="1" min="0" id="fx-aht" value="${F.ahtRiskPct}"></div>
          <div class="field"><label for="fx-qe">Quality: Excellent ≥</label><input class="input" type="number" step="0.5" id="fx-qe" value="${F.qualityExcellent}"></div>
          <div class="field"><label for="fx-qg">Quality: Good ≥</label><input class="input" type="number" step="0.5" id="fx-qg" value="${F.qualityGood}"></div></div>
          <p class="muted small">Abandon Rate = Abandon ÷ Call Offered × 100%. Kehadiran dan Ketepatan Login diisi sebagai persentase hasil (hadir ÷ terjadwal, login tepat waktu ÷ schedule).</p>
          <div class="row"><button class="btn primary" id="fx-save">Simpan formula</button></div>`);
      } else {
        body = `<div class="grid">${App.ds.mode === 'firebase' ? U.card('Import data awal', `<p style="margin-top:0">Menulis data asli dari file Excel yang diberikan (${window.SEED.projects.length} project, ${Object.values(window.SEED.months).reduce((a, r) => a + r.length, 0).toLocaleString('id-ID')} baris harian, skor QM ${window.SEED.agents.length} agent) ke Firestore. Data dengan ID yang sama akan ditimpa.</p><div class="progress" style="margin-bottom:12px"><i id="seed-bar"></i></div>${App.isSuper() ? `<button class="btn primary" id="seed-run">${U.icon('upload')} Import ke Firestore</button>` : '<p class="muted">Hanya Super Admin.</p>'}`, { span: 's6' })
          : U.card('Data demo', `<p style="margin-top:0">Data demo tersimpan di browser ini. Reset untuk mengembalikan data awal (dari file Excel yang diberikan), user demo, dan menghapus upload percobaan.</p><button class="btn danger" id="demo-reset">${U.icon('refresh')} Reset data demo</button>`, { span: 's6' })}
          ${U.card('Pembersihan data awal', `<dl class="kv"><dt>Tanggal tertukar (hari/bulan) diperbaiki</dt><dd>${window.SEED.cleaning.datesFixed}</dd><dt>Respon Rate tidak valid (&gt;100) dikosongkan</dt><dd>${window.SEED.cleaning.rr_invalid}</dd><dt>Response time &gt; 48 jam dikosongkan</dt><dd>${window.SEED.cleaning.rt_out}</dd><dt>SCR skala 0-10000 dinormalisasi</dt><dd>${window.SEED.cleaning.scr_scaled}</dd><dt>Interaksi TikTok (tidak ada di template)</dt><dd>${window.SEED.cleaning.tiktokExcluded.toLocaleString('id-ID')} tidak dihitung</dd></dl>`, { span: 's6' })}</div>`;
      }
      return U.pageHead('Super Admin Panel', 'System Settings', '') + tab.html + body;
    },
    async mount() {
      const App = A(); const cur = App.subTab.settings || 'overview'; const g = id => document.getElementById(id);
      if (cur === 'overview') {
        document.querySelectorAll('[data-qa]').forEach(b => b.addEventListener('click', () => { const a = b.dataset.qa; if (a === 'customer') customerForm(null); else if (a === 'project') projectForm(null); else if (a === 'user') { App.subTab.users = 'list'; App.go('users'); setTimeout(() => userForm(null), 200); } else if (a === 'template' || a === 'upload') { App.subTab.upload = 'center'; App.go('upload'); } else { App.subTab.settings = 'kpi'; App.render(); } }));
        App.ds.listUsers().then(u => { const e = g('ov-users'); if (e) e.textContent = u.filter(x => x.status === 'active').length; }).catch(() => { const e = g('ov-users'); if (e) e.textContent = '–'; });
        if (App.can('audit.view') && g('ov-act')) { const log = await App.ds.listAudit(1000).catch(() => []); const days = []; for (let i = 13; i >= 0; i--) { const d = new Date(Date.now() - i * 86400000); days.push(C.toISO(d)); } const cnt = d => log.filter(l => (l.at || '').slice(0, 10) === d); const pal = U.palette(); U.chart('ov-act', 'bar', { labels: days.map(d => d.slice(5)), datasets: [{ label: 'Login', data: days.map(d => cnt(d).filter(l => l.activity === 'Login').length), backgroundColor: pal[0], stack: 'a' }, { label: 'Upload', data: days.map(d => cnt(d).filter(l => /Upload/.test(l.activity)).length), backgroundColor: pal[1], stack: 'a' }, { label: 'Lainnya', data: days.map(d => cnt(d).filter(l => l.activity !== 'Login' && !/Upload/.test(l.activity)).length), backgroundColor: pal[4], stack: 'a' }] }, { scales: { x: { stacked: true }, y: { stacked: true, ticks: { precision: 0 } } } }); }
      } else if (cur === 'kpi') {
        const read = pid => { const tr = document.querySelector(`[data-kp="${pid}"]`); const o = {}; let bad = false; tr.querySelectorAll('[data-k]').forEach(i => { const v = parseFloat(i.value); if (!C.isNum(v) || v < 0 || (['scr', 'sl', 'quality', 'pk', 'productivity', 'attendance', 'login', 'rr'].includes(i.dataset.k) && v > 100)) { bad = true; i.setAttribute('aria-invalid', 'true'); } else { i.removeAttribute('aria-invalid'); o[i.dataset.k] = v; } }); return bad ? null : o; };
        const save = async pid => { const o = read(pid); if (!o) { U.toast(`Target ${App.proj(pid).code} tidak valid (persentase 0-100).`, 'bad'); return false; } const old = App.targets(pid); await App.ds.saveKpiTarget(pid, o); App.data.kpi[pid] = o; const ch = KPI_FIELDS.filter(([k]) => old[k] !== o[k]).map(([k, l]) => `${l}: ${old[k]} → ${o[k]}`); if (ch.length) await App.audit('Change Target', ch.join(', '), pid); return true; };
        document.querySelectorAll('[data-ksave]').forEach(b => b.addEventListener('click', async () => { if (await save(b.dataset.ksave)) U.toast('Target tersimpan.', 'ok'); }));
        g('k-all').addEventListener('click', async () => { let ok = true; for (const p of App.projectsInScope()) ok = (await save(p.id)) && ok; if (ok) U.toast('Semua target tersimpan.', 'ok'); App._alerts = null; });
      } else if (cur === 'formula') {
        g('fx-save').addEventListener('click', async () => {
          const F = { acceptedFromAcd: val(document, 'fx-acc') === 'true', scrSource: val(document, 'fx-scr'), scrAggregate: val(document, 'fx-agg'), totalDigital: val(document, 'fx-dig'), totalTraffic: val(document, 'fx-tt'), atRiskBand: parseFloat(val(document, 'fx-band')) || 0, ahtRiskPct: parseFloat(val(document, 'fx-aht')) || 0, qualityExcellent: parseFloat(val(document, 'fx-qe')) || 95, qualityGood: parseFloat(val(document, 'fx-qg')) || 85 };
          if (F.qualityGood >= F.qualityExcellent) return U.toast('Batas Good harus lebih kecil dari Excellent.', 'bad');
          try { await App.ds.saveSetting('formulas', F); App.data.settings.formulas = F; App.rebuildRows(); await App.audit('Change KPI', 'Formula: ' + Object.entries(F).map(([k, v]) => k + '=' + v).join(', ')); U.toast('Formula tersimpan. Semua dashboard dihitung ulang.', 'ok'); } catch (e) { U.toast(e.message, 'bad'); }
        });
      } else {
        if (g('seed-run')) g('seed-run').addEventListener('click', async () => { if (!await U.confirmBox('Import data awal', 'Tulis data awal ke Firestore? Dokumen dengan ID yang sama akan ditimpa.', 'Import', false)) return; const b = g('seed-run'); b.disabled = true; try { const r = await App.ds.importSeed(window.SEED, p => { const bar = g('seed-bar'); if (bar) bar.style.width = Math.round(p * 100) + '%'; }); await App.audit('Upload Excel', `Import data awal: ${r.docs} dokumen`); U.toast('Import selesai. Memuat ulang data…', 'ok'); await App.loadAll(); App.render(); } catch (e) { U.toast('Import gagal: ' + e.message, 'bad'); b.disabled = false; } });
        if (g('demo-reset')) g('demo-reset').addEventListener('click', async () => { if (!await U.confirmBox('Reset data demo', 'Kembalikan seluruh data demo ke kondisi awal? Anda akan logout.', 'Reset')) return; await App.ds.resetDemo(); });
      }
    }
  };
})();
