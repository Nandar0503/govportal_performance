/* =========================================================================
 * APP: bootstrap, autentikasi, shell (sidebar/topbar), router, filter global,
 * state data terpusat & RBAC. Semua halaman membaca data lewat App.rows().
 * ========================================================================= */
(function () {
  'use strict';
  const C = window.Core, U = window.UI, esc = C.esc, cfg = window.APP_CONFIG;
  const Pages = window.Pages = window.Pages || {};

  const NAV = [
    ['Dashboard', ['exec', 'portfolio', 'project', 'channel', 'traffic', 'sla', 'quality', 'workforce', 'digital']],
    ['Data', ['master', 'upload', 'reports']],
    ['Administrasi', ['users', 'access', 'audit', 'settings']]
  ];

  const App = window.App = {
    ds: null, profile: null, perms: new Set(), scopeIds: null,
    data: { customers: [], projects: [], kpi: {}, settings: { formulas: C.DEFAULT_FORMULAS, permissions: C.DEFAULT_ROLE_PERMS }, perf: {}, agents: [], uploads: [], issues: [], allRows: [] },
    filter: { customer: '', project: '', month: '', from: '', to: '', channel: '' },
    route: 'exec', subTab: {},

    /* ---------- RBAC ---------- */
    can(p) { return this.perms.has(p); },
    isCorporate() { return !!(this.profile && C.ROLES[this.profile.role] && C.ROLES[this.profile.role].all); },
    isSuper() { return this.profile && this.profile.role === 'super_admin'; },
    computeScope() {
      const p = this.profile; if (!p) return;
      const rp = (this.data.settings.permissions || C.DEFAULT_ROLE_PERMS)[p.role] || [];
      this.perms = new Set(p.role === 'super_admin' ? C.PERMISSIONS.map(x => x[0]) : rp);
      if (this.isCorporate()) this.scopeIds = null;
      else {
        const ids = new Set([].concat(p.projects || [], p.projectAccess || []));
        (p.customers || []).forEach(cid => this.data.projects.filter(x => x.customerId === cid).forEach(x => ids.add(x.id)));
        this.scopeIds = [...ids];
      }
    },
    projectsInScope() { return this.data.projects.filter(p => !this.scopeIds || this.scopeIds.includes(p.id)).sort((a, b) => a.name.localeCompare(b.name)); },
    customersInScope() { const ids = new Set(this.projectsInScope().map(p => p.customerId)); return this.data.customers.filter(c => this.isCorporate() || ids.has(c.id)).sort((a, b) => a.name.localeCompare(b.name)); },
    proj(id) { return this.data.projects.find(p => p.id === id) || { id, name: id, code: id, customerId: '' }; },
    cust(id) { return this.data.customers.find(c => c.id === id) || { id, name: id || '–' }; },
    targets(pid) { return Object.assign({}, C.DEFAULT_KPI, this.data.kpi[pid] || {}); },
    F() { return Object.assign({}, C.DEFAULT_FORMULAS, this.data.settings.formulas || {}); },

    /* ---------- DATA ---------- */
    async loadAll() {
      const ds = this.ds;
      const [customers, projects, kpi, settings] = await Promise.all([ds.listCustomers(), ds.listProjects(), ds.getKpiTargets(), ds.getSettings()]);
      Object.assign(this.data, { customers, projects, kpi, settings });
      this.computeScope();
      const ids = this.scopeIds;
      const [perf, agents, issues] = await Promise.all([ds.loadPerformance(ids), ds.loadAgents(ids).catch(() => []), ds.listIssues(ids).catch(() => [])]);
      this.data.perf = perf; this.data.agents = agents; this.data.issues = issues;
      this.data.uploads = (this.can('upload.data') || this.can('upload.approve') || this.isCorporate()) ? await ds.listUploads(ids).catch(() => []) : [];
      this.rebuildRows();
    },
    rebuildRows() {
      const F = this.F(); const out = [];
      Object.values(this.data.perf).forEach(doc => {
        if (this.scopeIds && !this.scopeIds.includes(doc.projectId)) return;
        const p = this.proj(doc.projectId);
        (doc.rows || []).forEach(r => { const x = C.computeRow(r, F); x.projectId = doc.projectId; x.customerId = p.customerId; x.ym = r.date.slice(0, 7); out.push(x); });
      });
      out.sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : 0);
      this.data.allRows = out;
      this._alerts = null;
    },
    months() { return [...new Set(this.data.allRows.map(r => r.ym))].sort(); },
    // opts: {ignoreProject, ignoreCustomer, ignoreMonth, ignoreDate, ignoreChannel, projectIds}
    rows(opts = {}) {
      const f = this.filter; let rows = this.data.allRows;
      rows = rows.filter(r => {
        if (opts.projectIds && !opts.projectIds.includes(r.projectId)) return false;
        if (!opts.ignoreCustomer && f.customer && r.customerId !== f.customer) return false;
        if (!opts.ignoreProject && f.project && r.projectId !== f.project) return false;
        if (!opts.ignoreMonth && f.month && r.ym !== f.month) return false;
        if (!opts.ignoreDate && f.from && r.date < f.from) return false;
        if (!opts.ignoreDate && f.to && r.date > f.to) return false;
        return true;
      });
      if (!opts.ignoreChannel && f.channel) {
        const ch = f.channel;
        rows = rows.map(r => {
          const x = Object.assign({}, r);
          if (ch === 'inbound') { x.totdigUsed = 0; x.trafficUsed = r.acc || 0; x.ob = 0; CHS.forEach(c => x[c] = 0); }
          else if (ch === 'outbound') { x.totdigUsed = 0; x.trafficUsed = r.ob || 0; x.acc = 0; CHS.forEach(c => x[c] = 0); }
          else if (ch === 'digital') { x.trafficUsed = r.totdigUsed; }
          else { CHS.forEach(c => { if (c !== ch) x[c] = 0; }); x.totdigUsed = r[ch] || 0; x.trafficUsed = x.totdigUsed; }
          return x;
        });
      }
      return rows;
    },
    agg(rows) { return C.aggregate(rows, this.F()); },
    perProject(rows) {
      const g = C.groupBy(rows, r => r.projectId);
      return [...g.entries()].map(([pid, rr]) => ({ project: this.proj(pid), agg: this.agg(rr), rows: rr })).sort((a, b) => b.agg.traffic - a.agg.traffic);
    },
    series(rows, key = 'ym') { const fn = key === 'week' ? r => C.isoWeek(r.date) : key === 'date' ? r => r.date : r => r[key]; return C.series(rows, fn, this.F()); },
    // target tertimbang untuk kumpulan project (dibobot volume offered / jumlah hari)
    targetFor(rows, key) {
      const pp = this.perProject(rows); if (!pp.length) return C.DEFAULT_KPI[key];
      let w = 0, s = 0; pp.forEach(x => { const wt = key === 'scr' || key === 'sl' ? (x.agg.off || 0) : key === 'aht' ? (x.agg.acd || 0) : x.agg.days; const t = this.targets(x.project.id)[key]; if (C.isNum(t) && wt > 0) { w += wt; s += t * wt; } });
      if (w === 0) { const ts = pp.map(x => this.targets(x.project.id)[key]); return C.avg(ts); }
      return s / w;
    },
    alerts() {
      if (this._alerts && this._alertsKey === JSON.stringify(this.filter)) return this._alerts;
      const rows = this.rows();
      const pp = this.perProject(rows); const tg = {}; pp.forEach(x => tg[x.project.id] = this.targets(x.project.id));
      this._alerts = C.buildAlerts(pp, tg, this.F()); this._alertsKey = JSON.stringify(this.filter);
      return this._alerts;
    },
    async audit(activity, detail = '', projectId = '', status = 'Success') {
      try { await this.ds.audit({ userId: this.profile ? this.profile.id : null, userName: this.profile ? this.profile.name : '-', role: this.profile ? this.profile.role : '-', activity, detail, projectId, status }); } catch (e) { }
    },
    periodLabel() {
      const f = this.filter; if (f.from || f.to) return `${f.from || 'awal'} s/d ${f.to || 'akhir'}`;
      if (f.month) return C.ymLabel(f.month);
      const m = this.months(); return m.length ? `${C.ymLabel(m[0])} – ${C.ymLabel(m[m.length - 1])}` : 'Belum ada data';
    },
    go(route) { if (location.hash.slice(1) !== route) location.hash = route; else this.render(); },
    afterRender: [],
    onMount(fn) { this.afterRender.push(fn); }
  };
  const CHS = C.CHANNELS.map(c => c.k);

  /* =================== BOOT =================== */
  async function boot() {
    let ds = null;
    const mode = cfg.mode || 'auto';
    if (mode === 'firebase' || mode === 'auto') {
      try { await window.FirebaseDataService.init(); ds = window.FirebaseDataService; }
      catch (e) { console.warn('Firebase tidak tersedia, beralih ke mode demo:', e); if (mode === 'firebase') { fatal('Tidak dapat terhubung ke Firebase: ' + (e.message || e)); return; } }
    }
    if (!ds) { ds = window.DemoDataService; await ds.init(); }
    App.ds = ds;
    try { const t = localStorage.getItem('ccpm-theme'); if (t) document.documentElement.setAttribute('data-theme', t); } catch (e) { }
    let first = true;
    ds.onAuthChange(async (profile, err) => {
      if (!profile) { App.profile = null; stopIdle(); renderLogin(err); return; }
      if (App.profile && App.profile.id === profile.id && !first) { App.profile = profile; App.computeScope(); renderShell(); return; }
      first = false; App.profile = profile;
      document.getElementById('app').innerHTML = `<div class="loading"><div class="spinner"></div><div>Memuat data performa…</div></div>`;
      try { await App.loadAll(); } catch (e) { console.error(e); U.toast('Gagal memuat data: ' + (e.message || e), 'bad'); }
      const allowed = firstAllowed(); const want = location.hash.slice(1);
      App.route = Pages[want] && allowedRoute(want) ? want : allowed;
      startIdle(); renderShell();
    });
  }
  function fatal(msg) { setTimeout(() => { const b = document.getElementById('reloadBtn'); if (b) b.addEventListener('click', () => location.reload()); }, 0); document.getElementById('app').innerHTML = `<div class="loading"><div style="max-width:520px;text-align:center"><b>Aplikasi tidak dapat dimulai</b><p class="muted">${esc(msg)}</p><button class="btn primary" id="reloadBtn">Muat ulang</button></div></div>`; }
  function allowedRoute(r) { const pg = Pages[r]; if (!pg) return false; return !pg.perm || (Array.isArray(pg.perm) ? pg.perm.some(p => App.can(p)) : App.can(pg.perm)) || (pg.allow && pg.allow()); }
  function firstAllowed() { for (const [, items] of NAV) for (const r of items) if (allowedRoute(r)) return r; return 'upload'; }

  /* =================== LOGIN =================== */
  async function renderLogin(err) {
    const ds = App.ds; const demo = ds.mode === 'demo';
    let needsSetup = false; try { needsSetup = (await ds.bootstrapStatus()).needsSetup; } catch (e) { }
    const seed = window.SEED; const projN = seed ? seed.projects.length : 0; const rowsN = seed ? Object.values(seed.months).reduce((a, r) => a + r.length, 0) : 0;
    document.getElementById('app').innerHTML = `
    <div class="login">
      <section class="login-brand">
        <div class="brand-mark"><div class="logo">${U.icon('phone')}</div><span>${esc(cfg.corporateName)}</span></div>
        <div><h1>Contact Center Performance Management</h1><p>Satu platform untuk memantau SCR, service level, kualitas, workforce, dan channel digital seluruh project contact center pemerintahan.</p></div>
        <div class="login-stats"><div><b>${projN}</b><span>project aktif</span></div><div><b>${rowsN.toLocaleString('id-ID')}</b><span>baris data harian</span></div><div><b>15</b><span>channel digital</span></div></div>
      </section>
      <section class="login-form-wrap">
        ${needsSetup ? setupForm() : `
        <form class="login-form" id="loginForm" novalidate>
          <div><h2>Masuk</h2><p class="sub">Gunakan akun korporat Anda.</p></div>
          ${demo ? `<div class="demo-box"><b>Mode demo</b> berjalan tanpa server. Pilih akun untuk mencoba setiap role (password: <span class="mono">${esc(ds.demoPassword)}</span>).
            <div class="accts">${[['superadmin@demo.id', 'Super Admin'], ['corporate@demo.id', 'Corporate Admin'], ['pm.bmkg@demo.id', 'Project Manager'], ['admin.dikti@demo.id', 'Project Admin'], ['dataentry@demo.id', 'Data Entry'], ['viewer.kejagung@demo.id', 'Viewer']].map(([e, l]) => `<button type="button" data-acct="${e}">${l}</button>`).join('')}</div></div>` : ''}
          <div class="field"><label for="lg-id">Email / Username</label><input class="input" id="lg-id" autocomplete="username" required></div>
          <div class="field"><label for="lg-pw">Password</label><input class="input" id="lg-pw" type="password" autocomplete="current-password" required></div>
          <div class="row" style="justify-content:space-between"><label class="check"><input type="checkbox" id="lg-rem" checked> Ingat saya</label><button type="button" class="link-btn" id="forgot">Lupa password?</button></div>
          <div class="err-msg" id="lg-err" role="alert">${esc(err || '')}</div>
          <button class="btn primary" type="submit" id="lg-btn">Masuk</button>
          <p class="muted small" style="margin:0">Akses dicatat dalam audit log. Sesi berakhir otomatis setelah ${cfg.sessionTimeoutMinutes} menit tidak aktif.</p>
        </form>`}
      </section>
    </div>`;
    if (needsSetup) return bindSetup();
    const form = document.getElementById('loginForm');
    form.querySelectorAll('[data-acct]').forEach(b => b.addEventListener('click', () => { document.getElementById('lg-id').value = b.dataset.acct; document.getElementById('lg-pw').value = ds.demoPassword; }));
    form.addEventListener('submit', async e => {
      e.preventDefault(); const id = document.getElementById('lg-id').value.trim(), pw = document.getElementById('lg-pw').value, rem = document.getElementById('lg-rem').checked;
      const er = document.getElementById('lg-err'); er.textContent = '';
      if (!id || !pw) { er.textContent = 'Isi email/username dan password.'; return; }
      const btn = document.getElementById('lg-btn'); btn.disabled = true; btn.textContent = 'Memeriksa…';
      try { const p = await ds.login(id, pw, rem); App.profile = p; await App.audit('Login', 'Login berhasil'); }
      catch (x) { er.textContent = x.message; btn.disabled = false; btn.textContent = 'Masuk'; }
    });
    document.getElementById('forgot').addEventListener('click', () => {
      const m = U.modal({ title: 'Lupa password', body: `<div class="stack"><p class="muted" style="margin:0">Masukkan email akun. Tautan reset password akan dikirim ke email tersebut.</p><div class="field"><label for="fp-email">Email</label><input class="input" id="fp-email" type="email" value="${esc(document.getElementById('lg-id').value)}"></div><div class="err-msg" id="fp-err"></div></div>`, foot: `<button class="btn" data-close>Batal</button><button class="btn primary" id="fp-send">Kirim tautan reset</button>` });
      m.el.querySelector('#fp-send').addEventListener('click', async () => {
        const em = m.el.querySelector('#fp-email').value.trim(); if (!/^\S+@\S+\.\S+$/.test(em)) { m.el.querySelector('#fp-err').textContent = 'Format email tidak valid.'; return; }
        try { const r = await ds.forgotPassword(em); m.close(); U.toast(r.demo ? 'Mode demo: email tidak benar-benar dikirim. Password demo tetap ' + ds.demoPassword : 'Jika email terdaftar, tautan reset sudah dikirim.', 'ok'); }
        catch (x) { m.el.querySelector('#fp-err').textContent = x.message; }
      });
    });
  }
  function setupForm() {
    return `<form class="login-form" id="setupForm" novalidate>
      <div><h2>Setup awal</h2><p class="sub">Belum ada Super Admin di database. Buat akun Super Admin pertama.</p></div>
      <div class="field"><label for="su-name">Nama lengkap</label><input class="input" id="su-name" required></div>
      <div class="field"><label for="su-email">Email</label><input class="input" id="su-email" type="email" required></div>
      <div class="field"><label for="su-pw">Password (min. 8 karakter)</label><input class="input" id="su-pw" type="password" required></div>
      <div class="field"><label for="su-pw2">Konfirmasi password</label><input class="input" id="su-pw2" type="password" required></div>
      <div class="err-msg" id="su-err"></div>
      <button class="btn primary" type="submit">Buat Super Admin</button></form>`;
  }
  function bindSetup() {
    document.getElementById('setupForm').addEventListener('submit', async e => {
      e.preventDefault(); const g = id => document.getElementById(id).value.trim(); const er = document.getElementById('su-err');
      if (!g('su-name') || !/^\S+@\S+\.\S+$/.test(g('su-email'))) { er.textContent = 'Nama dan email wajib diisi dengan benar.'; return; }
      if (g('su-pw').length < 8) { er.textContent = 'Password minimal 8 karakter.'; return; }
      if (g('su-pw') !== g('su-pw2')) { er.textContent = 'Konfirmasi password tidak sama.'; return; }
      try { await App.ds.createFirstAdmin({ name: g('su-name'), email: g('su-email'), password: g('su-pw') }); await App.audit('Create User', 'Super Admin pertama dibuat'); }
      catch (x) { er.textContent = x.message; }
    });
  }

  /* =================== SHELL =================== */
  function renderShell() {
    const p = App.profile; const demo = App.ds.mode === 'demo';
    const nav = NAV.map(([g, items]) => { const vis = items.filter(allowedRoute); return vis.length ? `<div class="nav-group">${g}</div>${vis.map(r => `<a class="nav-item ${App.route === r ? 'active' : ''}" href="#${r}" data-route="${r}">${U.icon(Pages[r].icon)}<span>${esc(Pages[r].title)}</span></a>`).join('')}` : ''; }).join('');
    const initials = (p.name || '?').split(/\s+/).map(s => s[0]).slice(0, 2).join('').toUpperCase();
    document.getElementById('app').innerHTML = `
    <div class="shell" id="shell">
      <aside class="side" aria-label="Navigasi utama">
        <div class="side-head"><div class="logo">${U.icon('phone')}</div><div>CC Performance<br><span style="font-weight:500;color:#8FA3C4;font-size:11.5px">Management Platform</span></div></div>
        <nav>${nav}</nav>
        <div class="side-foot"><span class="mode-pill ${demo ? 'demo' : ''}"><i></i>${demo ? 'Mode demo' : 'Firebase terhubung'}</span><div style="margin-top:6px">${esc(cfg.corporateName)}</div></div>
      </aside>
      <div class="main">
        <header class="topbar">
          <button class="icon-btn menu-btn" id="menuBtn" aria-label="Buka menu">${U.icon('menu')}</button>
          <div class="crumb"><div class="corp">${esc(cfg.corporateName)} · ${esc(Pages[App.route].title)}</div><div class="active-proj" id="activeProj"></div></div>
          <div class="top-actions">
            <button class="icon-btn" id="themeBtn" aria-label="Ganti tema">${U.icon(document.documentElement.getAttribute('data-theme') === 'dark' ? 'sun' : 'moon')}</button>
            <div style="position:relative"><button class="icon-btn" id="bellBtn" aria-label="Notifikasi">${U.icon('bell')}<span class="badge-dot" id="bellCount" hidden></span></button></div>
            <div style="position:relative"><button class="user-chip" id="userBtn" aria-label="Profil"><span class="avatar">${esc(initials)}</span><span class="who"><b>${esc(p.name)}</b><span>${esc((C.ROLES[p.role] || {}).label || p.role)}</span></span></button></div>
          </div>
        </header>
        <main class="content" id="content"></main>
      </div>
    </div>`;
    document.getElementById('menuBtn').addEventListener('click', () => document.getElementById('shell').classList.toggle('nav-open'));
    document.getElementById('shell').addEventListener('click', e => { if (e.target.id === 'shell') e.currentTarget.classList.remove('nav-open'); });
    document.querySelectorAll('.nav-item').forEach(a => a.addEventListener('click', () => document.getElementById('shell').classList.remove('nav-open')));
    document.getElementById('themeBtn').addEventListener('click', toggleTheme);
    document.getElementById('bellBtn').addEventListener('click', e => { e.stopPropagation(); openNotif(); });
    document.getElementById('userBtn').addEventListener('click', e => { e.stopPropagation(); openUserMenu(); });
    App.render();
  }
  function toggleTheme() {
    const cur = document.documentElement.getAttribute('data-theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    const next = cur === 'dark' ? 'light' : 'dark'; document.documentElement.setAttribute('data-theme', next);
    try { localStorage.setItem('ccpm-theme', next); } catch (e) { }
    renderShell();
  }
  function closeDrops() { document.querySelectorAll('.dropdown').forEach(d => d.remove()); }
  document.addEventListener('click', e => { if (!e.target.closest('.dropdown')) closeDrops(); });
  function openNotif() {
    closeDrops(); const host = document.getElementById('bellBtn').parentElement;
    const al = App.can('dashboard.view') ? App.alerts() : [];
    const ups = App.data.uploads.slice(0, 5);
    const d = document.createElement('div'); d.className = 'dropdown';
    d.innerHTML = `<header><span>Notifikasi</span><span class="muted small">${esc(App.periodLabel())}</span></header><div class="list">
      ${al.length ? al.slice(0, 30).map(a => `<div class="notif"><span class="sev" style="background:var(--${a.severity === 'bad' ? 'bad' : 'risk'})"></span><div>⚠ ${esc(a.text)}</div></div>`).join('') : `<div class="notif"><span class="sev" style="background:var(--ok)"></span><div>Semua KPI dalam target untuk filter saat ini.</div></div>`}
      ${ups.length ? `<div class="notif"><b>Upload terbaru</b></div>` + ups.map(u => `<div class="notif"><span class="sev" style="background:var(--info)"></span><div>${esc(u.fileName)} · ${esc(u.projectName || '')}<br><span class="muted small">${esc(u.status)} · ${esc((u.uploadedAt || '').slice(0, 16).replace('T', ' '))} · ${esc(u.uploadedBy || '')}</span></div></div>`).join('') : ''}
    </div>`;
    host.appendChild(d);
  }
  function openUserMenu() {
    closeDrops(); const host = document.getElementById('userBtn').parentElement; const p = App.profile;
    const d = document.createElement('div'); d.className = 'dropdown'; d.style.width = '280px';
    d.innerHTML = `<header><div><div>${esc(p.name)}</div><div class="muted small" style="font-weight:500">${esc(p.email)}</div></div></header>
      <div style="padding:12px 14px" class="stack small"><div><span class="muted">Role</span><br><b>${esc((C.ROLES[p.role] || {}).label)}</b></div>
      <div><span class="muted">Akses project</span><br>${App.scopeIds ? (App.scopeIds.length ? App.scopeIds.map(id => `<span class="tag">${esc(App.proj(id).code || id)}</span>`).join('') : 'Belum ada project') : '<b>Semua project</b>'}</div>
      <div><span class="muted">Login terakhir</span><br>${esc((p.lastLogin || '-').slice(0, 16).replace('T', ' '))}</div>
      <button class="btn danger" id="logoutBtn">${U.icon('logout')} Logout</button></div>`;
    host.appendChild(d);
    d.querySelector('#logoutBtn').addEventListener('click', logout);
  }
  async function logout(reason) { await App.audit('Logout', typeof reason === 'string' ? reason : 'Logout manual'); U.destroyCharts(); await App.ds.logout(); if (typeof reason === 'string') U.toast(reason); }

  /* ---------- idle session ---------- */
  let idleT = null; const idleEvents = ['mousemove', 'keydown', 'click', 'touchstart', 'scroll'];
  function resetIdle() { clearTimeout(idleT); idleT = setTimeout(() => { if (App.profile) logout('Sesi berakhir karena tidak aktif.'); }, (cfg.sessionTimeoutMinutes || 30) * 60000); }
  function startIdle() { idleEvents.forEach(ev => window.addEventListener(ev, resetIdle, { passive: true })); resetIdle(); }
  function stopIdle() { clearTimeout(idleT); idleEvents.forEach(ev => window.removeEventListener(ev, resetIdle)); }

  /* =================== FILTER BAR =================== */
  function filterBar() {
    const f = App.filter; const months = App.months();
    const custs = App.customersInScope(); const projs = App.projectsInScope().filter(p => !f.customer || p.customerId === f.customer);
    return `<form class="filters" id="filterForm" aria-label="Filter global">
      <div class="field"><label for="f-cust">Customer</label><select class="input" id="f-cust"><option value="">Semua customer</option>${custs.map(c => `<option value="${c.id}" ${f.customer === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
      <div class="field"><label for="f-proj">Project</label><select class="input" id="f-proj"><option value="">Semua project</option>${projs.map(p => `<option value="${p.id}" ${f.project === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select></div>
      <div class="field"><label for="f-month">Bulan</label><select class="input" id="f-month"><option value="">Semua bulan</option>${months.map(m => `<option value="${m}" ${f.month === m ? 'selected' : ''}>${C.ymLabel(m)}</option>`).join('')}</select></div>
      <div class="field wide"><label for="f-from">Rentang tanggal</label><div class="range"><input class="input" type="date" id="f-from" value="${f.from}" aria-label="Dari tanggal"><input class="input" type="date" id="f-to" value="${f.to}" aria-label="Sampai tanggal"></div></div>
      <div class="field"><label for="f-ch">Channel</label><select class="input" id="f-ch"><option value="">Semua channel</option><option value="inbound" ${f.channel === 'inbound' ? 'selected' : ''}>Inbound (Voice)</option><option value="outbound" ${f.channel === 'outbound' ? 'selected' : ''}>Outbound</option><option value="digital" ${f.channel === 'digital' ? 'selected' : ''}>Semua Digital</option>${C.CHANNELS.map(c => `<option value="${c.k}" ${f.channel === c.k ? 'selected' : ''}>${esc(c.label)}</option>`).join('')}</select></div>
      <div class="btns"><button type="button" class="btn" id="f-reset">Reset Filter</button><button type="submit" class="btn primary">Apply Filter</button></div>
    </form>`;
  }
  function bindFilter() {
    const form = document.getElementById('filterForm'); if (!form) return;
    form.querySelector('#f-cust').addEventListener('change', e => {
      const cid = e.target.value; const sel = form.querySelector('#f-proj'); const cur = sel.value;
      const projs = App.projectsInScope().filter(p => !cid || p.customerId === cid);
      sel.innerHTML = `<option value="">Semua project</option>` + projs.map(p => `<option value="${p.id}" ${cur === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
    });
    form.addEventListener('submit', e => {
      e.preventDefault(); const g = id => form.querySelector(id).value;
      const nf = { customer: g('#f-cust'), project: g('#f-proj'), month: g('#f-month'), from: g('#f-from'), to: g('#f-to'), channel: g('#f-ch') };
      if (nf.from && nf.to && nf.from > nf.to) { U.toast('Tanggal awal harus sebelum tanggal akhir.', 'bad'); return; }
      if (nf.project && nf.customer && App.proj(nf.project).customerId !== nf.customer) nf.project = '';
      App.filter = nf; App.render();
    });
    form.querySelector('#f-reset').addEventListener('click', () => { App.filter = { customer: '', project: '', month: '', from: '', to: '', channel: '' }; App.render(); });
  }

  /* =================== RENDER ROUTE =================== */
  App.render = function () {
    const content = document.getElementById('content'); if (!content) return;
    U.destroyCharts(); App.afterRender = [];
    let r = App.route; if (!allowedRoute(r)) { r = App.route = firstAllowed(); }
    const pg = Pages[r];
    document.querySelectorAll('.nav-item').forEach(a => a.classList.toggle('active', a.dataset.route === r));
    const crumb = document.querySelector('.crumb .corp'); if (crumb) crumb.textContent = `${cfg.corporateName} · ${pg.title}`;
    const f = App.filter;
    const ap = document.getElementById('activeProj');
    if (ap) ap.textContent = f.project ? App.proj(f.project).name : f.customer ? App.cust(f.customer).name : (App.scopeIds ? `${App.scopeIds.length} project ditugaskan` : `Semua project (${App.projectsInScope().length})`);
    const bell = document.getElementById('bellCount');
    if (bell) { const n = App.can('dashboard.view') ? App.alerts().length : 0; bell.hidden = !n; bell.textContent = n > 99 ? '99+' : n; }
    const banner = App.ds.mode === 'demo' ? `<div class="demo-banner">${U.icon('info')}<span><b>Mode demo</b>: perubahan tersimpan di browser ini saja. Deploy ke Firebase untuk penyimpanan bersama, autentikasi, dan audit terpusat.</span></div>` : '';
    let html = '';
    try { html = pg.render(); } catch (e) { console.error(e); html = U.empty('Halaman gagal dimuat', e.message); }
    content.innerHTML = banner + (pg.filters ? filterBar() : '') + html;
    bindFilter();
    try { pg.mount && pg.mount(); App.afterRender.forEach(fn => fn()); } catch (e) { console.error(e); U.toast('Sebagian komponen gagal dimuat: ' + e.message, 'bad'); }
    content.scrollTop = 0; window.scrollTo(0, 0);
  };
  window.addEventListener('hashchange', () => { const r = location.hash.slice(1); if (Pages[r] && App.profile) { App.route = r; App.render(); } });
  // tab helper for pages
  App.tabs = (key, tabs) => { const cur = App.subTab[key] || tabs[0][0]; return { cur, html: `<div class="tabs" role="tablist">${tabs.map(([k, l]) => `<button class="tab ${cur === k ? 'active' : ''}" role="tab" aria-selected="${cur === k}" data-tabkey="${key}" data-tab="${k}">${esc(l)}</button>`).join('')}</div>` }; };
  document.addEventListener('click', e => { const t = e.target.closest('[data-tabkey]'); if (t) { App.subTab[t.dataset.tabkey] = t.dataset.tab; App.render(); } });

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
