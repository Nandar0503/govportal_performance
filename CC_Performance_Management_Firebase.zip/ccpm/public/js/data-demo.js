/* =========================================================================
 * DATA SERVICE - MODE DEMO
 * Implementasi in-memory dengan antarmuka yang sama persis dengan
 * data-firebase.js. Dipakai untuk pratinjau / demonstrasi tanpa backend.
 * Data disimpan di browser (localStorage) bila tersedia.
 * ========================================================================= */
(function () {
  'use strict';
  const C = window.Core;
  const KEY = 'ccpm-demo-v2';
  const DEMO_PASSWORD = 'Demo#2026';
  let S = null; let session = null; const listeners = [];

  const store = {
    get(k, sess) { try { return (sess ? sessionStorage : localStorage).getItem(k); } catch (e) { return null; } },
    set(k, v, sess) { try { (sess ? sessionStorage : localStorage).setItem(k, v); } catch (e) { } },
    del(k) { try { localStorage.removeItem(k); sessionStorage.removeItem(k); } catch (e) { } }
  };
  let saveTimer = null;
  function persist() { clearTimeout(saveTimer); saveTimer = setTimeout(() => store.set(KEY, JSON.stringify(S)), 300); }
  const clone = o => JSON.parse(JSON.stringify(o));
  const now = () => new Date().toISOString();

  async function freshState() {
    const seed = window.SEED;
    const hash = await C.sha256('ccpm:' + DEMO_PASSWORD);
    const u = (id, name, email, role, projects = [], customers = []) => ({ id, name, username: email.split('@')[0], email, phone: '', role, projects, customers, status: 'active', createdAt: now(), lastLogin: null, pwHash: hash });
    const st = {
      users: [
        u('u-super', 'Super Admin', 'superadmin@demo.id', 'super_admin'),
        u('u-corp', 'Corporate Admin', 'corporate@demo.id', 'corporate_admin'),
        u('u-pm', 'PM Kebencanaan & Cuaca', 'pm.bmkg@demo.id', 'project_manager', ['PRJ-BMKG', 'PRJ-BNPB', 'PRJ-BASARNAS']),
        u('u-padm', 'Admin Project Dikti', 'admin.dikti@demo.id', 'project_admin', ['PRJ-DIKTI']),
        u('u-entry', 'Performance Admin', 'dataentry@demo.id', 'data_entry', ['PRJ-KEJAGUNG', 'PRJ-KEMENKOP', 'PRJ-KEMENHUB']),
        u('u-view', 'Viewer Kejaksaan', 'viewer.kejagung@demo.id', 'viewer', ['PRJ-KEJAGUNG'], ['CUS-KEJAGUNG'])
      ],
      customers: clone(seed.customers), projects: clone(seed.projects), kpi: clone(seed.kpi),
      settings: { formulas: clone(C.DEFAULT_FORMULAS), permissions: clone(C.DEFAULT_ROLE_PERMS) },
      months: {}, agents: clone(seed.agents), uploads: [], uploadErrors: {}, issues: {}, reports: [], audit: [], loginHistory: [], loginAttempts: []
    };
    Object.entries(seed.months).forEach(([key, rows]) => {
      const [pid, period] = key.split('_'); const p = seed.projects.find(x => x.id === pid);
      st.months[key] = { id: key, projectId: pid, customerId: p ? p.customerId : '', period, rows, source: 'seed', uploadId: null, updatedAt: seed.generatedAt, updatedBy: 'Import data awal' };
    });
    st.uploads.push({ id: 'up-seed', fileName: 'dashboard_performance_govseg3_ytd_2026_fixed.xlsx', projectId: '*', projectName: 'Semua project (data awal)', period: '2026-01 s/d 2026-09', totalRows: Object.values(seed.months).reduce((a, r) => a + r.length, 0), validRows: Object.values(seed.months).reduce((a, r) => a + r.length, 0), errorRows: 0, duplicateRows: 0, missingData: 0, uploadedAt: seed.generatedAt, uploadedBy: 'Sistem', status: 'Approved', note: 'Import data awal dari file Excel yang diberikan' });
    return st;
  }

  function profileOf(u) { if (!u) return null; const p = clone(u); delete p.pwHash; return p; }
  function emit() { const p = session ? profileOf(S.users.find(u => u.id === session.uid)) : null; listeners.forEach(f => f(p)); }
  function inScope(pid, ids) { return !ids || ids.includes(pid); }

  const DS = {
    mode: 'demo',
    demoPassword: DEMO_PASSWORD,
    async init() {
      const raw = store.get(KEY);
      if (raw) { try { S = JSON.parse(raw); } catch (e) { S = null; } }
      if (!S || !S.users) { S = await freshState(); persist(); }
      const sraw = store.get('ccpm-demo-session', true) || store.get('ccpm-demo-session');
      if (sraw) { try { session = JSON.parse(sraw); } catch (e) { session = null; } }
      if (session) { const u = S.users.find(x => x.id === session.uid); if (!u || u.status !== 'active') session = null; }
      setTimeout(emit, 0);
      return 'demo';
    },
    async resetDemo() { store.del(KEY); store.del('ccpm-demo-session'); S = await freshState(); persist(); session = null; emit(); },
    onAuthChange(cb) { listeners.push(cb); },
    sessionId() { return session ? session.sid : '-'; },
    async bootstrapStatus() { return { needsSetup: false }; },
    async login(email, password, remember) {
      email = String(email || '').trim().toLowerCase();
      const u = S.users.find(x => x.email.toLowerCase() === email || x.username.toLowerCase() === email);
      const recent = S.loginAttempts.filter(a => a.email === email && Date.now() - new Date(a.at).getTime() < 5 * 60000);
      if (recent.length >= 5) throw new Error('Terlalu banyak percobaan gagal. Coba lagi dalam 5 menit.');
      const fail = async reason => { S.loginAttempts.unshift({ id: C.uid('la'), email, at: now(), reason }); persist(); throw new Error(reason); };
      if (!u) return fail('Email/username atau password salah.');
      if (u.pwHash !== await C.sha256('ccpm:' + password)) return fail('Email/username atau password salah.');
      if (u.status !== 'active') return fail('Akun dinonaktifkan. Hubungi administrator.');
      session = { uid: u.id, sid: C.uid('sess'), at: now() };
      store.del('ccpm-demo-session'); store.set('ccpm-demo-session', JSON.stringify(session), !remember);
      u.lastLogin = now();
      S.loginHistory.unshift({ id: C.uid('lh'), userId: u.id, userName: u.name, email: u.email, at: now(), sessionId: session.sid, agent: navigator.userAgent.slice(0, 80) });
      persist(); emit();
      return profileOf(u);
    },
    async logout() { session = null; store.del('ccpm-demo-session'); emit(); },
    async forgotPassword(email) { const u = S.users.find(x => x.email.toLowerCase() === String(email).trim().toLowerCase()); return { sent: true, demo: true, exists: !!u }; },
    async changePassword(userId, pw) { const u = S.users.find(x => x.id === userId); if (u) { u.pwHash = await C.sha256('ccpm:' + pw); persist(); } },
    // USERS
    async listUsers() { return S.users.map(profileOf); },
    async createUser(data, password) {
      if (S.users.some(u => u.email.toLowerCase() === data.email.toLowerCase())) throw new Error('Email sudah terdaftar.');
      const u = Object.assign({ id: C.uid('u'), createdAt: now(), lastLogin: null, status: 'active' }, clone(data), { pwHash: await C.sha256('ccpm:' + password) });
      S.users.push(u); persist(); return profileOf(u);
    },
    async updateUser(id, patch) { const u = S.users.find(x => x.id === id); if (!u) throw new Error('User tidak ditemukan'); Object.assign(u, clone(patch)); persist(); if (session && id === session.uid) emit(); return profileOf(u); },
    async deleteUser(id) { S.users = S.users.filter(x => x.id !== id); persist(); },
    async adminResetPassword(user) { await this.changePassword(user.id, DEMO_PASSWORD); return { demo: true, password: DEMO_PASSWORD }; },
    // MASTER
    async listCustomers() { return clone(S.customers); },
    async saveCustomer(c) { const i = S.customers.findIndex(x => x.id === c.id); if (i >= 0) S.customers[i] = clone(c); else S.customers.push(clone(c)); persist(); },
    async deleteCustomer(id) { S.customers = S.customers.filter(x => x.id !== id); persist(); },
    async listProjects() { return clone(S.projects); },
    async saveProject(p) { const i = S.projects.findIndex(x => x.id === p.id); if (i >= 0) S.projects[i] = clone(p); else S.projects.push(clone(p)); persist(); },
    async deleteProject(id) { S.projects = S.projects.filter(x => x.id !== id); Object.keys(S.months).forEach(k => { if (S.months[k].projectId === id) delete S.months[k]; }); persist(); },
    async getKpiTargets() { return clone(S.kpi); },
    async saveKpiTarget(pid, obj) { S.kpi[pid] = clone(obj); persist(); },
    async getSettings() { return clone(S.settings); },
    async saveSetting(key, val) { S.settings[key] = clone(val); persist(); },
    // PERFORMANCE
    async loadPerformance(ids) { const o = {}; Object.entries(S.months).forEach(([k, v]) => { if (inScope(v.projectId, ids)) o[k] = v; }); return clone(o); },
    async getPerformanceMonth(key) { return S.months[key] ? clone(S.months[key]) : null; },
    async savePerformanceMonth(doc) { S.months[doc.id] = clone(doc); persist(); },
    async deletePerformanceMonth(key) { delete S.months[key]; persist(); },
    async loadAgents(ids) { return clone(S.agents.filter(a => inScope(a.projectId, ids))); },
    // UPLOADS
    async listUploads(ids) { return clone(S.uploads.filter(u => u.projectId === '*' ? !ids : inScope(u.projectId, ids))); },
    async saveUpload(rec) { const i = S.uploads.findIndex(x => x.id === rec.id); if (i >= 0) S.uploads[i] = clone(rec); else S.uploads.unshift(clone(rec)); persist(); },
    async deleteUpload(id) { S.uploads = S.uploads.filter(x => x.id !== id); delete S.uploadErrors[id]; persist(); },
    async saveUploadErrors(id, errors) { S.uploadErrors[id] = clone(errors.list || errors); persist(); },
    async getUploadErrors(id) { return clone(S.uploadErrors[id] || []); },
    async uploadFile(file, path) { return { path, url: null, stored: false, note: 'Mode demo: file tidak disimpan ke storage.' }; },
    // ISSUES & REPORTS
    async listIssues(ids) { return clone(Object.values(S.issues).filter(i => inScope(i.projectId, ids))); },
    async saveIssue(issue) { S.issues[issue.id] = clone(issue); persist(); },
    async listReports() { return clone(S.reports); },
    async saveReport(r) { const i = S.reports.findIndex(x => x.id === r.id); if (i >= 0) S.reports[i] = clone(r); else S.reports.unshift(clone(r)); persist(); },
    async deleteReport(id) { S.reports = S.reports.filter(x => x.id !== id); persist(); },
    // AUDIT
    async audit(e) { S.audit.unshift(Object.assign({ id: C.uid('al'), at: now(), sessionId: session ? session.sid : '-' }, e)); if (S.audit.length > 2000) S.audit.length = 2000; persist(); },
    async listAudit(limit = 500) { return clone(S.audit.slice(0, limit)); },
    async listLoginHistory(limit = 300) { return clone(S.loginHistory.slice(0, limit)); },
    async listFailedLogins(limit = 300) { return clone(S.loginAttempts.slice(0, limit)); },
    async importSeed() { const fresh = await freshState(); S.months = fresh.months; S.agents = fresh.agents; persist(); return { months: Object.keys(S.months).length }; },
    async countRecords() { return Object.values(S.months).reduce((a, m) => a + m.rows.length, 0); }
  };
  window.DemoDataService = DS;
})();
