/* =========================================================================
 * UI KIT: ikon, komponen (KPI card, tabel, modal, toast), helper chart,
 * dan utilitas file (download / export).
 * ========================================================================= */
(function () {
  'use strict';
  const C = window.Core; const esc = C.esc;

  /* ---------- ICONS (stroke 1.8, 24px) ---------- */
  const P = {
    exec: '<path d="M3 13h8V3H3zM13 21h8V11h-8zM13 3v6h8V3zM3 21h8v-6H3z"/>',
    portfolio: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
    project: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M8 4v5"/>',
    channel: '<path d="M4 6h16M4 12h10M4 18h6"/><circle cx="18" cy="15" r="3"/>',
    traffic: '<path d="M22 12h-4l-3 8L9 4l-3 8H2"/>',
    sla: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    quality: '<path d="M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.5 6.7 19.4l1.2-6L3.4 9.3l6-.7z"/>',
    workforce: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.6 3.3-5.5 6.5-5.5s5.9 1.9 6.5 5.5"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c2.4 0 4.2 1.4 4.6 4"/>',
    digital: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20.5l1.4-4.9A8 8 0 1 1 21 12z"/>',
    master: '<path d="M4 21V8l8-5 8 5v13"/><path d="M9 21v-6h6v6"/>',
    upload: '<path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
    report: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/>',
    users: '<circle cx="12" cy="8" r="4"/><path d="M4 21c.8-4 4-6 8-6s7.2 2 8 6"/>',
    access: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    audit: '<path d="M9 5h11M9 12h11M9 19h11"/><path d="M4 5h.01M4 12h.01M4 19h.01"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>',
    alert: '<path d="M12 3l10 18H2z"/><path d="M12 10v4M12 18h.01"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    download: '<path d="M12 4v12M7 11l5 5 5-5"/><path d="M4 20h16"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    file: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-2.6-6.4L21 8"/><path d="M21 3v5h-5"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.4 8-8 9-4.6-1-8-4-8-9V6z"/>'
  };
  const icon = (n, cls = '') => `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n] || P.info}</svg>`;

  /* ---------- KOMPONEN ---------- */
  const pill = (st, label) => `<span class="pill ${st}">${esc(label || C.STATUS_LABEL[st] || st)}</span>`;
  const empty = (title, msg) => `<div class="empty"><b>${esc(title)}</b>${esc(msg || '')}</div>`;
  function card(title, body, opts = {}) {
    return `<section class="card ${opts.span || 's12'} ${opts.cls || ''}" ${opts.id ? `id="${opts.id}"` : ''}>
      ${title ? `<div class="card-h"><h3>${esc(title)}</h3>${opts.hint ? `<span class="hint">${esc(opts.hint)}</span>` : ''}${opts.tools || ''}</div>` : ''}
      <div class="card-b">${body}</div></section>`;
  }
  const chartBox = (id, cls = '') => `<div class="chart-box ${cls}"><canvas id="${id}" role="img" aria-label="grafik"></canvas></div>`;
  // KPI card: {label, value, icon, status, target, actual, ach, sub, spark:id}
  function kpi(o) {
    const st = o.status && o.status !== 'na' ? 'st-' + o.status : (o.info ? 'st-info' : '');
    return `<div class="kpi ${st}">
      <div class="lbl">${o.icon ? icon(o.icon) : ''}${esc(o.label)}</div>
      <div class="val" title="${esc(o.value)}">${esc(o.value)}</div>
      ${o.target !== undefined ? `<div class="tav"><span>Target</span><span>Aktual</span><span>Ach.</span><b>${esc(o.target)}</b><b>${esc(o.actual ?? o.value)}</b><b>${esc(o.ach ?? '–')}</b></div>` : ''}
      <div class="meta"><span>${o.sub ? esc(o.sub) : ''}</span>${o.status ? pill(o.status) : ''}</div>
      ${o.spark ? `<div class="spark"><canvas id="${o.spark}"></canvas></div>` : ''}
    </div>`;
  }
  function pageHead(eyebrow, title, desc, actions = '') {
    return `<div class="page-head"><div><div class="eyebrow">${esc(eyebrow)}</div><h1>${esc(title)}</h1>${desc ? `<p>${esc(desc)}</p>` : ''}</div><div class="page-actions">${actions}</div></div>`;
  }
  function barCell(v, max, target, color) {
    const w = C.isNum(v) && max > 0 ? Math.max(0, Math.min(100, v / max * 100)) : 0;
    const t = C.isNum(target) && max > 0 ? Math.min(100, target / max * 100) : null;
    return `<div class="bar-cell"><div class="track"><div class="fill" style="width:${w}%;background:${color || 'var(--accent)'}"></div>${t !== null ? `<div class="tick" style="left:${t}%"></div>` : ''}</div></div>`;
  }

  /* ---------- DATA TABLE ---------- */
  // columns: [{k, label, r(right), fmt(v,row) -> html, sort(row) -> value, wrap}]
  function dataTable(container, columns, rows, opts = {}) {
    const el = typeof container === 'string' ? document.getElementById(container) : container;
    if (!el) return;
    const st = { q: '', sortK: opts.sortK || null, dir: opts.dir || -1, page: 0, size: opts.pageSize || 15 };
    function render() {
      let data = rows;
      if (st.q) { const q = st.q.toLowerCase(); data = data.filter(r => columns.some(c => String(c.sort ? c.sort(r) : r[c.k] ?? '').toLowerCase().includes(q))); }
      if (st.sortK) { const col = columns.find(c => c.k === st.sortK); const get = col && col.sort ? col.sort : r => r[st.sortK]; data = data.slice().sort((a, b) => { const x = get(a), y = get(b); if (x == null) return 1; if (y == null) return -1; return (x > y ? 1 : x < y ? -1 : 0) * st.dir; }); }
      const pages = Math.max(1, Math.ceil(data.length / st.size)); st.page = Math.min(st.page, pages - 1);
      const view = opts.noPaging ? data : data.slice(st.page * st.size, st.page * st.size + st.size);
      el.innerHTML = `${opts.search !== false ? `<div class="tbl-tools"><input class="input" type="search" placeholder="Cari…" value="${esc(st.q)}" aria-label="Cari di tabel">${opts.tools || ''}</div>` : ''}
        <div class="tbl-wrap"><table class="tbl ${opts.cls || ''}"><thead><tr>${columns.map(c => `<th class="${c.noSort ? '' : 'sortable'} ${c.r ? 'r' : ''}" data-k="${c.k}">${esc(c.label)}${st.sortK === c.k ? (st.dir > 0 ? ' ↑' : ' ↓') : ''}</th>`).join('')}</tr></thead>
        <tbody>${view.length ? view.map((r, i) => `<tr>${columns.map(c => `<td class="${c.r ? 'r' : ''} ${c.wrap ? 'wrap' : ''}">${c.fmt ? c.fmt(r[c.k], r, i) : esc(r[c.k] ?? '–')}</td>`).join('')}</tr>`).join('') : `<tr><td colspan="${columns.length}">${empty('Tidak ada data', opts.emptyMsg || 'Ubah filter atau upload data baru.')}</td></tr>`}</tbody></table></div>
        ${opts.noPaging ? '' : `<div class="tbl-foot"><span>${data.length.toLocaleString('id-ID')} baris</span><span class="row"><button class="btn sm" data-p="-1" ${st.page === 0 ? 'disabled' : ''}>Sebelumnya</button><span>${st.page + 1} / ${pages}</span><button class="btn sm" data-p="1" ${st.page >= pages - 1 ? 'disabled' : ''}>Berikutnya</button></span></div>`}`;
      const inp = el.querySelector('input[type=search]');
      if (inp) inp.addEventListener('input', e => { st.q = e.target.value; st.page = 0; const pos = e.target.selectionStart; render(); const n = el.querySelector('input[type=search]'); n.focus(); n.setSelectionRange(pos, pos); });
      el.querySelectorAll('th.sortable').forEach(th => th.addEventListener('click', () => { const k = th.dataset.k; if (st.sortK === k) st.dir *= -1; else { st.sortK = k; st.dir = -1; } render(); }));
      el.querySelectorAll('[data-p]').forEach(b => b.addEventListener('click', () => { st.page += +b.dataset.p; render(); }));
      opts.onRender && opts.onRender(el);
    }
    render();
    return { refresh(newRows) { if (newRows) rows = newRows; render(); } };
  }

  /* ---------- MODAL & TOAST ---------- */
  function modal({ title, body, foot, wide, onMount }) {
    const ov = document.createElement('div'); ov.className = 'overlay';
    ov.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal-h"><h3>${esc(title)}</h3><button class="icon-btn" data-close aria-label="Tutup">${icon('x')}</button></div><div class="modal-b">${body}</div>${foot ? `<div class="modal-f">${foot}</div>` : ''}</div>`;
    const close = () => { ov.remove(); document.removeEventListener('keydown', onKey); };
    const onKey = e => { if (e.key === 'Escape') close(); };
    ov.addEventListener('click', e => { if (e.target === ov || e.target.closest('[data-close]')) close(); });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(ov);
    const f = ov.querySelector('input,select,textarea'); if (f) setTimeout(() => f.focus(), 30);
    onMount && onMount(ov, close);
    return { el: ov, close };
  }
  function confirmBox(title, msg, okLabel = 'Ya, lanjutkan', danger = true) {
    return new Promise(res => {
      const m = modal({ title, body: `<p style="margin:0">${msg}</p>`, foot: `<button class="btn" data-close>Batal</button><button class="btn ${danger ? 'danger' : 'primary'}" data-ok>${esc(okLabel)}</button>` });
      m.el.querySelector('[data-ok]').addEventListener('click', () => { m.close(); res(true); });
      m.el.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', () => res(false)));
    });
  }
  function toast(msg, type = '') {
    const t = document.createElement('div'); t.className = 'toast ' + type; t.innerHTML = `${icon(type === 'bad' ? 'alert' : type === 'ok' ? 'check' : 'info')}<span>${esc(msg)}</span>`;
    document.getElementById('toasts').appendChild(t); setTimeout(() => t.remove(), 4800);
  }

  /* ---------- CHART ---------- */
  const charts = {};
  const css = v => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  const palette = () => ['--c1', '--c2', '--c3', '--c4', '--c5', '--c6', '--c7', '--c8'].map(css);
  const alpha = (hex, a) => { const h = hex.replace('#', ''); if (h.length !== 6) return hex; const n = parseInt(h, 16); return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`; };
  function destroyCharts() { Object.keys(charts).forEach(k => { try { charts[k].destroy(); } catch (e) { } delete charts[k]; }); }
  function chart(id, type, data, options = {}) {
    const cv = document.getElementById(id); if (!cv || !window.Chart) return null;
    if (charts[id]) { charts[id].destroy(); }
    const text = css('--muted'), grid = css('--line-2');
    Chart.defaults.font.family = css('--font') || 'sans-serif'; Chart.defaults.font.size = 11; Chart.defaults.color = text;
    const isCart = !['doughnut', 'pie'].includes(type);
    const base = {
      responsive: true, maintainAspectRatio: false, animation: { duration: 300 },
      interaction: { mode: isCart ? 'index' : 'nearest', intersect: false },
      plugins: { legend: { display: (data.datasets || []).length > 1 || !isCart, position: 'bottom', labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true, pointStyle: 'rectRounded', padding: 12 } },
        tooltip: { backgroundColor: css('--navy-900'), titleColor: '#fff', bodyColor: '#DCE6F5', padding: 10, cornerRadius: 8, boxPadding: 4 } },
      scales: isCart ? { x: { grid: { display: false }, ticks: { color: text, maxRotation: 0, autoSkip: true, autoSkipPadding: 8 }, border: { color: grid } }, y: { grid: { color: grid }, ticks: { color: text }, border: { display: false }, beginAtZero: true } } : undefined
    };
    const merged = deepMerge(base, options);
    charts[id] = new Chart(cv, { type, data, options: merged });
    return charts[id];
  }
  function spark(id, values, color) {
    const c = color || css('--c1');
    return chart(id, 'line', { labels: values.map((_, i) => i), datasets: [{ data: values, borderColor: c, backgroundColor: alpha(c, .12), fill: true, borderWidth: 1.6, pointRadius: values.map((_, i) => i === values.length - 1 ? 2.5 : 0), pointBackgroundColor: c, tension: .35, spanGaps: true }] },
      { plugins: { legend: { display: false }, tooltip: { enabled: false } }, scales: { x: { display: false }, y: { display: false, beginAtZero: false } }, animation: false });
  }
  function deepMerge(a, b) { const o = Array.isArray(a) ? a.slice() : Object.assign({}, a); Object.keys(b || {}).forEach(k => { if (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k]) && a && typeof a[k] === 'object' && a[k] !== null) o[k] = deepMerge(a[k], b[k]); else o[k] = b[k]; }); return o; }
  // gauge setengah lingkaran
  function gauge(id, value, target, st) {
    const v = C.isNum(value) ? Math.max(0, Math.min(100, value)) : 0;
    const col = st === 'ok' ? css('--ok') : st === 'risk' ? css('--risk') : st === 'bad' ? css('--bad') : css('--c5');
    return chart(id, 'doughnut', { labels: ['Aktual', 'Sisa'], datasets: [{ data: [v, 100 - v], backgroundColor: [col, css('--line-2')], borderWidth: 0, circumference: 180, rotation: 270, cutout: '74%' }] },
      { plugins: { legend: { display: false }, tooltip: { enabled: false } }, aspectRatio: 2 });
  }

  /* ---------- FILE / DOWNLOAD ---------- */
  let dlCap; // namespace capability downloads (hanya saat berjalan sebagai artifact)
  async function saveFile(filename, blob) {
    if (dlCap === undefined) { try { dlCap = window.claude && window.claude.use ? await window.claude.use('downloads') : null; } catch (e) { dlCap = null; } }
    if (dlCap) { try { await dlCap.save({ filename, data: blob }); return true; } catch (e) { if (e && e.code === 'cancelled') return false; toast('File tidak dapat disimpan: ' + (e.message || e.code), 'bad'); return false; } }
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000); return true;
  }
  function workbookBlob(wb) { const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array', cellDates: true }); return new Blob([out], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }); }
  const loaded = {};
  function loadScript(src) { if (loaded[src]) return loaded[src]; loaded[src] = new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => { delete loaded[src]; rej(new Error('Gagal memuat ' + src)); }; document.head.appendChild(s); }); return loaded[src]; }

  window.UI = { icon, pill, empty, card, chartBox, kpi, pageHead, barCell, dataTable, modal, confirmBox, toast, chart, spark, gauge, destroyCharts, palette, alpha, css, saveFile, workbookBlob, loadScript };
})();
