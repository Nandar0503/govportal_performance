/*
 * Konfigurasi aplikasi.
 *  mode: 'firebase' -> memakai Firebase Auth + Firestore + Storage (produksi)
 *        'demo'     -> data in-memory (pratinjau, tanpa backend)
 *        'auto'     -> coba Firebase, jika gagal (mis. offline / diblokir) jatuh ke demo
 */
window.APP_CONFIG = {
  mode: 'firebase',
  appName: 'Corporate Contact Center Performance Management',
  corporateName: 'Government Segment 3',
  sessionTimeoutMinutes: 30,
  firebase: {
    apiKey: "AIzaSyCbCHSf__wGsvgOqDF9_tDGfNLpHNi6JFk",
    authDomain: "government-f3e2b.firebaseapp.com",
    projectId: "government-f3e2b",
    storageBucket: "government-f3e2b.firebasestorage.app",
    messagingSenderId: "1067670047216",
    appId: "1:1067670047216:web:88aa719824fb5a08e7f535",
    measurementId: "G-37V779052F"
  },
  firebaseSdkVersion: '10.12.2'
};
