/* =========================================================================
 * HALAMAN DASHBOARD: Executive, Portfolio, Project, Channel, Traffic
 * ========================================================================= */
(function () {
  'use strict';
  const C = window.Core, U = window.UI, esc = C.esc;
  const Pages = window.Pages = window.Pages || {};
  const A = () => window.App;

  /* ---------- helper bersama ---------- */
  const KPI_DEF = {
    projects: { label: 'Total Project', icon: 'project', fmt: v => C.fmtInt(v) },
    traffic: { label: 'Total Traffic', icon: 'traffic', fmt: C.fmtCompact },
    off: { label: 'Total Inbound', icon: 'phone', fmt: C.fmtCompact, sub: 'Call offered' },
    acc: { label: 'Accepted Call', icon: 'phone', fmt: C.fmtCompact },
    abd: { label: 'Abandon Call', icon: 'phone', fmt: C.fmtCompact },
    ob: { label: 'Outbound', icon: 'phone', fmt: C.fmtCompact },
    cmin: { label: 'Call Minute', icon: 'clock', fmt: C.fmtCompact },
    totdig: { label: 'Total Digital', icon: 'digital', fmt: C.fmtCompact },
    scr: { label: 'SCR', icon: 'sla', fmt: v => C.fmtPct(v), t: 'scr', hi: true },
    sl: { label: 'Service Level', icon: 'sla', fmt: v => C.fmtPct(v), t: 'sl', hi: true },
    aht: { label: 'AHT', icon: 'clock', fmt: C.fmtSec, t: 'aht', hi: false },
    qs: { label: 'Quality Score', icon: 'quality', fmt: v => C.fmtNum(v, 1), t: 'quality', hi: true },
    pk: { label: 'Product Knowledge', icon: 'quality', fmt: v => C.fmtNum(v, 1), t: 'pk', hi: true },
    prod: { label: 'Productivity', icon: 'workforce', fmt: v => C.fmtPct(v), t: 'productivity', hi: true },
    att: { label: 'Attendance', icon: 'workforce', fmt: v => C.fmtPct(v), t: 'attendance', hi: true },
    login: { label: 'Login Accuracy', icon: 'clock', fmt: v => C.fmtPct(v), t: 'login', hi: true },
    rr: { label: 'Respon Rate', icon: 'digital', fmt: v => C.fmtPct(v), t: 'rr', hi: true },
    rt: { label: 'Response Time', icon: 'clock', fmt: C.fmtSec, t: 'rt', hi: false },
    ht: { label: 'Handling Time', icon: 'clock', fmt: C.fmtSec, t: 'ht', hi: false },
    abdRate: { label: 'Abandon Rate', icon: 'alert', fmt: v => C.fmtPct(v) }
  };
  // Kartu KPI dengan target/aktual/achievement + sparkline bulanan
  function kpiCards(keys, rows, a, opts = {}) {
    const App = A(); const ser = opts.spark ? App.series(rows) : null; const out = []; const sparks = [];
    keys.forEach(k => {
      const d = KPI_DEF[k]; const v = a[k]; const o = { label: d.label, value: d.fmt(v), icon: d.icon, sub: d.sub };
      if (d.t) {
        const tg = App.targetFor(rows, d.t);
        o.status = C.isNum(v) ? C.status(v, tg, d.hi, App.F()) : 'na';
        if (opts.tav) { o.target = d.fmt(tg); o.ach = C.isNum(v) && C.isNum(tg) && tg > 0 ? C.fmtPct(d.hi ? v / tg * 100 : tg / v * 100, 1) : '–'; }
        else o.sub = `Target ${d.fmt(tg)}`;
      } else o.info = true;
      if (!C.isNum(v)) { o.value = '–'; o.sub = 'Belum ada data'; }
      if (ser && ser.length > 1) { o.spark = 'sp-' + k + '-' + (opts.id || ''); sparks.push([o.spark, ser.map(s => s[k] ?? null)]); }
      out.push(U.kpi(o));
    });
    if (sparks.length) App.onMount(() => sparks.forEach(([id, vals]) => U.spark(id, vals)));
    return `<div class="kpis">${out.join('')}</div>`;
  }
  const stColor = st => U.css(st === 'ok' ? '--ok' : st === 'risk' ? '--risk' : st === 'bad' ? '--bad' : '--c5');
  const ymLabels = s => s.map(x => C.ymShort(x.key));
  const tickCompact = { ticks: { callback: v => C.fmtCompact(v) } };
  const noData = (msg) => U.empty('Belum ada data untuk filter ini', msg || 'Ubah filter atau upload data melalui Data Upload Center.');
  function issueRows(rows) { return rows.filter(r => r.issue).map(r => ({ r, p: A().proj(r.projectId) })); }
  function issueCategory(t) {
    const s = (t || '').toLowerCase();
    if (/sdm|agent|staff|personil/.test(s) && !/login/.test(s)) return 'SDM / Staffing';
    if (/gangguan|jaringan|intermiten|terputus|gamas|telpon|telfon|117|112|provider|telco/.test(s)) return 'Jaringan / Telco';
    if (/abd un|sistem|aplikasi|tidak tercatat|error/.test(s)) return 'Sistem / Pencatatan';
    if (/volume|lonjakan|peak|tinggi/.test(s)) return 'Lonjakan Volume';
    return 'Lainnya';
  }
  window.PH = { kpiCards, KPI_DEF, stColor, ymLabels, tickCompact, noData, issueRows, issueCategory };

  /* =================== 1. EXECUTIVE =================== */
  Pages.exec = {
    title: 'Executive Dashboard', icon: 'exec', perm: 'dashboard.view', filters: true,
    render() {
      const App = A(); const rows = App.rows(); if (!rows.length) return U.pageHead('Corporate Contact Center', 'Executive Overview', App.periodLabel()) + noData();
      const a = App.agg(rows); const pp = App.perProject(rows);
      a.projects = App.projectsInScope().filter(p => p.status === 'Active' && (!App.filter.customer || p.customerId === App.filter.customer) && (!App.filter.project || p.id === App.filter.project)).length;
      const alerts = App.alerts();
      const issues = issueRows(rows).slice(-6).reverse();
      const ups = App.data.uploads.slice(0, 5);
      const projTable = pp.map(x => { const t = App.targets(x.project.id); const st = x.agg.off > 0 ? C.status(x.agg.scr, t.scr, true, App.F()) : 'na'; return `<tr><td><b>${esc(x.project.code || x.project.name)}</b><div class="muted small">${esc(App.cust(x.project.customerId).name)}</div></td><td class="r">${C.fmtCompact(x.agg.traffic)}</td><td class="r">${x.agg.off > 0 ? C.fmtPct(x.agg.scr) : '–'}</td><td>${U.pill(st)}</td><td class="r">${C.fmtSec(x.agg.aht)}</td><td class="r">${C.fmtNum(x.agg.qs, 1)}</td></tr>`; }).join('');
      return U.pageHead('Corporate Contact Center Executive Overview', 'Executive Dashboard', `${App.periodLabel()} · ${pp.length} project dengan data`, App.can('report.export') ? `<a class="btn" href="#reports">${U.icon('report')} Report Center</a>` : '') +
        kpiCards(['projects', 'traffic', 'scr', 'sl', 'aht', 'qs', 'prod'], rows, a, { spark: true, id: 'top' }) +
        kpiCards(['off', 'totdig', 'pk', 'att', 'login'], rows, a, { spark: true, id: 'sec' }) +
        `<div class="grid">
          ${U.card('Traffic Trend', U.chartBox('ex-traffic'), { span: 's6', hint: 'Inbound accepted · Outbound · Digital' })}
          ${U.card('SCR Trend', U.chartBox('ex-scr'), { span: 's6', hint: 'Aktual vs target tertimbang' })}
          ${U.card('Digital Channel', U.chartBox('ex-digital'), { span: 's5', hint: 'Volume per channel' })}
          ${U.card('Project Performance', `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Project</th><th class="r">Traffic</th><th class="r">SCR</th><th>Status</th><th class="r">AHT</th><th class="r">Quality</th></tr></thead><tbody>${projTable}</tbody></table></div>`, { span: 's7' })}
          ${U.card('Quality', U.chartBox('ex-quality', 'short'), { span: 's4', hint: 'Skor QM per project' })}
          ${U.card('Workforce', U.chartBox('ex-wf', 'short'), { span: 's4', hint: 'Jumlah SDM per project' })}
          ${U.card('Top Issue', alerts.length ? alerts.slice(0, 6).map(x => `<div class="alert-row ${x.severity}"><span class="ic">${U.icon('alert')}</span><div>${esc(x.text)}</div></div>`).join('') : U.empty('Tidak ada alert', 'Semua KPI dalam target.'), { span: 's4', hint: alerts.length + ' alert aktif' })}
          ${U.card('SCR Issue', issues.length ? issues.map(({ r, p }) => `<div class="alert-row risk"><span class="ic">${U.icon('sla')}</span><div><b>${esc(p.code)}</b> · ${esc(r.date)} · SCR ${C.fmtPct(r.scrUsed)}<div class="muted small">${esc(r.issue.slice(0, 140))}${r.issue.length > 140 ? '…' : ''}</div></div></div>`).join('') : U.empty('Tidak ada issue SCR', 'Belum ada catatan issue pada periode ini.'), { span: 's6' })}
          ${U.card('Latest Update', ups.length ? ups.map(u => `<div class="alert-row info"><span class="ic">${U.icon('upload')}</span><div><b>${esc(u.projectName || u.projectId)}</b> · ${esc(u.period)}<div class="muted small">${esc(u.fileName)} · ${esc(u.status)} · ${esc((u.uploadedAt || '').slice(0, 10))}</div></div></div>`).join('') : lastDataList(pp), { span: 's6' })}
        </div>
        <div class="section-title"><h2>Corporate Performance Chart</h2><span>Perbandingan seluruh project pada periode terpilih</span></div>
        <div class="grid">
          ${U.card('Traffic by Project', U.chartBox('cp-traffic'), { span: 's6' })}
          ${U.card('Digital Interaction by Project', U.chartBox('cp-digital'), { span: 's6', hint: 'Stacked per channel' })}
          ${U.card('SCR by Project', U.chartBox('cp-scr', 'tall'), { span: 's4' })}
          ${U.card('SL by Project', U.chartBox('cp-sl', 'tall'), { span: 's4' })}
          ${U.card('Quality Score by Project', U.chartBox('cp-qs', 'tall'), { span: 's4' })}
          ${U.card('Monthly Traffic Trend', U.chartBox('cp-mt'), { span: 's6' })}
          ${U.card('SCR Trend per Project', U.chartBox('cp-st'), { span: 's6' })}
          ${U.card('AHT Trend', U.chartBox('cp-aht'), { span: 's6' })}
          ${U.card('Workforce Trend', U.chartBox('cp-wf'), { span: 's6', hint: 'Kehadiran & Quality bulanan' })}
        </div>`;
    },
    mount() {
      const App = A(); const rows = App.rows(); if (!rows.length) return;
      const pal = U.palette(); const ser = App.series(rows); const pp = App.perProject(rows); const F = App.F();
      U.chart('ex-traffic', 'bar', { labels: ymLabels(ser), datasets: [
        { label: 'Inbound', data: ser.map(s => s.acc), backgroundColor: pal[0], stack: 't', borderRadius: 3 },
        { label: 'Outbound', data: ser.map(s => s.ob), backgroundColor: pal[3], stack: 't', borderRadius: 3 },
        { label: 'Digital', data: ser.map(s => s.totdig), backgroundColor: pal[1], stack: 't', borderRadius: 3 }] }, { scales: { x: { stacked: true }, y: Object.assign({ stacked: true }, tickCompact) } });
      const tScr = App.targetFor(rows, 'scr');
      U.chart('ex-scr', 'line', { labels: ymLabels(ser), datasets: [
        { label: 'SCR aktual', data: ser.map(s => s.off > 0 ? s.scr : null), borderColor: pal[0], backgroundColor: U.alpha(pal[0], .1), fill: true, tension: .3, pointRadius: 3 },
        { label: 'Target', data: ser.map(() => tScr), borderColor: U.css('--bad'), borderDash: [6, 4], pointRadius: 0, borderWidth: 1.5 }] }, { scales: { y: { beginAtZero: false, suggestedMin: 60, max: 100, ticks: { callback: v => v + '%' } } } });
      const ch = C.CHANNELS.map(c => ({ l: c.label, v: rows.reduce((s, r) => s + (r[c.k] || 0), 0) })).filter(x => x.v > 0).sort((a, b) => b.v - a.v);
      U.chart('ex-digital', 'bar', { labels: ch.map(x => x.l), datasets: [{ label: 'Volume', data: ch.map(x => x.v), backgroundColor: pal[1], borderRadius: 4 }] }, { indexAxis: 'y', scales: { x: tickCompact, y: { grid: { display: false } } } });
      const q = pp.filter(x => C.isNum(x.agg.qs));
      U.chart('ex-quality', 'bar', { labels: q.map(x => x.project.code), datasets: [{ label: 'Quality', data: q.map(x => x.agg.qs), backgroundColor: q.map(x => stColor(C.status(x.agg.qs, App.targets(x.project.id).quality, true, F))), borderRadius: 4 }] }, { scales: { y: { beginAtZero: false, suggestedMin: 70, max: 100 } } });
      const w = pp.filter(x => C.isNum(x.agg.sdm));
      U.chart('ex-wf', 'bar', { labels: w.map(x => x.project.code), datasets: [{ label: 'SDM', data: w.map(x => x.agg.sdm), backgroundColor: pal[2], borderRadius: 4 }, { label: 'Seat', data: w.map(x => x.agg.seat), backgroundColor: pal[4], borderRadius: 4 }] });
      // corporate charts
      U.chart('cp-traffic', 'bar', { labels: pp.map(x => x.project.code), datasets: [{ label: 'Total Traffic', data: pp.map(x => x.agg.traffic), backgroundColor: pal[0], borderRadius: 4 }] }, { scales: { y: tickCompact } });
      const topCh = ch.slice(0, 6).map(x => C.CHANNELS.find(c => c.label === x.l));
      const ppD = pp.filter(x => x.agg.totdig > 0);
      U.chart('cp-digital', 'bar', { labels: ppD.map(x => x.project.code), datasets: topCh.map((c, i) => ({ label: c.label, data: ppD.map(x => x.agg[c.k]), backgroundColor: pal[i % pal.length], stack: 'd' })).concat([{ label: 'Lainnya', data: ppD.map(x => x.agg.totdig - topCh.reduce((s, c) => s + (x.agg[c.k] || 0), 0)), backgroundColor: U.css('--line'), stack: 'd' }]) }, { scales: { x: { stacked: true }, y: Object.assign({ stacked: true }, tickCompact) } });
      const scrP = pp.filter(x => x.agg.off > 0).sort((a, b) => b.agg.scr - a.agg.scr);
      U.chart('cp-scr', 'bar', { labels: scrP.map(x => x.project.code), datasets: [{ label: 'SCR', data: scrP.map(x => x.agg.scr), backgroundColor: scrP.map(x => stColor(C.status(x.agg.scr, App.targets(x.project.id).scr, true, F))), borderRadius: 4 }] }, { indexAxis: 'y', scales: { x: { max: 100, ticks: { callback: v => v + '%' } }, y: { grid: { display: false } } } });
      const slP = pp.filter(x => C.isNum(x.agg.sl)).sort((a, b) => b.agg.sl - a.agg.sl);
      U.chart('cp-sl', 'bar', { labels: slP.map(x => x.project.code), datasets: [{ label: 'SL', data: slP.map(x => x.agg.sl), backgroundColor: slP.map(x => stColor(C.status(x.agg.sl, App.targets(x.project.id).sl, true, F))), borderRadius: 4 }] }, { indexAxis: 'y', scales: { x: { max: 100, ticks: { callback: v => v + '%' } }, y: { grid: { display: false } } } });
      U.chart('cp-qs', 'bar', { labels: q.map(x => x.project.code), datasets: [{ label: 'Quality', data: q.map(x => x.agg.qs), backgroundColor: q.map(x => stColor(C.status(x.agg.qs, App.targets(x.project.id).quality, true, F))), borderRadius: 4 }, { type: 'line', label: 'Target', data: q.map(x => App.targets(x.project.id).quality), borderColor: U.css('--text'), pointStyle: 'line', pointRadius: 8, showLine: false }] }, { scales: { y: { beginAtZero: false, suggestedMin: 70, max: 100 } } });
      U.chart('cp-mt', 'line', { labels: ymLabels(ser), datasets: [{ label: 'Total Traffic', data: ser.map(s => s.traffic), borderColor: pal[0], backgroundColor: U.alpha(pal[0], .1), fill: true, tension: .3 }] }, { scales: { y: tickCompact } });
      const top5 = scrP.slice().sort((a, b) => b.agg.off - a.agg.off).slice(0, 5);
      U.chart('cp-st', 'line', { labels: ymLabels(ser), datasets: top5.map((x, i) => { const s = App.series(x.rows); const m = new Map(s.map(y => [y.key, y])); return { label: x.project.code, data: ser.map(y => m.get(y.key) && m.get(y.key).off > 0 ? m.get(y.key).scr : null), borderColor: pal[i], tension: .3, spanGaps: true }; }) }, { scales: { y: { beginAtZero: false, suggestedMin: 50, max: 100, ticks: { callback: v => v + '%' } } } });
      U.chart('cp-aht', 'line', { labels: ymLabels(ser), datasets: [{ label: 'AHT (detik)', data: ser.map(s => s.aht), borderColor: pal[3], tension: .3 }, { label: 'Target', data: ser.map(() => App.targetFor(rows, 'aht')), borderColor: U.css('--bad'), borderDash: [6, 4], pointRadius: 0 }] });
      U.chart('cp-wf', 'line', { labels: ymLabels(ser), datasets: [{ label: 'Kehadiran %', data: ser.map(s => s.att), borderColor: pal[2], tension: .3, spanGaps: true }, { label: 'Quality', data: ser.map(s => s.qs), borderColor: pal[1], tension: .3, spanGaps: true }, { label: 'Login Accuracy %', data: ser.map(s => s.login), borderColor: pal[3], tension: .3, spanGaps: true }] }, { scales: { y: { beginAtZero: false, suggestedMin: 70, max: 100 } } });
    }
  };
  function lastDataList(pp) { return pp.slice(0, 6).map(x => `<div class="alert-row info"><span class="ic">${U.icon('calendar')}</span><div><b>${esc(x.project.code)}</b> · data terakhir ${esc(x.rows[x.rows.length - 1].date)}</div></div>`).join(''); }

  /* =================== 2. PORTFOLIO =================== */
  const CMP = [['traffic', 'Traffic'], ['scr', 'SCR'], ['sl', 'SL'], ['aht', 'AHT'], ['qs', 'Quality'], ['pk', 'Product Knowledge'], ['prod', 'Productivity'], ['att', 'Attendance'], ['login', 'Login Accuracy'], ['totdig', 'Digital Interaction']];
  Pages.portfolio = {
    title: 'Portfolio Dashboard', icon: 'portfolio', perm: 'dashboard.view', filters: true,
    render() {
      const App = A(); const sel = App.subTab.portfolioSel || App.projectsInScope().map(p => p.id);
      const rows = App.rows({ ignoreProject: true, projectIds: sel }); const pp = App.perProject(rows);
      const metric = App.subTab.portfolioMetric || 'traffic';
      return U.pageHead('Portfolio Performance Comparison', 'Portfolio Dashboard', `${App.periodLabel()} · bandingkan project yang dipilih`) +
        U.card('Pilih project', `<div class="multi" id="pf-sel">${App.projectsInScope().map(p => `<label class="check"><input type="checkbox" value="${p.id}" ${sel.includes(p.id) ? 'checked' : ''}> ${esc(p.code)} <span class="muted small">${esc(p.name)}</span></label>`).join('')}</div><div class="row" style="margin-top:10px"><button class="btn sm" id="pf-all">Pilih semua</button><button class="btn sm" id="pf-none">Kosongkan</button><button class="btn sm primary" id="pf-apply">Terapkan</button></div>`) +
        (pp.length ? `<div class="grid">${U.card('Tabel perbandingan', '<div id="pf-table"></div>', { hint: 'Klik judul kolom untuk mengurutkan' })}
          ${U.card('Grafik perbandingan', `<div class="row" style="margin-bottom:8px"><label class="small muted" for="pf-metric">Metrik</label><select class="input" id="pf-metric" style="max-width:220px">${CMP.map(([k, l]) => `<option value="${k}" ${metric === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>${U.chartBox('pf-chart', 'tall')}`, { span: 's7' })}
          ${U.card('Tren bulanan metrik', U.chartBox('pf-trend', 'tall'), { span: 's5' })}</div>` : noData('Pilih minimal satu project.'));
    },
    mount() {
      const App = A(); const el = document.getElementById('pf-sel');
      const apply = () => { App.subTab.portfolioSel = [...el.querySelectorAll('input:checked')].map(i => i.value); App.render(); };
      document.getElementById('pf-apply').addEventListener('click', apply);
      document.getElementById('pf-all').addEventListener('click', () => el.querySelectorAll('input').forEach(i => i.checked = true));
      document.getElementById('pf-none').addEventListener('click', () => el.querySelectorAll('input').forEach(i => i.checked = false));
      const sel = App.subTab.portfolioSel || App.projectsInScope().map(p => p.id);
      const rows = App.rows({ ignoreProject: true, projectIds: sel }); const pp = App.perProject(rows); if (!pp.length) return;
      const F = App.F();
      const st = (v, t, hi) => C.isNum(v) ? U.pill(C.status(v, t, hi, F), C.STATUS_LABEL[C.status(v, t, hi, F)]) : '';
      U.dataTable('pf-table', [
        { k: 'name', label: 'Project', fmt: (v, r) => `<b>${esc(r.code)}</b><div class="muted small">${esc(r.cust)}</div>` },
        { k: 'traffic', label: 'Traffic', r: 1, fmt: v => C.fmtInt(v) },
        { k: 'scr', label: 'SCR', r: 1, fmt: (v, r) => r.off > 0 ? `${C.fmtPct(v)}<br>${st(v, r.t.scr, true)}` : '–' },
        { k: 'sl', label: 'SL', r: 1, fmt: (v, r) => C.isNum(v) ? `${C.fmtPct(v)}<br>${st(v, r.t.sl, true)}` : '–' },
        { k: 'aht', label: 'AHT', r: 1, fmt: (v, r) => C.isNum(v) ? `${C.fmtSec(v)}<br>${st(v, r.t.aht, false)}` : '–' },
        { k: 'qs', label: 'Quality', r: 1, fmt: (v, r) => C.isNum(v) ? `${C.fmtNum(v)}<br>${st(v, r.t.quality, true)}` : '–' },
        { k: 'pk', label: 'PK', r: 1, fmt: v => C.fmtNum(v) },
        { k: 'prod', label: 'Productivity', r: 1, fmt: v => C.fmtPct(v) },
        { k: 'att', label: 'Attendance', r: 1, fmt: v => C.fmtPct(v) },
        { k: 'login', label: 'Login Acc.', r: 1, fmt: v => C.fmtPct(v) },
        { k: 'totdig', label: 'Digital', r: 1, fmt: v => C.fmtInt(v) }
      ], pp.map(x => Object.assign({ name: x.project.name, code: x.project.code, cust: App.cust(x.project.customerId).name, t: App.targets(x.project.id) }, x.agg)), { sortK: 'traffic', noPaging: true });
      const metric = App.subTab.portfolioMetric || 'traffic';
      document.getElementById('pf-metric').addEventListener('change', e => { App.subTab.portfolioMetric = e.target.value; App.render(); });
      const pal = U.palette(); const lbl = (CMP.find(c => c[0] === metric) || [])[1];
      const sorted = pp.filter(x => C.isNum(x.agg[metric]) && !(metric === 'scr' && !x.agg.off)).sort((a, b) => b.agg[metric] - a.agg[metric]);
      U.chart('pf-chart', 'bar', { labels: sorted.map(x => x.project.code), datasets: [{ label: lbl, data: sorted.map(x => x.agg[metric]), backgroundColor: pal[0], borderRadius: 4 }] }, { indexAxis: 'y', scales: { y: { grid: { display: false } } } });
      const months = App.months().filter(m => rows.some(r => r.ym === m));
      U.chart('pf-trend', 'line', { labels: months.map(C.ymShort), datasets: sorted.slice(0, 8).map((x, i) => { const s = new Map(App.series(x.rows).map(y => [y.key, y])); return { label: x.project.code, data: months.map(m => s.get(m) ? s.get(m)[metric] : null), borderColor: pal[i % pal.length], tension: .3, spanGaps: true }; }) });
    }
  };

  /* =================== 3. PROJECT DASHBOARD =================== */
  Pages.project = {
    title: 'Project Dashboard', icon: 'project', perm: 'dashboard.view', filters: true,
    render() {
      const App = A(); const projs = App.projectsInScope();
      let pid = App.filter.project || App.subTab.projectPick || (projs[0] && projs[0].id);
      if (!pid) return U.pageHead('Project', 'Project Dashboard', '') + noData('Belum ada project yang ditugaskan.');
      const p = App.proj(pid); const rows = App.rows({ ignoreProject: true, projectIds: [pid] }); const a = App.agg(rows); const t = App.targets(pid);
      const picker = `<select class="input" id="pj-pick" style="min-width:240px" aria-label="Pilih project">${projs.map(x => `<option value="${x.id}" ${x.id === pid ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>`;
      const head = `<div class="card s12"><div class="card-b"><div class="row" style="justify-content:space-between;align-items:flex-start"><div><div class="eyebrow">Project Performance Dashboard</div><h1 style="font-size:22px">${esc(p.name)}</h1><div class="muted">${esc(App.cust(p.customerId).name)} · Periode ${esc(App.periodLabel())}</div></div><div class="row">${picker}${App.can('report.export') ? `<button class="btn" id="pj-export">${U.icon('download')} Export Excel</button>` : ''}</div></div>
        <dl class="kv" style="margin-top:12px"><dt>Kode</dt><dd>${esc(p.code)}</dd><dt>Status</dt><dd>${U.pill(p.status === 'Active' ? 'ok' : p.status === 'Onboarding' ? 'info' : 'na', p.status)}</dd><dt>Project Manager</dt><dd>${esc(p.manager || '–')}</dd></dl></div></div>`;
      if (!rows.length) return `<div class="grid">${head}</div>` + noData();
      return `<div class="grid">${head}</div>` +
        kpiCards(['off', 'acc', 'abd', 'scr', 'sl', 'aht', 'cmin', 'ob'], rows, a, { tav: true }) +
        kpiCards(['totdig', 'traffic', 'qs', 'pk', 'prod', 'att', 'login'], rows, a, { tav: true }) +
        `<div class="grid">
          ${U.card('Traffic harian', U.chartBox('pj-daily'), { span: 's8', hint: 'Inbound · Outbound · Digital' })}
          ${U.card('Contact reason', U.chartBox('pj-reason'), { span: 's4' })}
          ${U.card('SCR harian vs target', U.chartBox('pj-scr'), { span: 's6' })}
          ${U.card('AHT harian', U.chartBox('pj-aht'), { span: 's6' })}
          ${U.card('Channel digital', U.chartBox('pj-ch'), { span: 's6' })}
          ${U.card('Quality, Kehadiran & Login (bulanan)', U.chartBox('pj-q'), { span: 's6' })}
          ${U.card('Data harian', '<div id="pj-table"></div>', { hint: 'Nilai setelah auto-calculation' })}
        </div>`;
    },
    mount() {
      const App = A(); const sel = document.getElementById('pj-pick');
      if (sel) sel.addEventListener('change', e => { if (App.filter.project) App.filter.project = e.target.value; App.subTab.projectPick = e.target.value; App.render(); });
      const pid = sel && sel.value; if (!pid) return;
      const rows = App.rows({ ignoreProject: true, projectIds: [pid] }); if (!rows.length) return;
      const pal = U.palette(); const t = App.targets(pid);
      const daily = App.series(rows, 'date'); const L = daily.map(d => d.key.slice(5));
      U.chart('pj-daily', 'bar', { labels: L, datasets: [{ label: 'Inbound', data: daily.map(d => d.acc), backgroundColor: pal[0], stack: 's' }, { label: 'Outbound', data: daily.map(d => d.ob), backgroundColor: pal[3], stack: 's' }, { label: 'Digital', data: daily.map(d => d.totdig), backgroundColor: pal[1], stack: 's' }] }, { scales: { x: { stacked: true }, y: Object.assign({ stacked: true }, tickCompact) } });
      const a = App.agg(rows); const rs = [['Informasi', a.info], ['Permintaan', a.perm], ['Komplain', a.komp], ['Non Pengaduan', a.nonp]].filter(x => x[1] > 0);
      if (rs.length) U.chart('pj-reason', 'doughnut', { labels: rs.map(x => x[0]), datasets: [{ data: rs.map(x => x[1]), backgroundColor: pal.slice(0, 4), borderWidth: 0 }] }, { cutout: '62%' });
      else document.getElementById('pj-reason').parentElement.innerHTML = U.empty('Belum ada data contact reason', '');
      U.chart('pj-scr', 'line', { labels: L, datasets: [{ label: 'SCR', data: daily.map(d => d.off > 0 ? d.scr : null), borderColor: pal[0], pointRadius: 0, tension: .2, spanGaps: true }, { label: 'Target', data: daily.map(() => t.scr), borderColor: U.css('--bad'), borderDash: [6, 4], pointRadius: 0 }] }, { scales: { y: { beginAtZero: false, max: 100 } } });
      U.chart('pj-aht', 'line', { labels: L, datasets: [{ label: 'AHT (detik)', data: daily.map(d => d.aht), borderColor: pal[3], pointRadius: 0, tension: .2, spanGaps: true }, { label: 'Target', data: daily.map(() => t.aht), borderColor: U.css('--bad'), borderDash: [6, 4], pointRadius: 0 }] });
      const ch = C.CHANNELS.map(c => ({ l: c.label, v: a[c.k] })).filter(x => x.v > 0).sort((x, y) => y.v - x.v);
      if (ch.length) U.chart('pj-ch', 'bar', { labels: ch.map(x => x.l), datasets: [{ label: 'Volume', data: ch.map(x => x.v), backgroundColor: pal[1], borderRadius: 4 }] }, { indexAxis: 'y', scales: { x: tickCompact, y: { grid: { display: false } } } });
      else document.getElementById('pj-ch').parentElement.innerHTML = U.empty('Tidak ada interaksi digital', '');
      const ms = App.series(rows);
      U.chart('pj-q', 'line', { labels: ymLabels(ms), datasets: [{ label: 'Quality', data: ms.map(s => s.qs), borderColor: pal[1], tension: .3, spanGaps: true }, { label: 'Product Knowledge', data: ms.map(s => s.pk), borderColor: pal[2], tension: .3, spanGaps: true }, { label: 'Kehadiran %', data: ms.map(s => s.att), borderColor: pal[0], tension: .3, spanGaps: true }, { label: 'Login %', data: ms.map(s => s.login), borderColor: pal[3], tension: .3, spanGaps: true }] }, { scales: { y: { beginAtZero: false, suggestedMin: 70, max: 100 } } });
      const cols = [{ k: 'date', label: 'Tanggal' }, { k: 'day', label: 'Hari' }, { k: 'off', label: 'Offered', r: 1, fmt: C.fmtInt }, { k: 'acc', label: 'Accepted', r: 1, fmt: C.fmtInt }, { k: 'abd', label: 'Abandon', r: 1, fmt: C.fmtInt }, { k: 'scrUsed', label: 'SCR', r: 1, fmt: v => C.fmtPct(v) }, { k: 'sl', label: 'SL', r: 1, fmt: v => C.fmtPct(v) }, { k: 'aht', label: 'AHT', r: 1, fmt: C.fmtSec }, { k: 'ob', label: 'Outbound', r: 1, fmt: C.fmtInt }, { k: 'totdigUsed', label: 'Digital', r: 1, fmt: C.fmtInt }, { k: 'trafficUsed', label: 'Total Trafik', r: 1, fmt: C.fmtInt }, { k: 'qs', label: 'Quality', r: 1, fmt: v => C.fmtNum(v) }, { k: 'att', label: 'Hadir', r: 1, fmt: v => C.fmtPct(v) }, { k: 'issue', label: 'Issue', wrap: 1, fmt: v => esc(v || '') }];
      U.dataTable('pj-table', cols, rows.slice().reverse(), { pageSize: 10 });
      const ex = document.getElementById('pj-export');
      if (ex) ex.addEventListener('click', () => window.Reports.quickExport('Project_' + App.proj(pid).code, rows));
    }
  };

  /* =================== 4. CHANNEL PERFORMANCE =================== */
  Pages.channel = {
    title: 'Channel Performance', icon: 'channel', perm: 'dashboard.view', filters: true,
    render() {
      const App = A(); const rows = App.rows(); if (!rows.length) return U.pageHead('Channel', 'Channel Performance', App.periodLabel()) + noData();
      const a = App.agg(rows); const tot = a.acc + a.ob + a.totdig;
      const grp = [['Inbound (Voice)', a.acc, 'phone', `SCR ${C.fmtPct(a.scr)} · AHT ${C.fmtSec(a.aht)}`], ['Outbound', a.ob, 'phone', 'Call outbound'], ['Digital', a.totdig, 'digital', `RT ${C.fmtSec(a.rt)} · RR ${C.fmtPct(a.rr)}`]];
      return U.pageHead('Channel Performance', 'Channel Performance', `Komposisi channel layanan · ${App.periodLabel()}`) +
        `<div class="kpis">${grp.map(([l, v, ic, s]) => U.kpi({ label: l, value: C.fmtCompact(v), icon: ic, info: true, sub: `${tot ? C.fmtPct(v / tot * 100) : '–'} dari total · ${s}` })).join('')}${U.kpi({ label: 'Total Traffic All', value: C.fmtCompact(tot), icon: 'traffic', info: true, sub: 'Accepted + Outbound + Digital' })}</div>
        <div class="grid">
          ${U.card('Komposisi channel per project', U.chartBox('ch-proj', 'tall'), { span: 's8' })}
          ${U.card('Kontribusi channel', U.chartBox('ch-share', 'tall'), { span: 's4' })}
          ${U.card('Tren bulanan per kelompok channel', U.chartBox('ch-trend'), { span: 's12' })}
          ${U.card('Tabel channel per project', '<div id="ch-table"></div>')}
        </div>`;
    },
    mount() {
      const App = A(); const rows = App.rows(); if (!rows.length) return; const pal = U.palette();
      const pp = App.perProject(rows); const a = App.agg(rows);
      U.chart('ch-proj', 'bar', { labels: pp.map(x => x.project.code), datasets: [{ label: 'Inbound', data: pp.map(x => x.agg.acc), backgroundColor: pal[0], stack: 'a' }, { label: 'Outbound', data: pp.map(x => x.agg.ob), backgroundColor: pal[3], stack: 'a' }, { label: 'Digital', data: pp.map(x => x.agg.totdig), backgroundColor: pal[1], stack: 'a' }] }, { indexAxis: 'y', scales: { x: Object.assign({ stacked: true }, tickCompact), y: { stacked: true, grid: { display: false } } } });
      const parts = [['Inbound', a.acc], ['Outbound', a.ob]].concat(C.CHANNELS.map(c => [c.label, a[c.k]])).filter(x => x[1] > 0).sort((x, y) => y[1] - x[1]);
      U.chart('ch-share', 'doughnut', { labels: parts.map(x => x[0]), datasets: [{ data: parts.map(x => x[1]), backgroundColor: parts.map((_, i) => pal[i % pal.length]), borderWidth: 0 }] }, { cutout: '58%' });
      const ser = App.series(rows);
      U.chart('ch-trend', 'line', { labels: ymLabels(ser), datasets: [{ label: 'Inbound', data: ser.map(s => s.acc), borderColor: pal[0], tension: .3 }, { label: 'Outbound', data: ser.map(s => s.ob), borderColor: pal[3], tension: .3 }, { label: 'Digital', data: ser.map(s => s.totdig), borderColor: pal[1], tension: .3 }] }, { scales: { y: tickCompact } });
      U.dataTable('ch-table', [{ k: 'code', label: 'Project' }, { k: 'acc', label: 'Inbound', r: 1, fmt: C.fmtInt }, { k: 'scr', label: 'SCR', r: 1, fmt: (v, r) => r.off > 0 ? C.fmtPct(v) : '–' }, { k: 'ob', label: 'Outbound', r: 1, fmt: C.fmtInt }, { k: 'totdig', label: 'Digital', r: 1, fmt: C.fmtInt }, { k: 'rt', label: 'Resp. Time', r: 1, fmt: C.fmtSec }, { k: 'traffic', label: 'Total', r: 1, fmt: C.fmtInt }, { k: 'dshare', label: '% Digital', r: 1, fmt: v => C.fmtPct(v) }],
        pp.map(x => Object.assign({ code: x.project.code, dshare: x.agg.traffic ? x.agg.totdig / x.agg.traffic * 100 : null }, x.agg)), { sortK: 'traffic', noPaging: true });
    }
  };

  /* =================== 5. TRAFFIC ANALYTICS =================== */
  Pages.traffic = {
    title: 'Traffic Analytics', icon: 'traffic', perm: 'dashboard.view', filters: true,
    render() {
      const App = A(); const rows = App.rows(); if (!rows.length) return U.pageHead('Traffic', 'Traffic Analytics', App.periodLabel()) + noData();
      const a = App.agg(rows);
      const tab = App.tabs('traffic', [['volume', 'Volume & Tren'], ['reason', 'Customer Contact Reason'], ['category', 'Top Category Analytics']]);
      let body = '';
      if (tab.cur === 'volume') body = `<div class="section-title"><h2>Inbound</h2></div>` + kpiCards(['off', 'acc', 'abd', 'abdRate', 'aht', 'cmin', 'scr', 'sl'], rows, a) +
        `<div class="section-title"><h2>Outbound & Digital</h2></div>` + kpiCards(['ob', 'totdig', 'traffic'], rows, a) +
        `<div class="grid">
          ${U.card('Hourly Traffic', `<p class="muted small" style="margin:0 0 8px">Template harian belum memuat data interval per jam. Grafik menampilkan pola rata-rata per hari dalam seminggu.</p>${U.chartBox('tr-dow', 'short')}`, { span: 's4' })}
          ${U.card('Daily Traffic', U.chartBox('tr-daily'), { span: 's8' })}
          ${U.card('Weekly Traffic', U.chartBox('tr-week'), { span: 's6' })}
          ${U.card('Monthly Traffic', U.chartBox('tr-month'), { span: 's6' })}
          ${U.card('Channel Distribution', U.chartBox('tr-ch'), { span: 's6' })}
          ${U.card('Project Distribution', U.chartBox('tr-proj'), { span: 's6' })}
        </div>`;
      else if (tab.cur === 'reason') {
        const tot = a.info + a.perm + a.komp + a.nonp;
        body = (tot ? `<div class="kpis">${[['Informasi', a.info], ['Permintaan', a.perm], ['Komplain', a.komp], ['Non Pengaduan', a.nonp]].map(([l, v]) => U.kpi({ label: l, value: C.fmtCompact(v), info: true, sub: C.fmtPct(v / tot * 100) + ' kontribusi' })).join('')}</div>
          <div class="grid">${U.card('Kontribusi kategori', U.chartBox('rs-donut'), { span: 's4' })}${U.card('Kategori per project', U.chartBox('rs-stack'), { span: 's8' })}${U.card('Tren kategori bulanan', U.chartBox('rs-trend'), { span: 's12' })}</div>` : noData('Kolom Informasi / Permintaan / Komplain / Non Pengaduan belum terisi.'));
      } else {
        body = `<div class="grid">${U.card('Ranking kategori berdasarkan volume', '<div id="tc-table"></div>', { span: 's7', hint: 'Bobot: Top 1 = 3, Top 2 = 2, Top 3 = 1 per hari' })}${U.card('Kontribusi kategori teratas', U.chartBox('tc-chart', 'tall'), { span: 's5' })}${U.card('Perbandingan antar project', '<div id="tc-proj"></div>', { span: 's12' })}${U.card('Tren kategori teratas', U.chartBox('tc-trend'), { span: 's12' })}</div>`;
      }
      return U.pageHead('Traffic Analytics', 'Traffic Analytics', App.periodLabel()) + tab.html + body;
    },
    mount() {
      const App = A(); const rows = App.rows(); if (!rows.length) return; const pal = U.palette(); const cur = App.subTab.traffic || 'volume';
      if (cur === 'volume') {
        const dow = C.DAYS_ID.map((d, i) => { const rr = rows.filter(r => new Date(r.date + 'T00:00:00').getDay() === i); const days = new Set(rr.map(r => r.date)).size; return { d, v: days ? rr.reduce((s, r) => s + r.trafficUsed, 0) / days : 0 }; });
        const order = [1, 2, 3, 4, 5, 6, 0];
        U.chart('tr-dow', 'bar', { labels: order.map(i => dow[i].d.slice(0, 3)), datasets: [{ label: 'Rata-rata traffic/hari', data: order.map(i => dow[i].v), backgroundColor: pal[0], borderRadius: 4 }] }, { scales: { y: tickCompact } });
        const d = App.series(rows, 'date');
        U.chart('tr-daily', 'line', { labels: d.map(x => x.key.slice(5)), datasets: [{ label: 'Inbound', data: d.map(x => x.acc), borderColor: pal[0], pointRadius: 0, tension: .2 }, { label: 'Digital', data: d.map(x => x.totdig), borderColor: pal[1], pointRadius: 0, tension: .2 }, { label: 'Outbound', data: d.map(x => x.ob), borderColor: pal[3], pointRadius: 0, tension: .2 }] }, { scales: { y: tickCompact } });
        const w = App.series(rows, 'week');
        U.chart('tr-week', 'bar', { labels: w.map(x => x.key.slice(5)), datasets: [{ label: 'Total traffic', data: w.map(x => x.traffic), backgroundColor: pal[2], borderRadius: 3 }] }, { scales: { y: tickCompact } });
        const m = App.series(rows);
        U.chart('tr-month', 'bar', { labels: ymLabels(m), datasets: [{ label: 'Inbound', data: m.map(x => x.acc), backgroundColor: pal[0], stack: 'm' }, { label: 'Outbound', data: m.map(x => x.ob), backgroundColor: pal[3], stack: 'm' }, { label: 'Digital', data: m.map(x => x.totdig), backgroundColor: pal[1], stack: 'm' }] }, { scales: { x: { stacked: true }, y: Object.assign({ stacked: true }, tickCompact) } });
        const a = App.agg(rows); const parts = [['Inbound', a.acc], ['Outbound', a.ob]].concat(C.CHANNELS.map(c => [c.label, a[c.k]])).filter(x => x[1] > 0).sort((x, y) => y[1] - x[1]);
        U.chart('tr-ch', 'doughnut', { labels: parts.map(x => x[0]), datasets: [{ data: parts.map(x => x[1]), backgroundColor: parts.map((_, i) => pal[i % pal.length]), borderWidth: 0 }] }, { cutout: '58%', plugins: { legend: { position: 'right' } } });
        const pp = App.perProject(rows);
        U.chart('tr-proj', 'bar', { labels: pp.map(x => x.project.code), datasets: [{ label: 'Traffic', data: pp.map(x => x.agg.traffic), backgroundColor: pal[0], borderRadius: 4 }] }, { scales: { y: tickCompact } });
      } else if (cur === 'reason') {
        const a = App.agg(rows); if (!(a.info + a.perm + a.komp + a.nonp)) return;
        const K = [['info', 'Informasi'], ['perm', 'Permintaan'], ['komp', 'Komplain'], ['nonp', 'Non Pengaduan']];
        U.chart('rs-donut', 'doughnut', { labels: K.map(k => k[1]), datasets: [{ data: K.map(k => a[k[0]]), backgroundColor: pal.slice(0, 4), borderWidth: 0 }] }, { cutout: '62%' });
        const pp = App.perProject(rows).filter(x => x.agg.info + x.agg.perm + x.agg.komp + x.agg.nonp > 0);
        U.chart('rs-stack', 'bar', { labels: pp.map(x => x.project.code), datasets: K.map((k, i) => ({ label: k[1], data: pp.map(x => x.agg[k[0]]), backgroundColor: pal[i], stack: 'r' })) }, { scales: { x: { stacked: true }, y: Object.assign({ stacked: true }, tickCompact) } });
        const s = App.series(rows);
        U.chart('rs-trend', 'line', { labels: ymLabels(s), datasets: K.map((k, i) => ({ label: k[1], data: s.map(x => x[k[0]]), borderColor: pal[i], tension: .3 })) }, { scales: { y: tickCompact } });
      } else {
        const cat = {}; rows.forEach(r => [['top1', 3], ['top2', 2], ['top3', 1]].forEach(([k, w]) => { const t = r[k]; if (!t) return; const key = t.trim(); const c = cat[key] = cat[key] || { name: key, score: 0, days: 0, projects: new Set(), byMonth: {} }; c.score += w; c.days++; c.projects.add(r.projectId); c.byMonth[r.ym] = (c.byMonth[r.ym] || 0) + w; }));
        const list = Object.values(cat).sort((a, b) => b.score - a.score); const total = list.reduce((s, c) => s + c.score, 0);
        if (!list.length) { document.getElementById('tc-table').innerHTML = U.empty('Belum ada data Top Kategori', 'Isi kolom Top Kategori 1-3 pada template.'); return; }
        U.dataTable('tc-table', [{ k: 'rank', label: '#', r: 1 }, { k: 'name', label: 'Kategori', wrap: 1 }, { k: 'score', label: 'Skor', r: 1, fmt: C.fmtInt }, { k: 'pct', label: '%', r: 1, fmt: v => C.fmtPct(v) }, { k: 'days', label: 'Hari muncul', r: 1 }, { k: 'proj', label: 'Project', fmt: v => v.map(id => `<span class="tag">${esc(App.proj(id).code)}</span>`).join('') }],
          list.map((c, i) => ({ rank: i + 1, name: c.name, score: c.score, pct: c.score / total * 100, days: c.days, proj: [...c.projects] })), { pageSize: 10 });
        const top = list.slice(0, 8);
        U.chart('tc-chart', 'bar', { labels: top.map(c => c.name.length > 38 ? c.name.slice(0, 36) + '…' : c.name), datasets: [{ label: '% kontribusi', data: top.map(c => c.score / total * 100), backgroundColor: pal[2], borderRadius: 4 }] }, { indexAxis: 'y', scales: { y: { grid: { display: false }, ticks: { font: { size: 10 } } } } });
        const pp = App.perProject(rows).map(x => { const c = {}; x.rows.forEach(r => [['top1', 3], ['top2', 2], ['top3', 1]].forEach(([k, w]) => { if (r[k]) c[r[k]] = (c[r[k]] || 0) + w; })); const best = Object.entries(c).sort((a, b) => b[1] - a[1]); return { code: x.project.code, n: best.length, c1: best[0] ? best[0][0] : '–', c2: best[1] ? best[1][0] : '–', c3: best[2] ? best[2][0] : '–' }; }).filter(x => x.n);
        U.dataTable('tc-proj', [{ k: 'code', label: 'Project' }, { k: 'c1', label: 'Kategori #1', wrap: 1 }, { k: 'c2', label: 'Kategori #2', wrap: 1 }, { k: 'c3', label: 'Kategori #3', wrap: 1 }], pp, { noPaging: true, search: false });
        const months = App.months().filter(m => rows.some(r => r.ym === m));
        U.chart('tc-trend', 'line', { labels: months.map(C.ymShort), datasets: list.slice(0, 5).map((c, i) => ({ label: c.name.length > 40 ? c.name.slice(0, 38) + '…' : c.name, data: months.map(m => c.byMonth[m] || 0), borderColor: pal[i], tension: .3 })) });
      }
    }
  };
})();
