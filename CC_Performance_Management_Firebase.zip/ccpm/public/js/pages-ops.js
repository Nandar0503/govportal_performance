/* =========================================================================
 * HALAMAN OPERASIONAL: SLA & SCR, Quality, Workforce, Digital Channel
 * ========================================================================= */
(function () {
  'use strict';
  const C = window.Core, U = window.UI, esc = C.esc;
  const Pages = window.Pages = window.Pages || {};
  const A = () => window.App; const PH = () => window.PH;

  /* =================== 6. SLA & SERVICE LEVEL =================== */
  const ISSUE_CATS = ['Jaringan / Telco', 'Sistem / Pencatatan', 'SDM / Staffing', 'Lonjakan Volume', 'Lainnya'];
  function issueList(rows) {
    const App = A(); const stored = new Map(App.data.issues.map(i => [i.id, i]));
    return rows.filter(r => r.issue).map(r => {
      const id = r.projectId + '_' + r.date; const s = stored.get(id) || {}; const t = C.isNum(r.tscr) ? r.tscr : App.targets(r.projectId).scr;
      return { id, projectId: r.projectId, code: App.proj(r.projectId).code, date: r.date, scr: r.scrUsed, target: t, gap: C.isNum(r.scrUsed) ? r.scrUsed - t : null, issue: r.issue, category: s.category || PH().issueCategory(r.issue), actionPlan: s.actionPlan || '', status: s.status || 'Open', updatedBy: s.updatedBy || '' };
    }).sort((a, b) => b.date.localeCompare(a.date));
  }
  Pages.sla = {
    title: 'SLA & Service Level', icon: 'sla', perm: 'dashboard.view', filters: true,
    render() {
      const App = A(); const rows = App.rows().filter(r => r.off > 0 || C.isNum(r.scr));
      if (!rows.length) return U.pageHead('SCR Performance', 'SLA & Service Level', App.periodLabel()) + PH().noData('Tidak ada data inbound/SCR pada filter ini.');
      const a = App.agg(rows); const tg = App.targetFor(rows, 'scr'); const st = C.status(a.scr, tg, true, App.F());
      const ach = C.isNum(a.scr) && tg ? a.scr / tg * 100 : null; const gap = C.isNum(a.scr) ? a.scr - tg : null;
      const pp = App.perProject(rows).filter(x => C.isNum(x.agg.scr)).sort((x, y) => x.agg.scr - y.agg.scr);
      const F = App.F(); const cnt = { ok: 0, risk: 0, bad: 0 }; pp.forEach(x => { const s = C.status(x.agg.scr, App.targets(x.project.id).scr, true, F); if (cnt[s] !== undefined) cnt[s]++; });
      const iss = issueList(App.rows());
      const below = rows.filter(r => C.isNum(r.scrUsed) && r.scrUsed < (C.isNum(r.tscr) ? r.tscr : App.targets(r.projectId).scr) && !r.issue).length;
      const mode = App.subTab.slaTrend || 'monthly';
      return U.pageHead('SCR Performance', 'SLA & Service Level', App.periodLabel()) +
        `<div class="grid">
          <section class="card s4"><div class="card-h"><h3>SCR vs Target</h3>${U.pill(st)}</div><div class="card-b"><div class="gauge"><canvas id="sla-gauge"></canvas><div class="g-val"><b>${C.fmtPct(a.scr)}</b><span>Target ${C.fmtPct(tg)}</span></div></div>
            <div class="stat-strip" style="margin-top:12px"><div><span>Target SCR</span><b>${C.fmtPct(tg)}</b></div><div><span>Actual SCR</span><b>${C.fmtPct(a.scr)}</b></div><div><span>Achievement</span><b>${C.fmtPct(ach)}</b></div><div><span>Gap</span><b style="color:var(--${gap >= 0 ? 'ok' : 'bad'})">${gap === null ? '–' : (gap >= 0 ? '+' : '') + C.fmtNum(gap, 2) + ' pt'}</b></div></div></div></section>
          ${U.card('Status SCR per project', `<div class="row small" style="margin-bottom:8px">${U.pill('ok', cnt.ok + ' Achieved')}${U.pill('risk', cnt.risk + ' At Risk')}${U.pill('bad', cnt.bad + ' Below Target')}</div>` + pp.map(x => { const t = App.targets(x.project.id).scr; const s = C.status(x.agg.scr, t, true, F); return `<div class="row" style="padding:5px 0;flex-wrap:nowrap"><b style="width:96px;flex:none;font-size:12.5px;overflow-wrap:anywhere">${esc(x.project.code)}</b>${U.barCell(x.agg.scr, 100, t, PH().stColor(s))}<span class="mono" style="width:62px;text-align:right;font-size:12.5px">${C.fmtPct(x.agg.scr)}</span>${U.pill(s)}</div>`; }).join(''), { span: 's8', hint: 'Garis tegak = target project' })}
          ${U.card('SCR Trend', `<div class="row" style="margin-bottom:8px"><button class="btn sm ${mode === 'monthly' ? 'primary' : ''}" data-sla="monthly">Bulanan</button><button class="btn sm ${mode === 'daily' ? 'primary' : ''}" data-sla="daily">Harian</button><button class="btn sm ${mode === 'weekly' ? 'primary' : ''}" data-sla="weekly">Mingguan</button></div>${U.chartBox('sla-trend', 'tall')}`, { span: 's8', hint: 'Actual line vs target line' })}
          ${U.card('Service Level by Project', U.chartBox('sla-sl', 'tall'), { span: 's4' })}
        </div>
        <div class="section-title"><h2>Issue Ketidaktercapaian SCR</h2><span>${iss.length} catatan issue${below ? ` · ${below} hari di bawah target tanpa keterangan` : ''}</span></div>
        ${U.card('', '<div id="sla-issues"></div>')}`;
    },
    mount() {
      const App = A(); const rows = App.rows().filter(r => r.off > 0 || C.isNum(r.scr)); if (!rows.length) return;
      document.querySelectorAll('[data-sla]').forEach(b => b.addEventListener('click', () => { App.subTab.slaTrend = b.dataset.sla; App.render(); }));
      const a = App.agg(rows); const tg = App.targetFor(rows, 'scr'); U.gauge('sla-gauge', a.scr, tg, C.status(a.scr, tg, true, App.F()));
      const mode = App.subTab.slaTrend || 'monthly'; const pal = U.palette();
      const s = App.series(rows, mode === 'daily' ? 'date' : mode === 'weekly' ? 'week' : 'ym');
      const lbl = s.map(x => mode === 'monthly' ? C.ymShort(x.key) : mode === 'daily' ? x.key.slice(5) : x.key.slice(5));
      U.chart('sla-trend', 'line', { labels: lbl, datasets: [{ label: 'Actual SCR', data: s.map(x => x.scr), borderColor: pal[0], backgroundColor: U.alpha(pal[0], .1), fill: true, tension: .25, pointRadius: mode === 'daily' ? 0 : 3, spanGaps: true }, { label: 'Target SCR', data: s.map(x => { const rr = rows.filter(r => (mode === 'daily' ? r.date : mode === 'weekly' ? C.isoWeek(r.date) : r.ym) === x.key); return App.targetFor(rr, 'scr'); }), borderColor: U.css('--bad'), borderDash: [6, 4], pointRadius: 0 }] }, { scales: { y: { beginAtZero: false, max: 100, ticks: { callback: v => v + '%' } } } });
      const pp = App.perProject(rows).filter(x => C.isNum(x.agg.sl)).sort((x, y) => y.agg.sl - x.agg.sl);
      U.chart('sla-sl', 'bar', { labels: pp.map(x => x.project.code), datasets: [{ label: 'SL', data: pp.map(x => x.agg.sl), backgroundColor: pp.map(x => PH().stColor(C.status(x.agg.sl, App.targets(x.project.id).sl, true, App.F()))), borderRadius: 4 }] }, { indexAxis: 'y', scales: { x: { max: 100 }, y: { grid: { display: false } } } });
      const list = issueList(App.rows()); const canEdit = App.can('issue.edit');
      U.dataTable('sla-issues', [
        { k: 'code', label: 'Project' }, { k: 'date', label: 'Date' }, { k: 'scr', label: 'SCR', r: 1, fmt: v => C.fmtPct(v) }, { k: 'target', label: 'Target', r: 1, fmt: v => C.fmtPct(v) },
        { k: 'gap', label: 'Gap', r: 1, fmt: v => C.isNum(v) ? `<span style="color:var(--${v >= 0 ? 'ok' : 'bad'})">${v >= 0 ? '+' : ''}${C.fmtNum(v, 2)}</span>` : '–' },
        { k: 'issue', label: 'Issue', wrap: 1 }, { k: 'category', label: 'Category', fmt: v => `<span class="tag">${esc(v)}</span>` }, { k: 'actionPlan', label: 'Action Plan', wrap: 1, fmt: v => esc(v || '–') },
        { k: 'status', label: 'Status', fmt: v => U.pill(v === 'Resolved' ? 'ok' : v === 'On Progress' ? 'risk' : 'bad', v) },
        { k: 'id', label: '', noSort: 1, fmt: v => canEdit ? `<button class="btn sm" data-issue="${esc(v)}">${U.icon('edit')} Kelola</button>` : '' }
      ], list, { pageSize: 10, emptyMsg: 'Belum ada catatan pada kolom "Issue Ketidak tercapaian SCR".', onRender: el => el.querySelectorAll('[data-issue]').forEach(b => b.addEventListener('click', () => editIssue(list.find(i => i.id === b.dataset.issue)))) });
    }
  };
  function editIssue(it) {
    const App = A();
    const m = U.modal({ title: `Issue SCR · ${it.code} · ${it.date}`, body: `<div class="stack"><div class="muted small">${esc(it.issue)}</div>
      <div class="form-grid"><div class="field"><label for="is-cat">Category</label><select class="input" id="is-cat">${ISSUE_CATS.map(c => `<option ${c === it.category ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
      <div class="field"><label for="is-st">Status</label><select class="input" id="is-st">${['Open', 'On Progress', 'Resolved'].map(s => `<option ${s === it.status ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
      <div class="field full"><label for="is-ap">Action Plan</label><textarea class="input" id="is-ap" maxlength="1000">${esc(it.actionPlan)}</textarea></div></div></div>`,
      foot: `<button class="btn" data-close>Batal</button><button class="btn primary" id="is-save">Simpan</button>` });
    m.el.querySelector('#is-save').addEventListener('click', async () => {
      const rec = { id: it.id, projectId: it.projectId, date: it.date, issue: it.issue, category: m.el.querySelector('#is-cat').value, status: m.el.querySelector('#is-st').value, actionPlan: m.el.querySelector('#is-ap').value.trim(), updatedBy: App.profile.name, updatedAt: new Date().toISOString() };
      try { await App.ds.saveIssue(rec); const i = App.data.issues.findIndex(x => x.id === rec.id); if (i >= 0) App.data.issues[i] = rec; else App.data.issues.push(rec); await App.audit('Edit Data', `Issue SCR ${it.code} ${it.date} → ${rec.status}`, it.projectId); m.close(); U.toast('Issue tersimpan.', 'ok'); App.render(); }
      catch (e) { U.toast(e.message, 'bad'); }
    });
  }

  /* =================== 7. QUALITY =================== */
  function agentsInScope() {
    const App = A(); const f = App.filter; const months = new Set(App.rows().map(r => r.ym));
    const allowed = new Set(App.rows().map(r => r.projectId));
    return App.data.agents.filter(a => (!f.project || a.projectId === f.project) && (!f.customer || App.proj(a.projectId).customerId === f.customer) && (allowed.has(a.projectId) || !App.rows().length)).map(a => {
      const pick = obj => Object.entries(obj || {}).filter(([m]) => !months.size || months.has(m));
      const q = pick(a.qs); const pk = pick(a.pk); const at = pick(a.att);
      return { name: a.name, projectId: a.projectId, code: App.proj(a.projectId).code, channel: a.channel, qs: C.avg(q.map(x => x[1])), last: q.length ? q.sort()[q.length - 1][1] : null, n: q.length, pk: C.avg(pk.map(x => x[1])), att: C.avg(at.map(x => x[1])), scores: q };
    }).filter(a => a.n);
  }
  Pages.quality = {
    title: 'Quality Performance', icon: 'quality', perm: 'dashboard.view', filters: true,
    render() {
      const App = A(); const rows = App.rows(); const a = App.agg(rows); const ag = agentsInScope();
      if (!rows.length) return U.pageHead('Quality', 'Quality Performance', App.periodLabel()) + PH().noData();
      const F = App.F(); const bands = { Excellent: 0, Good: 0, 'Need Improvement': 0 };
      ag.forEach(x => x.scores.forEach(([, v]) => { bands[C.qualityBand(v, F)]++; }));
      const totB = bands.Excellent + bands.Good + bands['Need Improvement'];
      return U.pageHead('Quality Monitoring', 'Quality Performance', App.periodLabel()) +
        PH().kpiCards(['qs', 'pk', 'prod'], rows, a, { tav: true }) +
        `<div class="grid">
          ${U.card('Quality Trend per project', U.chartBox('q-trend', 'tall'), { span: 's8', hint: 'Skor QM bulanan' })}
          ${U.card('Distribusi skor agent', totB ? U.chartBox('q-dist', 'tall') : U.empty('Belum ada skor agent', ''), { span: 's4', hint: `Excellent ≥ ${F.qualityExcellent} · Good ≥ ${F.qualityGood}` })}
          ${U.card('Project Comparison', U.chartBox('q-proj'), { span: 's6', hint: 'Garis = target quality project' })}
          ${U.card('Monthly Trend (rata-rata)', U.chartBox('q-month'), { span: 's6', hint: 'Quality · Product Knowledge · Productivity' })}
          ${U.card('Agent Performance', ag.length ? '<div id="q-agents"></div>' : U.empty('Belum ada data skor per agent', 'Data agent tersedia untuk project yang memiliki rekap QM.'), { hint: `${ag.length} agent` })}
        </div>`;
    },
    mount() {
      const App = A(); const rows = App.rows(); if (!rows.length) return; const pal = U.palette(); const F = App.F();
      const months = App.months().filter(m => rows.some(r => r.ym === m)); const pp = App.perProject(rows).filter(x => C.isNum(x.agg.qs));
      U.chart('q-trend', 'line', { labels: months.map(C.ymShort), datasets: pp.map((x, i) => { const s = new Map(App.series(x.rows).map(y => [y.key, y])); return { label: x.project.code, data: months.map(m => s.get(m) ? s.get(m).qs : null), borderColor: pal[i % pal.length], tension: .3, spanGaps: true }; }) }, { scales: { y: { beginAtZero: false, suggestedMin: 75, max: 100 } } });
      const ag = agentsInScope(); const bands = { Excellent: 0, Good: 0, 'Need Improvement': 0 }; ag.forEach(x => x.scores.forEach(([, v]) => bands[C.qualityBand(v, F)]++));
      if (document.getElementById('q-dist')) U.chart('q-dist', 'doughnut', { labels: Object.keys(bands), datasets: [{ data: Object.values(bands), backgroundColor: [U.css('--ok'), U.css('--c1'), U.css('--risk')], borderWidth: 0 }] }, { cutout: '60%' });
      U.chart('q-proj', 'bar', { labels: pp.map(x => x.project.code), datasets: [{ label: 'Quality', data: pp.map(x => x.agg.qs), backgroundColor: pp.map(x => PH().stColor(C.status(x.agg.qs, App.targets(x.project.id).quality, true, F))), borderRadius: 4 }, { type: 'line', label: 'Target', data: pp.map(x => App.targets(x.project.id).quality), borderColor: U.css('--text'), showLine: false, pointStyle: 'line', pointRadius: 10 }] }, { scales: { y: { beginAtZero: false, suggestedMin: 75, max: 100 } } });
      const s = App.series(rows);
      U.chart('q-month', 'line', { labels: PH().ymLabels(s), datasets: [{ label: 'Quality', data: s.map(x => x.qs), borderColor: pal[1], tension: .3, spanGaps: true }, { label: 'Product Knowledge', data: s.map(x => x.pk), borderColor: pal[2], tension: .3, spanGaps: true }, { label: 'Productivity', data: s.map(x => x.prod), borderColor: pal[3], tension: .3, spanGaps: true }] }, { scales: { y: { beginAtZero: false, suggestedMin: 75, max: 100 } } });
      if (ag.length) U.dataTable('q-agents', [{ k: 'name', label: 'Agent' }, { k: 'code', label: 'Project' }, { k: 'channel', label: 'Channel' }, { k: 'qs', label: 'Rata-rata QM', r: 1, fmt: v => C.fmtNum(v, 2) }, { k: 'last', label: 'Bulan terakhir', r: 1, fmt: v => C.fmtNum(v, 2) }, { k: 'pk', label: 'Product Knowledge', r: 1, fmt: v => C.fmtNum(v, 1) }, { k: 'att', label: 'Kehadiran', r: 1, fmt: v => C.fmtPct(v) },
        { k: 'band', label: 'Kategori', sort: r => r.qs, fmt: (v, r) => { const b = C.qualityBand(r.qs, F); return U.pill(b === 'Excellent' ? 'ok' : b === 'Good' ? 'info' : 'risk', b); } }], ag, { sortK: 'qs', pageSize: 12 });
    }
  };

  /* =================== 8. WORKFORCE =================== */
  Pages.workforce = {
    title: 'Workforce Performance', icon: 'workforce', perm: 'dashboard.view', filters: true,
    render() {
      const App = A(); const rows = App.rows(); if (!rows.length) return U.pageHead('Workforce', 'Workforce Performance', App.periodLabel()) + PH().noData();
      const a = App.agg(rows); const pp = App.perProject(rows); const F = App.F();
      const tab = App.tabs('wf', [['wf', 'Workforce'], ['att', 'Attendance & Login Monitoring']]);
      const alerts = [];
      pp.forEach(x => { const g = x.agg, t = App.targets(x.project.id), c = x.project.code;
        if (C.isNum(g.seat) && C.isNum(g.sdm)) { if (g.sdm < g.seat * 0.9) alerts.push(['bad', `Understaffed: ${c} memiliki ${g.sdm} SDM untuk ${g.seat} seat.`]); else if (g.sdm > g.seat * 1.25) alerts.push(['risk', `Overstaffed: ${c} memiliki ${g.sdm} SDM untuk ${g.seat} seat.`]); }
        if (C.status(g.att, t.attendance, true, F) === 'bad' || C.status(g.att, t.attendance, true, F) === 'risk') alerts.push([C.status(g.att, t.attendance, true, F), `Attendance Issue: kehadiran ${c} ${C.fmtPct(g.att)} (target ${C.fmtPct(t.attendance)}).`]);
        if (['bad', 'risk'].includes(C.status(g.login, t.login, true, F))) alerts.push([C.status(g.login, t.login, true, F), `Login Compliance Issue: ketepatan login ${c} ${C.fmtPct(g.login)} (target ${C.fmtPct(t.login)}).`]);
      });
      const missing = ['seat', 'att', 'login', 'prod'].filter(k => !C.isNum(a[k])).map(k => ({ seat: 'Jumlah Seat', att: 'Kehadiran', login: 'Ketepatan Login', prod: 'Productifity Agent' }[k]));
      const note = missing.length ? `<div class="demo-banner" style="background:var(--info-soft);border-color:var(--accent-line)">${U.icon('info')}<span>Kolom <b>${missing.join(', ')}</b> belum terisi pada data periode ini. Lengkapi melalui template upload agar seluruh indikator workforce tampil.</span></div>` : '';
      let body;
      if (tab.cur === 'wf') {
        body = PH().kpiCards(['seat', 'sdm', 'prod', 'att', 'login'].filter(k => k !== 'seat' && k !== 'sdm'), rows, a, { tav: true });
        body = `<div class="kpis">${U.kpi({ label: 'Jumlah Seat', value: C.fmtInt(a.seat), icon: 'project', info: true, sub: C.isNum(a.seat) ? 'Nilai terakhir per project' : 'Belum ada data' })}${U.kpi({ label: 'Jumlah SDM', value: C.fmtInt(a.sdm), icon: 'workforce', info: true, sub: 'Nilai terakhir per project' })}${U.kpi({ label: 'Utilisasi Staffing', value: C.isNum(a.seat) && a.seat ? C.fmtPct(a.sdm / a.seat * 100) : '–', icon: 'workforce', info: true, sub: 'SDM / Seat' })}</div>` + body +
          `<div class="grid">${U.card('Seat vs SDM', U.chartBox('wf-seat'), { span: 's6' })}${U.card('Staffing Utilization', U.chartBox('wf-util'), { span: 's6', hint: 'SDM ÷ Seat per project' })}
          ${U.card('Attendance Trend', U.chartBox('wf-att', 'short'), { span: 's4' })}${U.card('Login Accuracy Trend', U.chartBox('wf-login', 'short'), { span: 's4' })}${U.card('Productivity Trend', U.chartBox('wf-prod', 'short'), { span: 's4' })}
          ${U.card('Workforce Alert', alerts.length ? alerts.map(([s, t]) => `<div class="alert-row ${s}"><span class="ic">${U.icon('alert')}</span><div>${esc(t)}</div></div>`).join('') : U.empty('Tidak ada alert workforce', 'Staffing, kehadiran, dan login sesuai target (untuk data yang tersedia).'))}</div>`;
      } else {
        const sched = a.sdm || 0; const present = C.isNum(a.att) ? Math.round(sched * a.att / 100) : null; const ontime = C.isNum(a.login) && present !== null ? Math.round(present * a.login / 100) : null;
        body = `<div class="kpis">${[['Total Agent', a.sdm], ['Scheduled', sched || null], ['Present', present], ['Absent', present !== null ? sched - present : null], ['Late', ontime !== null ? present - ontime : null], ['On Time', ontime]].map(([l, v]) => U.kpi({ label: l, value: C.fmtInt(v), info: true, sub: l === 'Total Agent' ? 'Jumlah SDM' : 'Estimasi harian rata-rata' })).join('')}</div>` +
          PH().kpiCards(['att', 'login'], rows, a, { tav: true }) +
          `<p class="muted small" style="margin:0">Present/Absent/Late/On Time diestimasi dari Jumlah SDM × % Kehadiran × % Ketepatan Login. Untuk angka absolut, tambahkan data absensi per agent.</p>
          <div class="grid">${U.card('Attendance Trend', U.chartBox('at-att'), { span: 's6' })}${U.card('Login Accuracy Trend', U.chartBox('at-login'), { span: 's6' })}${U.card('Project Comparison', U.chartBox('at-proj'), { span: 's12' })}${U.card('Ringkasan per project', '<div id="at-table"></div>')}</div>`;
      }
      return U.pageHead('Workforce Monitoring', 'Workforce Performance', App.periodLabel()) + tab.html + note + body;
    },
    mount() {
      const App = A(); const rows = App.rows(); if (!rows.length) return; const pal = U.palette(); const pp = App.perProject(rows); const s = App.series(rows); const L = PH().ymLabels(s);
      const line = (id, k, color, tKey) => U.chart(id, 'line', { labels: L, datasets: [{ label: PH().KPI_DEF[k].label, data: s.map(x => x[k]), borderColor: color, backgroundColor: U.alpha(color, .1), fill: true, tension: .3, spanGaps: true }].concat(tKey ? [{ label: 'Target', data: s.map(() => App.targetFor(rows, tKey)), borderColor: U.css('--bad'), borderDash: [6, 4], pointRadius: 0 }] : []) }, { scales: { y: { beginAtZero: false, suggestedMin: 80, max: 100 } } });
      if ((App.subTab.wf || 'wf') === 'wf') {
        const w = pp.filter(x => C.isNum(x.agg.sdm) || C.isNum(x.agg.seat));
        U.chart('wf-seat', 'bar', { labels: w.map(x => x.project.code), datasets: [{ label: 'Seat', data: w.map(x => x.agg.seat), backgroundColor: pal[4], borderRadius: 4 }, { label: 'SDM', data: w.map(x => x.agg.sdm), backgroundColor: pal[0], borderRadius: 4 }] });
        const u = w.filter(x => x.agg.seat > 0);
        if (u.length) U.chart('wf-util', 'bar', { labels: u.map(x => x.project.code), datasets: [{ label: 'Utilisasi %', data: u.map(x => x.agg.sdm / x.agg.seat * 100), backgroundColor: pal[2], borderRadius: 4 }] });
        else document.getElementById('wf-util').parentElement.innerHTML = U.empty('Data Jumlah Seat belum tersedia', 'Isi kolom Jumlah Seat pada template.');
        line('wf-att', 'att', pal[0], 'attendance'); line('wf-login', 'login', pal[3], 'login'); line('wf-prod', 'prod', pal[2], 'productivity');
      } else {
        line('at-att', 'att', pal[0], 'attendance'); line('at-login', 'login', pal[3], 'login');
        const q = pp.filter(x => C.isNum(x.agg.att) || C.isNum(x.agg.login));
        U.chart('at-proj', 'bar', { labels: q.map(x => x.project.code), datasets: [{ label: 'Attendance %', data: q.map(x => x.agg.att), backgroundColor: pal[0], borderRadius: 4 }, { label: 'Login Accuracy %', data: q.map(x => x.agg.login), backgroundColor: pal[3], borderRadius: 4 }, { label: 'Productivity %', data: q.map(x => x.agg.prod), backgroundColor: pal[2], borderRadius: 4 }] }, { scales: { y: { beginAtZero: false, suggestedMin: 80, max: 100 } } });
        U.dataTable('at-table', [{ k: 'code', label: 'Project' }, { k: 'sdm', label: 'Agent', r: 1, fmt: C.fmtInt }, { k: 'att', label: 'Attendance', r: 1, fmt: v => C.fmtPct(v) }, { k: 'login', label: 'Login Accuracy', r: 1, fmt: v => C.fmtPct(v) }, { k: 'prod', label: 'Productivity', r: 1, fmt: v => C.fmtPct(v) }], pp.map(x => Object.assign({ code: x.project.code }, x.agg)), { noPaging: true });
      }
    }
  };

  /* =================== 9. DIGITAL CHANNEL =================== */
  function channelStats(rows) {
    const tot = rows.reduce((s, r) => s + (r.totdigUsed || 0), 0);
    return C.CHANNELS.map(c => {
      let v = 0, rtw = 0, rtv = 0, htw = 0, htv = 0, rrw = 0, rrv = 0;
      rows.forEach(r => { const n = r[c.k] || 0; if (!n) return; v += n; if (C.isNum(r.rt)) { rtw += n; rtv += r.rt * n; } if (C.isNum(r.ht)) { htw += n; htv += r.ht * n; } if (C.isNum(r.rr)) { rrw += n; rrv += r.rr * n; } });
      return { k: c.k, label: c.label, volume: v, share: tot ? v / tot * 100 : null, rt: rtw ? rtv / rtw : null, ht: htw ? htv / htw : null, rr: rrw ? rrv / rrw : null };
    });
  }
  function heat(rowsLabel, colsLabel, getVal, fmt) {
    let max = 0; rowsLabel.forEach(r => colsLabel.forEach(c => { const v = getVal(r, c); if (C.isNum(v) && v > max) max = v; }));
    const c1 = U.css('--c1');
    return `<div class="tbl-wrap"><table class="tbl heat"><thead><tr><th></th>${colsLabel.map(c => `<th class="r">${esc(c.label)}</th>`).join('')}</tr></thead><tbody>${rowsLabel.map(r => `<tr><td><b>${esc(r.label)}</b></td>${colsLabel.map(c => { const v = getVal(r, c); const a = C.isNum(v) && max ? .08 + .72 * (v / max) : 0; return `<td class="h" style="background:${a ? U.alpha(c1, a.toFixed(2)) : 'transparent'};color:${a > .5 ? '#fff' : 'inherit'}">${C.isNum(v) && v ? fmt(v) : '·'}</td>`; }).join('')}</tr>`).join('')}</tbody></table></div>`;
  }
  Pages.digital = {
    title: 'Digital Channel', icon: 'digital', perm: 'dashboard.view', filters: true,
    render() {
      const App = A(); const rows = App.rows(); const st = channelStats(rows); const act = st.filter(x => x.volume > 0).sort((a, b) => b.volume - a.volume);
      const head = U.pageHead('Digital Service', 'Digital Channel', App.periodLabel());
      const tab = App.tabs('dig', [['ov', 'Channel Overview'], ['rh', 'Response & Handling Time']]);
      if (!rows.length || !act.length) return head + tab.html + PH().noData('Tidak ada interaksi digital pada filter ini.');
      const a = App.agg(rows); const months = App.months().filter(m => rows.some(r => r.ym === m));
      if (tab.cur === 'ov') {
        const cards = st.slice().sort((x, y) => y.volume - x.volume).map(x => `<div class="kpi ${x.volume ? 'st-info' : ''}"><div class="lbl">${esc(x.label)}</div><div class="val">${C.fmtCompact(x.volume)}</div><div class="meta"><span>${x.volume ? C.fmtPct(x.share) + ' kontribusi' : 'Tidak ada volume'}</span></div>${x.volume ? `<div class="small muted">RT ${C.fmtSec(x.rt)} · HT ${C.fmtSec(x.ht)} · RR ${C.fmtPct(x.rr)}</div><div class="spark"><canvas id="dg-sp-${x.k}"></canvas></div>` : ''}</div>`).join('');
        const pp = App.perProject(rows).filter(x => x.agg.totdig > 0);
        return head + tab.html + PH().kpiCards(['totdig', 'rt', 'ht', 'rr'], rows, a) + `<div class="section-title"><h2>15 channel digital</h2><span>Volume, kontribusi & tren</span></div><div class="kpis">${cards}</div>
          <div class="grid">${U.card('Heatmap volume: channel × bulan', heat(act, months.map(m => ({ k: m, label: C.ymShort(m) })), (r, c) => rows.filter(x => x.ym === c.k).reduce((s, x) => s + (x[r.k] || 0), 0), C.fmtCompact), { hint: 'Warna makin pekat = trafik makin tinggi' })}
          ${U.card('Heatmap volume: channel × project', heat(act, pp.map(x => ({ k: x.project.id, label: x.project.code })), (r, c) => rows.filter(x => x.projectId === c.k).reduce((s, x) => s + (x[r.k] || 0), 0), C.fmtCompact))}</div>`;
      }
      return head + tab.html + `<div class="grid">${U.card('Response & Handling per channel', '<div id="rh-table"></div>', { hint: 'RT/HT/RR per channel = rata-rata tertimbang volume dari nilai harian project' })}
        ${U.card('Response vs Handling Time', U.chartBox('rh-bar', 'tall'), { span: 's6' })}${U.card('Tren bulanan', U.chartBox('rh-line', 'tall'), { span: 's6' })}
        ${U.card('Heatmap response time: project × bulan', heat(App.perProject(rows).filter(x => C.isNum(x.agg.rt)).map(x => ({ k: x.project.id, label: x.project.code })), months.map(m => ({ k: m, label: C.ymShort(m) })), (r, c) => App.agg(rows.filter(x => x.projectId === r.k && x.ym === c.k)).rt, C.fmtSec), { hint: 'Makin pekat = response time makin lama' })}</div>`;
    },
    mount() {
      const App = A(); const rows = App.rows(); const st = channelStats(rows); if (!st.some(x => x.volume)) return; const pal = U.palette();
      const months = App.months().filter(m => rows.some(r => r.ym === m));
      if ((App.subTab.dig || 'ov') === 'ov') { st.filter(x => x.volume).forEach(x => U.spark('dg-sp-' + x.k, months.map(m => rows.filter(r => r.ym === m).reduce((s, r) => s + (r[x.k] || 0), 0)), pal[1])); return; }
      const act = st.filter(x => x.volume).sort((a, b) => b.volume - a.volume); const tg = { rt: App.targetFor(rows, 'rt'), ht: App.targetFor(rows, 'ht'), rr: App.targetFor(rows, 'rr') }; const F = App.F();
      U.dataTable('rh-table', [{ k: 'label', label: 'Channel' }, { k: 'volume', label: 'Volume', r: 1, fmt: C.fmtInt }, { k: 'share', label: 'Kontribusi', r: 1, fmt: v => C.fmtPct(v) },
        { k: 'rt', label: 'Response Time', r: 1, fmt: v => C.isNum(v) ? `${C.fmtSec(v)} ${U.pill(C.status(v, tg.rt, false, F))}` : '–' },
        { k: 'ht', label: 'Handling Time', r: 1, fmt: v => C.isNum(v) ? `${C.fmtSec(v)} ${U.pill(C.status(v, tg.ht, false, F))}` : '–' },
        { k: 'rr', label: 'Response Rate', r: 1, fmt: v => C.isNum(v) ? `${C.fmtPct(v)} ${U.pill(C.status(v, tg.rr, true, F))}` : '–' }], act, { noPaging: true, search: false, sortK: 'volume' });
      U.chart('rh-bar', 'bar', { labels: act.map(x => x.label), datasets: [{ label: 'Response Time (dtk)', data: act.map(x => x.rt), backgroundColor: pal[0], borderRadius: 4 }, { label: 'Handling Time (dtk)', data: act.map(x => x.ht), backgroundColor: pal[2], borderRadius: 4 }, { type: 'line', label: 'Target RT', data: act.map(() => tg.rt), borderColor: U.css('--bad'), borderDash: [6, 4], pointRadius: 0 }] }, { scales: { y: { ticks: { callback: v => C.fmtSec(v) } } } });
      const s = App.series(rows);
      U.chart('rh-line', 'line', { labels: PH().ymLabels(s), datasets: [{ label: 'Response Time', data: s.map(x => x.rt), borderColor: pal[0], tension: .3, spanGaps: true, yAxisID: 'y' }, { label: 'Handling Time', data: s.map(x => x.ht), borderColor: pal[2], tension: .3, spanGaps: true, yAxisID: 'y' }, { label: 'Response Rate %', data: s.map(x => x.rr), borderColor: pal[1], borderDash: [4, 3], tension: .3, spanGaps: true, yAxisID: 'y1' }] }, { scales: { y: { ticks: { callback: v => C.fmtSec(v) } }, y1: { position: 'right', min: 0, max: 100, grid: { display: false } } } });
    }
  };
})();
