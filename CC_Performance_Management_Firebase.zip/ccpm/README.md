# Corporate Contact Center Performance Management

Web application untuk memonitor performa seluruh project contact center (multi customer, multi project, multi channel) dalam satu platform. Dibangun di atas **Firebase**: Authentication, Firestore, Storage, dan Hosting.

- **Frontend**: HTML/CSS/JavaScript tanpa build step, sehingga bisa langsung di-deploy. Grafik memakai Chart.js, Excel memakai SheetJS, PDF memakai jsPDF, dan PowerPoint memakai PptxGenJS.
- **Backend**: Firebase Auth (hashing password, session, reset password), Firestore (database, dengan RBAC dan isolasi data di Security Rules), dan Storage (arsip file Excel).
- **Data awal**: data asli Jan–Sep 2026 dari file Excel Segmen 3 (13 project). Data dimasukkan sekali lewat menu **System Settings → Data & Sistem → Import ke Firestore**.

---

## 1. Struktur folder

```
ccpm/
├─ firebase.json            # hosting + security headers (CSP, HSTS, X-Frame-Options)
├─ .firebaserc              # project: government-f3e2b
├─ firestore.rules          # RBAC & isolasi data per project
├─ firestore.indexes.json
├─ storage.rules            # arsip upload Excel per project
├─ templates/
│  └─ Template_Daily_Performance.xlsx   # template standar (50 kolom)
└─ public/                  # folder yang di-deploy ke Firebase Hosting
   ├─ index.html
   └─ js/
      ├─ config.js          # konfigurasi Firebase & mode aplikasi
      ├─ core.js            # template, RBAC, mesin kalkulasi & validasi (satu sumber angka)
      ├─ seed-data.js       # data awal hasil pembersihan file Excel
      ├─ data-firebase.js   # data service Firebase
      ├─ data-demo.js       # data service demo (in-browser), antarmuka sama
      ├─ ui.js              # komponen UI, chart, modal, export file
      ├─ app.js             # login, shell, router, filter global, state
      ├─ pages-dashboard.js # Executive, Portfolio, Project, Channel, Traffic
      ├─ pages-ops.js       # SLA/SCR, Quality, Workforce, Digital Channel
      └─ pages-admin.js     # Customer/Project, Upload, Report, User, Access, Audit, Settings
```

## 2. Deploy ke Firebase (sekali saja)

1. **Firebase Console → Authentication → Sign-in method**: aktifkan **Email/Password**.
2. **Firestore Database → Create database**: pilih *production mode* dan lokasi `asia-southeast2 (Jakarta)`.
3. **Storage → Get started**: wajib untuk arsip file Excel. Bucket baru membutuhkan paket **Blaze**. Tanpa Storage, upload data tetap berjalan, hanya file aslinya yang tidak diarsipkan.
4. Di komputer Anda:
   ```bash
   npm install -g firebase-tools
   firebase login
   cd ccpm
   firebase deploy        # hosting + firestore rules + storage rules
   ```
5. Buka URL hosting (`https://government-f3e2b.web.app`). Karena database masih kosong, halaman login menampilkan **Setup awal**. Buat akun **Super Admin** pertama di sana.
6. Login sebagai Super Admin, lalu buka **System Settings → Data & Sistem → Import ke Firestore** untuk memasukkan 13 customer, 13 project, target KPI, 3.096 baris data harian, dan skor QM 59 agent.
7. Buat user lain di **User Management**, lalu atur role dan project yang boleh diakses.

> **Keamanan API key**: `apiKey` Firebase di `config.js` memang bersifat publik (client identifier), bukan rahasia. Yang menjaga data adalah Security Rules. Langkah tambahan yang disarankan: di Google Cloud Console → APIs & Services → Credentials, batasi API key ke domain hosting Anda, lalu aktifkan **Firebase App Check**.

### Mode demo
Di `public/js/config.js`, ubah `mode: 'firebase'` menjadi `mode: 'demo'` untuk menjalankan aplikasi tanpa backend. Data disimpan di browser dan tersedia 6 akun contoh, satu untuk setiap role (password `Demo#2026`). Mode `auto` akan mencoba Firebase dulu, lalu memakai demo jika Firebase tidak terjangkau.

## 3. Role & akses

| Permission | Super Admin | Corporate Admin | Project Manager | Project Admin | Data Entry | Viewer |
|---|:-:|:-:|:-:|:-:|:-:|:-:|
| Dashboard | ✓ | ✓ | ✓ | ✓ | – | ✓ |
| Download template / Upload | ✓ | ✓ | ✓ | ✓ | ✓ | – |
| Approve / reject / reprocess upload | ✓ | ✓ | – | – | – | – |
| Hapus data | ✓ | – | – | – | – | – |
| Export report | ✓ | ✓ | ✓ | ✓ | – | ✓ |
| Kelola issue SCR | ✓ | ✓ | ✓ | ✓ | – | – |
| Customer / Project | ✓ | ✓ | – | – | – | – |
| KPI & target | ✓ | ✓ | – | – | – | – |
| User management | ✓ | ✓ (tidak bisa mengubah Super Admin) | – | – | – | – |
| Audit log | ✓ | ✓ | – | – | – | – |
| Permission & formula | ✓ | – | – | – | – | – |

- Matriks ini bisa diubah di menu **Access Management** dan disimpan ke `system_settings/permissions`. Firestore Rules membaca matriks yang sama.
- **Isolasi data**: Super Admin dan Corporate Admin melihat semua project. Role lain hanya melihat project di field `projectAccess` pada profilnya (project yang ditugaskan, ditambah semua project milik customer yang ditugaskan). Aturan ini ditegakkan oleh Firestore Rules, jadi tidak bisa dilewati dari browser.
- Jika customer mendapat project baru, buka lalu simpan ulang user viewer customer tersebut agar `projectAccess` ikut diperbarui.

## 4. Model data Firestore

| Tabel pada spesifikasi | Koleksi Firestore | Keterangan |
|---|---|---|
| users, roles, permissions | `users`, `usernames`, `system_settings/permissions` | password di-hash oleh Firebase Auth (tidak pernah disimpan di Firestore) |
| customers, projects, project_users | `customers`, `projects`, `users.projects / customers / projectAccess` | |
| kpi_targets | `kpi_targets/{projectId}` | target berbeda per project |
| daily_performance, digital_performance, workforce_performance | `daily_performance/{projectId}_{YYYY-MM}` | 1 dokumen per project per bulan, berisi `rows[]` harian (50 kolom template). Semua dashboard dan report membaca sumber yang sama sehingga angkanya selalu konsisten |
| quality_performance | `quality_performance/{projectId}` | skor QM per agent per bulan |
| upload_history, upload_errors | `upload_history`, `upload_errors` | menyimpan snapshot data lama untuk rollback saat reject |
| issue_tracking | `issue_tracking/{projectId}_{date}` | kategori, action plan, status |
| reports | `reports` | jadwal report |
| audit_logs | `audit_logs`, `login_history`, `login_attempts` | append-only (tidak bisa diubah atau dihapus) |
| system_settings | `system_settings/{formulas, permissions, bootstrap}` | |

Relasi: Customer → Project → Daily Performance (berisi channel, quality, workforce) → Dashboard.

## 5. Template Excel & validasi

- Template berisi 50 kolom dengan **nama dan urutan persis** sesuai spesifikasi (`PROJECT`, `MONTH`, `DATE`, `DAY`, `Call Offered (Inbound)`, … `Ketepatan Login`). Template bisa diunduh dari Data Upload Center (otomatis terisi project dan tanggal satu bulan) atau dari `templates/`.
- **Validasi struktur**: nama kolom, jumlah kolom, dan urutan kolom. Jika salah, muncul pesan *"Template tidak sesuai. Silakan download template terbaru."*
- **Validasi per baris**: mandatory field, PROJECT harus sesuai project yang dipilih, MONTH valid dan sesuai periode, format tanggal, tanggal berada dalam periode, tanggal duplikat, angka dan angka negatif, persentase (0–1 atau 0–100), durasi (detik atau hh:mm:ss), serta konsistensi formula (ACD ≤ Offered, Abandon ≤ Offered, ACD + Abandon ≈ Offered, SCR vs ACD/Offered, Total Digital vs jumlah channel, issue wajib diisi saat SCR < target).
- **Error** memblokir submit. **Warning** hanya berupa catatan dan tidak memblokir. Keduanya bisa diunduh sebagai *Error Report*.
- Jika tanggal yang di-upload sudah ada di database, user harus mencentang opsi **Timpa data**. Data lama disimpan agar bisa dipulihkan saat upload di-*reject*.

## 6. Formula (dapat dikonfigurasi di System Settings → Formula & Alert)

- Accepted Call = ACD Call
- Abandon Rate = Abandon ÷ Call Offered × 100%
- SCR = nilai upload, atau ACD ÷ Offered. Agregasi multi-hari/multi-project memakai bobot volume (Σ ACD ÷ Σ Offered) atau rata-rata harian
- Total Digital = Walkin + SMS + Email + Aplikasi + Chatbot + Facebook + Threads + Instagram + Live Chat + Video Call + Apps + Twitter/X + WhatsApp Interaction + WhatsApp Blasting + OTP
- Total Traffic All = Accepted + Outbound + Total Digital
- Status: **Achieved** (≥ target), **At Risk** (≤ 2 poin di bawah target, atau AHT ≤ 10% di atas target), **Below Target**. Batas ini dapat diatur.

## 7. Checklist keamanan

| Persyaratan | Implementasi |
|---|---|
| Authentication, password hashing, session | Firebase Auth (scrypt), persistence *Ingat saya* (local/session), auto-logout setelah 30 menit tidak aktif |
| Forgot/reset password | `sendPasswordResetEmail`, juga tersedia di User Management |
| Activation/deactivation, last login, login history, failed login | field `status` dicek saat login dan oleh Rules; `login_history`, `login_attempts`; Firebase memblokir sementara setelah terlalu banyak percobaan |
| RBAC & project-level isolation | `firestore.rules`, `storage.rules` |
| Input & file validation | validasi template (core.js), maksimal 10 MB, ekstensi .xlsx/.xls/.csv (juga di storage.rules) |
| XSS | semua teks di-*escape* sebelum ditampilkan, ditambah header CSP di `firebase.json` |
| SQL injection | tidak relevan: Firestore adalah NoSQL dan diakses lewat SDK bertipe, tanpa query string |
| CSRF | Firebase memakai token bearer (bukan cookie), sehingga request lintas situs tidak membawa kredensial |
| Audit trail | `audit_logs` append-only: login, logout, upload, approve/reject, hapus data, create/edit/delete user, perubahan permission, KPI, dan target, export report |

## 8. Pengembangan berikutnya (memerlukan Cloud Functions, paket Blaze)

- **Pengiriman report terjadwal**: buat function `onSchedule` yang membaca koleksi `reports`, menyusun file, lalu mengirim email (misalnya lewat extension *Trigger Email*).
- **Hapus akun login**: saat dokumen `users/{uid}` dihapus, panggil `admin.auth().deleteUser(uid)` dari function `onDocumentDeleted`. Sementara ini, akun tanpa profil otomatis ditolak saat login.
- **IP address di audit log**: browser tidak dapat membaca IP sendiri. Catat IP lewat callable function (`request.rawRequest.ip`).
- **Data interval per jam**: template saat ini harian, sehingga grafik *Hourly Traffic* menampilkan pola per hari dalam seminggu. Tambahkan sheet interval bila data per jam tersedia.

## 9. Catatan data awal

Data awal diambil dari `dashboard_performance_govseg3_ytd_2026_fixed.xlsx` (Sumary Trafik), `Rekapan_QM_2026_Segmen_3.xlsx`, `Score_Quality_Assurance_BKPM_2026.xlsx`, `Quality_Performance_Monthly_Agent_Dikti_2026.xlsx`, dan jumlah SDM per layanan dari `summary_data_dashboard_gov_segement_3_2026.xlsx`. **Data pribadi pegawai (KTP, alamat, rekening, dan sejenisnya) tidak dimasukkan.**

Pembersihan yang dilakukan:
- 330 tanggal dengan hari/bulan tertukar diperbaiki.
- Respon Rate > 100% dan response time > 48 jam dikosongkan karena tidak valid.
- Facebook/Instagram/Twitter = comment + DM.
- Interaksi TikTok (2.347) tidak dihitung karena tidak ada di template. Tambahkan kolom baru jika TikTok perlu dilaporkan.

Kolom **Jumlah Seat**, **Ketepatan Login**, dan **Productifity Agent** belum tersedia di file sumber. Kolom **Kehadiran** dan **Product Knowledge** baru tersedia untuk Dikti. Indikator ini akan tampil begitu kolomnya diisi melalui upload template.
